"""Sizing and drawing the on-screen cards, without any Kodi code.

Kodi cannot measure text from an add-on, so widths are estimated from a typical
sans-serif's letter widths. The scale was measured on the owner's PC and laptop
(font12 in Plextuary: 23.6 and 23.9 px per em at 1080 lines) and is set about 6%
wider, so a line always fits. Lines are broken here, not by Kodi, so the card's
height is known; a card image is drawn once per size and kept.
"""
import os
import struct
import zlib

# Advance widths per 1000 units of the em, close to Noto Sans and similar skin fonts.
WIDTHS = {
    ' ': 260, '.': 268, ',': 268, ':': 268, ';': 268, "'": 221, '"': 401, '!': 268, '?': 429, '-': 322, '(': 303,
    ')': 303, '·': 268, '/': 372, '&': 705,
    'a': 561, 'b': 615, 'c': 480, 'd': 615, 'e': 564, 'f': 344, 'g': 615, 'h': 618, 'i': 258, 'j': 258, 'k': 534,
    'l': 258, 'm': 935, 'n': 618, 'o': 605, 'p': 615, 'q': 615, 'r': 413, 's': 479, 't': 361, 'u': 618, 'v': 508,
    'w': 786, 'x': 529, 'y': 510, 'z': 470,
    'A': 639, 'B': 647, 'C': 632, 'D': 723, 'E': 556, 'F': 522, 'G': 726, 'H': 739, 'I': 336, 'J': 259, 'K': 615,
    'L': 524, 'M': 907, 'N': 763, 'O': 778, 'P': 604, 'Q': 778, 'R': 618, 'S': 549, 'T': 553, 'U': 733, 'V': 603,
    'W': 925, 'X': 579, 'Y': 556, 'Z': 566,
}
DIGIT, OTHER = 572, 700
PX_PER_UNIT = 25.5 / 1000

# Layout on a 1920 x 1080 window.
PAD_X, PAD_Y = 20, 14
ICON, GAP = 44, 14
LINE_H = 32
RADIUS = 18
MAX_TEXT = 430
MIN_HEIGHT = ICON + 2 * PAD_Y
# Widths are rounded up to this step, so only a handful of card images ever exist.
WIDTH_STEP = 8


def text_width(text):
    return sum(WIDTHS.get(c, DIGIT if c.isdigit() else OTHER) for c in text) * PX_PER_UNIT


def wrap(text, limit=MAX_TEXT):
    """Lines no wider than `limit`, broken between words; [CR] forces a break."""
    lines = []
    for paragraph in text.replace('[CR]', '\n').split('\n'):
        line = ''
        words = []
        for word in paragraph.split():
            if word == '\u00b7' and words:
                words[-1] += ' \u00b7'  # a separator ends a line, never starts one ("Example Show \u00b7" / "S1 E2")
            else:
                words.append(word)
        for word in words:
            candidate = word if not line else line + ' ' + word
            if line and text_width(candidate) > limit:
                lines.append(line)
                line = word
            else:
                line = candidate
        lines.append(line)
    return [line for line in lines if line] or ['']


def layout(text):
    """Card size and where its parts go, relative to the card's top left corner."""
    lines = wrap(text)
    text_w = int(max(text_width(line) for line in lines)) + 1
    width = PAD_X + ICON + GAP + text_w + PAD_X
    width = -(-width // WIDTH_STEP) * WIDTH_STEP
    height = max(MIN_HEIGHT, len(lines) * LINE_H + 2 * PAD_Y)
    return {
        'width': width, 'height': height, 'lines': lines,
        'icon': (PAD_X, (height - ICON) // 2, ICON),
        'text': (PAD_X + ICON + GAP, (height - len(lines) * LINE_H) // 2, width - PAD_X - ICON - GAP - PAD_X // 2),
    }


def rounded_png(path, width, height, radius=RADIUS, scale=2, samples=4):
    """A white rounded rectangle (Kodi tints it), drawn at `scale` times the size for clean edges."""
    w, h, r = width * scale, height * scale, radius * scale
    full = b'\xff\xff\xff\xff'

    def corner_alpha(x, y):
        # Distance from the corner circle's centre, sampled, for a smooth edge.
        cx = r if x < r else w - r
        cy = r if y < r else h - r
        hits = 0
        for i in range(samples):
            for j in range(samples):
                px, py = x + (i + 0.5) / samples, y + (j + 0.5) / samples
                hits += (px - cx) ** 2 + (py - cy) ** 2 <= r * r
        return int(255 * hits / samples ** 2)

    edge_rows = {}
    rows = bytearray()
    for y in range(h):
        rows.append(0)
        if r <= y < h - r:
            rows.extend(full * w)
            continue
        key = y if y < r else h - 1 - y
        row = edge_rows.get(key)
        if row is None:
            left = bytearray()
            for x in range(r):
                left.extend(b'\xff\xff\xff' + bytes((corner_alpha(x, key),)))
            right = bytearray()
            for x in range(r - 1, -1, -1):
                right.extend(left[4 * x:4 * x + 4])
            row = bytes(left) + full * (w - 2 * r) + bytes(right)
            edge_rows[key] = row
        rows.extend(row)

    def chunk(kind, data):
        body = kind + data
        return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)

    temporary = path + '.new'
    with open(temporary, 'wb') as handle:
        handle.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
                     + chunk(b'IDAT', zlib.compress(bytes(rows), 6)) + chunk(b'IEND', b''))
    os.replace(temporary, path)


def card_image(folder, width, height):
    """The card image for this size, drawn the first time it is needed."""
    path = os.path.join(folder, 'card-{}x{}.png'.format(width, height))
    if not os.path.exists(path):
        os.makedirs(folder, exist_ok=True)
        rounded_png(path, width, height)
    return path
