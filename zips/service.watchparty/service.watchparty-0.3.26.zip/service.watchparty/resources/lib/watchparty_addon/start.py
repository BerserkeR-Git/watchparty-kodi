"""The shared start: holding a player for the moment everyone starts, and getting it there.

A countdown (begin): the watch party plays on from a spot at a moment ahead. The player is held until then; while
held it gets into position (jumps to the spot), its landing is checked, and a keyframe player that landed short
may move everyone's start back to where it is (an align). At the moment it plays, a little early by its play lead,
or later by however far ahead it is held. Too late, or out of position, it lands instead.

A landing (land): from pause, jump ahead of where the party will be and wait held until the party reaches that
frame ("Syncing"), then play.

The engine holds the player and lets it go (hold, release): Start never pauses or plays the player itself, so the
engine keeps knowing which pause is its own. Nothing here knows the party beyond its change number (seq).
"""
from collections import namedtuple

# A held player away from the spot gets into position during the countdown (a jump while paused, at least this
# long before the moment) and then starts from pause like everyone, instead of jumping at the moment (where the TV
# landed on keyframes, up to 9 s off). Tried as an experiment first (owner's fourth diagnostics run): the laptop
# landed within 0.04 s and every start from there was within 0.1 s; the TV started cleanly from where it landed.
PREPOSITION_MIN_MS = 2000
PREPOSITION_CHECK_MS = 1000
# The TV lands short of the spot when it jumps while held (on the keyframe before it: 0.2 to 9 s in the owner's
# fourth diagnostics run): with this long still to go, everyone starts from where it landed instead (the others
# get into position there; the laptop lands to the millisecond), once per countdown.
ALIGN_MIN_MS = 1500
# A held player never moves: everything is put right at the shared moment. One a little ahead of the party's
# spot (a follower always pauses a moment after whoever paused) keeps its frame and starts that much later,
# exactly in sync. One further off, or behind (it would start before the moment), jumps to the spot just before
# the moment, its learned jump lead early, so it starts with everyone (jump then play at once looks right on
# the P3i box; holding paused after a jump does not).
HOLD_AHEAD_S = 3.0
HOLD_BEHIND_S = 0.25
# How often the engine runs in the last moments before a shared start.
FINE_TICK_MS = 20
# Starting more than this late (the message arrived late) jumps to the right spot instead of starting behind.
LATE_START_MS = 250
# A start from hold later than this (the loop held up by a request at the moment) is no measure of the play lead:
# nothing is learnt from it, and once settled the player lines up if it ended up out of step.
LATE_TO_LEARN_MS = 100
# A countdown is only shown when there is time to read it.
COUNTDOWN_MIN_MS = 1500
# From pause, a jump lands and then waits for the party to reach that frame, rather than jumping and playing at
# once: on the TV (the P3i) a jump then play took about 3.7 s before the picture moved, and still landed 0.7 s
# behind (a keyframe), while a start from where it is held lands within about 50 ms. Aimed where the party will
# be LAND_AHEAD_S from now (or at its start, if that is later); where it landed is read LAND_CHECK_MS later;
# landed with less than LAND_MIN_MS to wait, it jumps again, further on (LAND_TRIES jumps at most). Only from
# pause: a playing player is never paused for it (Plex would report a pause nobody pressed, and the owner's lights
# follow it).
LAND_AHEAD_S = 3.0
LAND_CHECK_MS = 1200
LAND_MIN_MS = 300
LAND_TRIES = 2
# Within this long of a shared start (or while landing), nothing that can wait goes out (status, diagnostics):
# a request is sent from the same loop that starts the player, and one held up by the connection (up to 6 s)
# made the device miss the moment.
QUIET_BEFORE_START_MS = 6000

# What run() hands back on the tick the player was set playing: the change to learn the play lead from (None when
# it is no measure), whether to line up once settled instead (a late start), and a notice kept for this moment.
Started = namedtuple('Started', 'learn line_up say')


def jump_trace(player):
    """How the player's time read while its last jump waited for Kodi (Kodi's player only), as plain numbers."""
    trace = getattr(player, 'jump_trace', None)
    return {key: value for key, value in trace.items() if value is None or isinstance(value, int)} \
        if isinstance(trace, dict) else {}


class Start:
    def __init__(self, clock, player, screen, movement, learned, hold, release, align, seq, watching, diag, log):
        """`hold()` and `release()` pause and play the player as the engine's own moves; `align(spot, seq)` asks
        the server to start everyone from `spot` and returns its answer or None; `seq()` is the party's current
        change (None without a party); `watching()` whether a video of the party's title is open."""
        self.clock, self.player, self.screen, self.movement, self.learned = clock, player, screen, movement, learned
        self.hold, self.release, self.align, self.seq, self.watching = hold, release, align, seq, watching
        self.diag, self.log = diag, log
        self.scheduled = None  # (moment, spot) of the countdown under way
        self.landing_now = None  # the landing under way (see land)
        self.positioned = None  # (moment, spot) got into position for, once per countdown
        self.position_check = None  # (seq, when, spot aimed at) of getting into position, to read where it landed
        self.aligned_for = None  # the moment an align was sent for, once per countdown
        self.screen_countdown = None  # (when, caption) shown for the countdown
        self.countdown_caption = None  # (moment, caption): a moved start keeps its caption

    # Starting -----------------------------------------------------------------------------------------------

    def begin(self, moment, spot, kind=None):
        """The watch party plays on from `spot` at `moment` (ahead): hold the player and count down to it."""
        now = self.clock()
        self.hold()
        self.scheduled = (moment, spot)
        # A player a little ahead (it paused a moment after whoever paused) starts that much later, so its
        # countdown runs to its own start: it never sits at zero looking stuck.
        start = self._own_start(moment, spot)
        self.screen_countdown = None
        if start - now >= COUNTDOWN_MIN_MS:
            caption = 'Starting' if kind == 'start' else 'Resuming'
            if kind in ('align', 'seek') and self.countdown_caption and self.countdown_caption[0] == moment:
                caption = self.countdown_caption[1]  # the same start, moved: still "Starting" if it was
            self.countdown_caption = (moment, caption)
            self.screen_countdown = (start, caption)
            self.screen.countdown(*self.screen_countdown)

    def land(self, at_ref, pos_ref):
        """From pause: jump ahead of the party and wait there for it, then play. The party is at `pos_ref` at
        `at_ref` and moves on from there."""
        now = self.clock()
        # Where the party will be once this player can have landed: right on the spot if the start is far enough
        # off (it then starts with everyone), else that much further on.
        aim = pos_ref + max(0, now + LAND_AHEAD_S * 1000 - at_ref) / 1000.0
        self.landing_now = {'ref': (at_ref, pos_ref), 'aim': aim, 'check': now + LAND_CHECK_MS, 'tries': 1,
                            'play_at': None, 'seq': self.seq()}
        self._land_jump(aim)

    def say_when_landed(self, text):
        """Keep a notice for the moment a landing plays (not while it still waits to). False when not landing."""
        if not self.landing_now:
            return False
        self.landing_now['say'] = text
        return True

    # Running ------------------------------------------------------------------------------------------------

    def run(self, now):
        """The countdown, then the landing, as far as they are due. Returns a Started for each that set the player
        playing this tick (none, mostly; both only when a landing ran beside a countdown)."""
        started = []
        if self.scheduled:
            started.append(self._run_scheduled(now))
        if self.landing_now:
            started.append(self._run_landing(now))
        return [one for one in started if one is not None]

    def check(self, now):
        """Where getting into position landed, once it has settled: an align, or the countdown moved."""
        if self.position_check and now >= self.position_check[1]:
            self._check_position(now)

    # Letting go ---------------------------------------------------------------------------------------------

    def cancel(self):
        """The countdown no longer applies: dropped, and taken off the screen. Returns its (moment, spot), if any."""
        dropped, self.scheduled = self.scheduled, None
        self.screen.clear_countdown()
        return dropped

    def drop(self, with_check=False):
        """A countdown or a landing under way is dropped and taken off the screen (with a pending check of where it
        got into position, if asked); True if there was one."""
        if not (self.scheduled or self.landing_now):
            return False
        self.scheduled = self.landing_now = None
        if with_check:
            self.position_check = None
        self.screen.clear_countdown()
        return True

    def drop_landing(self, clear=True):
        """A landing under way is dropped (the viewer's own move, or a new change decides now); True if there was."""
        if not self.landing_now:
            return False
        self.landing_now = None
        if clear:
            self.screen.clear_countdown()
        return True

    def forget_video(self):
        """The video went: a landing and a pending check of where it got into position belonged to it."""
        self.landing_now = self.position_check = None

    # Questions ----------------------------------------------------------------------------------------------

    @property
    def counting_down(self):
        return bool(self.scheduled)

    @property
    def landing(self):
        return bool(self.landing_now)

    @property
    def moment(self):
        """(moment, spot) of the countdown under way, or None."""
        return self.scheduled

    def busy(self):
        """Something under way that needs the engine's quick pace (a pending check included)."""
        return bool(self.scheduled or self.landing_now or self.position_check)

    def near(self, now):
        """Landing, or close to a shared start: nothing that can wait goes out (see QUIET_BEFORE_START_MS)."""
        return bool(self.landing_now) or bool(self.scheduled and self.scheduled[0] - now < QUIET_BEFORE_START_MS)

    def wake_in_ms(self, now):
        """When the engine next needs to run, if sooner than its usual pace (for precise starts)."""
        if self.scheduled:
            # The earliest this device may act: playing from hold a little behind the spot (anything further off
            # lands at the moment itself; see _run_scheduled).
            lead = self.learned.play + HOLD_BEHIND_S
            left = self.scheduled[0] - lead * 1000 - now
            return max(FINE_TICK_MS, min(left, 250)) if left > 250 else FINE_TICK_MS
        if self.landing_now and self.landing_now['play_at'] is not None:
            left = self.landing_now['play_at'] - now
            return max(FINE_TICK_MS, min(left, 250)) if left > 250 else FINE_TICK_MS
        return None

    # Inside -------------------------------------------------------------------------------------------------

    def _jump(self, spot):
        self.movement.expect('seek')  # held, a jump reports only its seek
        self.movement.jumped(spot, not self.player.paused())
        self.player.jump(spot)

    def _land_jump(self, aim):
        spot = max(0.0, aim)
        self._jump(spot)
        if self.landing_now:
            # From the jump's end: the jump's wait used to hold 1.5 s, so the check ran well after the landing; it
            # now returns once the time reads near the aim (PLAN W1).
            self.landing_now['check'] = self.clock() + LAND_CHECK_MS
        self.log('land ahead at {:.3f}, held'.format(spot))
        self.diag('ld', to=float(spot), n=self.landing_now['tries'] if self.landing_now else 1,
                  **jump_trace(self.player))

    def _run_landing(self, now):
        landing = self.landing_now
        at_ref, pos_ref = landing['ref']
        if landing['play_at'] is None:
            if now < landing['check']:
                return None
            landed = self.player.position() if self.player.paused() else None
            if landed is None:
                self.landing_now = None  # playing already (the viewer pressed play): theirs from here
                return None
            play_at = int(at_ref + (landed - pos_ref) * 1000 - self.learned.play * 1000)
            if play_at - now < LAND_MIN_MS and landing['tries'] < LAND_TRIES:
                # Landed short (a keyframe well before the spot): again, further on by what it fell short.
                aim = pos_ref + max(0, now + LAND_AHEAD_S * 1000 - at_ref) / 1000.0 + max(0.0, landing['aim'] - landed)
                landing.update(aim=aim, check=now + LAND_CHECK_MS, tries=landing['tries'] + 1)
                self._land_jump(aim)
                return None
            landing['play_at'] = max(now, play_at)
            self.log('landed at {:.3f}: plays in {} ms'.format(landed, landing['play_at'] - now))
            self.diag('lw', at=float(landed), wait=int(landing['play_at'] - now))
            if landing['play_at'] - now >= COUNTDOWN_MIN_MS:
                self.screen.countdown(landing['play_at'], 'Syncing')
            return None
        if now < landing['play_at']:
            return None
        self.landing_now = None
        self.screen.clear_countdown()
        self.release()
        current = self.seq()
        learn = landing['seq'] if current is not None and current == landing['seq'] else None
        return Started(learn=learn, line_up=False, say=landing.get('say'))

    def _preposition(self, now, at, position):
        """Get into position while held, once per scheduled start."""
        if self.positioned == (at, position) or not self.player.paused():
            return
        self.positioned = (at, position)
        mine = self.player.position()
        if mine is None or -HOLD_BEHIND_S <= mine - position <= HOLD_AHEAD_S or at - now < PREPOSITION_MIN_MS:
            return
        self._jump(position)
        self.log('into position while held: {:.3f} -> {:.3f}, {} ms before the moment'.format(mine, position, at - now))
        seq = self.seq()
        self.diag('pp', seq=seq, frm=float(mine), to=float(position), early=int(at - now), **jump_trace(self.player))
        self.position_check = (seq, self.clock() + PREPOSITION_CHECK_MS, position)  # from the jump's end, as land's

    def _check_position(self, now):
        seq, _, aimed = self.position_check
        self.position_check = None
        landed = self.player.position() if self.player.paused() else None
        self.diag('pl', seq=seq, off=None if landed is None else float(landed - aimed))
        current = self.seq()
        if current is None or current != seq:
            # The start changed while this player got into position for the one before (someone skipped during the
            # countdown): its landing says nothing about the new start. (Taken for landing short of it, the laptop
            # asked to start from 0:00 instead of 33:56, took the server's answer for yes and played from 0:00 while
            # everyone else was at 33:56: the simulation with Plex's timings, round 35.)
            return
        if landed is not None and self.scheduled:
            self.log('into position: landed {:+.3f} s from the spot'.format(landed - aimed))
            # Against where everyone starts now, not where this player aimed: another player may have moved the
            # start back meanwhile (to where it landed), and this one may well be ahead of that.
            at, spot = self.scheduled
            if landed - spot < -HOLD_BEHIND_S and at - now >= ALIGN_MIN_MS and self.aligned_for != at:
                result = self.align(landed, seq)
                if result is not None:
                    # Landed short: everyone starts from here instead (the new spot comes back as the party's state).
                    self.aligned_for = at
                    self.diag('al', seq=seq, to=float(landed))
                    if result.get('seq') != seq:
                        # Taken: it starts from here, held, without waiting for the new state to come back. (The TV's
                        # came 3.6 s later, its loop busy with slow jumps; meanwhile it found itself short of the old
                        # spot and landed, jump after jump, while everyone else started from where it had been.)
                        self.scheduled = (at, landed)
                    return
            start = self._own_start(*self.scheduled)
            if self.screen_countdown and abs(start - self.screen_countdown[0]) > 300:
                # Landed a little ahead (a keyframe): it starts that much later, and its countdown says so.
                self.screen_countdown = (start, self.screen_countdown[1])
                self.screen.countdown(*self.screen_countdown)

    def _run_scheduled(self, now):
        at, position = self.scheduled
        self._preposition(now, at, position)
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and -HOLD_BEHIND_S <= mine - position <= HOLD_AHEAD_S:
            # Already (nearly) there: start a little earlier or later instead of jumping, and this device's own
            # play lead early, as it takes that long to get moving.
            start = at + (mine - position) * 1000 - self.learned.play * 1000
            if now < start:
                return None
            self.scheduled = None
            if not self.watching():
                return None
            self.log('start: {} ms after the moment, {:.3f} from the spot'.format(now - at, mine - position))
            self.diag('go', seq=self.seq(), how='late' if now - start > LATE_START_MS else 'hold', late=int(now - start),
                      ahead=float(mine - position), pl=self.learned.play)
            if now - start > LATE_START_MS:
                self.land(self.clock(), position + (now - at) / 1000.0)  # held, so it lands and waits
                return None
            self.release()
            current = self.seq()
            on_time = now - start <= LATE_TO_LEARN_MS
            return Started(learn=current if current is not None and on_time else None,
                           line_up=current is not None and not on_time, say=None)
        if self.position_check and now < at:
            return None  # where it got into position is still to be read (it may move everyone's spot back instead)
        self.scheduled = None
        if self.watching():
            # Too far from the spot to start from where it is held, and no time (or no luck) getting into position
            # during the countdown: it lands ahead and starts when the party reaches that frame (see land).
            self.log('start by landing: {} ms to the moment'.format(at - now))
            self.diag('go', seq=self.seq(), how='land', early=int(at - now))
            self.screen.clear_countdown()
            self.land(at, position)
        return None

    def _own_start(self, at, position):
        """When this held player will start for the shared moment `at`: later by however far ahead it is held."""
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and 0 < mine - position <= HOLD_AHEAD_S:
            return at + int((mine - position) * 1000)
        return at
