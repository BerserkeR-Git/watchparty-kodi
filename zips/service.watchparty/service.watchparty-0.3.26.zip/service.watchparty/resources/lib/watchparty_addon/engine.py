"""What this device does when someone in a watch party pauses, plays, skips or starts.

There is no Kodi code in here. The engine works through three small adapters:
a player (what is playing, and pause/play/jump: see player.py), a screen (cards
and questions) and send (one request to the Watch Party server). The same logic
runs in the tests and in Kodi. Beside it: movement.py (whose move an event was),
start.py (the shared start), learned.py (the leads) and wording.py (what is said).

Rules measured on a real device (PLAN.md, phase 0):
- Never hold a pause after a jump: jump, then play straight away.
- PM4K wraps its own skips in pause, jump, play and raises a flag meanwhile.
- PM4K's start-up (resume point) also pauses, jumps and plays. None of that is the viewer.
"""
import json

from .learned import Learned
from .movement import REPORT_LATE_MAX_S, SEEK_ECHO_S, Movement
from .player import LANDED_MOVE_S, LANDED_SHORT_MAX_S
from .start import Start, jump_trace
from . import wording

# PM4K's own skip lands on a keyframe, up to 4 s from the spot it reports. It is said at once from where this
# device's PM4K skips land (learned); where it really landed is read this long after it plays again (or, without
# PM4K's pause and play around it, after the skip), teaches that, and puts the party right when far off.
PM4K_LANDING_MS = 1200
# The owner's choice (2026-10-16, "as accurate as possible"): a PM4K skip that leaves this player this far from the
# party is put right with one more skip, which the others follow without a second "skipped to". 1.5 s at first;
# since 2026-10-18 the same as a followed skip's (ALIGN_FOLLOW_S, the owner: "past 1 s off"): the box's first PM4K
# skip each way, nothing learnt yet, landed 1.14 s off and stayed there (the simulation, 0.3.25 too).
CORRECT_LANDING_S = 1.0
# A skip by the same person this soon after their last, near where that one is by now, is that skip settling:
# followed, not said again.
SETTLING_SKIP_MS = 6000
# Whoever starts a title from its beginning has played this little of it by the time the party hears: the start
# is said as 0:00, where the others open it too (the TV then needs no jump; Lucy, Dolby Vision, landed 1.8 s short).
FROM_THE_BEGINNING_S = 3.0
# A jump is judged once it has settled: the TV's position stands still for about a second after a jump and only
# settles by 4 s, so judging at 2 s taught it a lead 0.6 s too long.
JUMP_SETTLE_MS = 5000
PLAY_SETTLE_MS = 4000
# Who joined, left, lost or regained the connection is gathered this long and said together; news that cancels out
# meanwhile (left and came back) is not said at all. People joining one after another at the start of a bigger
# party were one notice each.
MEMBER_NEWS_MS = 2500
# PM4K's own skip, from its pause to its play.
SKIP_MS = 5000
# PM4K has finished opening a video once it has played normally for this long.
STEADY_MS = 500
# Stopping this close to the end is finishing, which does not pause the others.
FINISH_WINDOW_S = 60
# A party moves on to a different title only in its last minutes (same as the server).
NEXT_ITEM_WINDOW_S = 300
IDLE_STATUS_MS = 60_000
# A lost connection is said only while watching along with someone, and only once it has lasted this long: a
# server restart (an update) is back within seconds and needs no word.
OFFLINE_NOTICE_MS = 30_000
# A player already playing this close to where the party is, is left alone when a state is applied again.
IN_STEP_S = 0.3
# A jump following someone's skip that lands this far from the party (a keyframe) moves everyone to it instead: the
# precise players land where they aim, and line up in one more small jump (owner, 2026-10-18: "past 1 s off").
ALIGN_FOLLOW_S = 1.0
# Alone on the title, a device that pressed play reports where it plays this long after (once settled, see the
# server's LONE_SETTLED_MS): the party's clock follows it there.
LONE_REPORT_MS = 4500
# A while after every start (start, resume, rejoin, skip) the device reports exactly where it is, so the
# server can log how well the start was shared.
SYNC_CHECK_MS = 2000
# A viewer's skip that did not get through (its request failed, or the connection was already away) is sent once it is
# back, this soon and if the party has not changed meanwhile: the others follow, as if it had arrived late. Lost, the
# skipper played on 15 s, and once 350 s, from everyone without a word (the simulation with dropped requests). Past
# this, a reconnect moves nobody and a resync is offered instead.
UNSENT_SKIP_MS = 15_000
# An invitation shown during a film stays this long.
INVITATION_NOTICE_S = 15
# Someone started a title and the party waits for this device: said for CALL_S, and again every CALL_REPEAT_S
# until this device opens it or the party moves on (for CALL_MAX_S at most). Watching something else: a card for
# CALL_VIDEO_S, less often.
CALL_S = 20
CALL_REPEAT_S = 45
CALL_VIDEO_S = 10
CALL_REPEAT_VIDEO_S = 180
CALL_MAX_S = 600
# The resync offer holds as long as its card shows; past that a pause is a pause again (it turned a pause meant for
# everyone into a resync long after the card had gone), and it is offered again after a while if still apart.
OFFER_VALID_MS = 15_000
REOFFER_MS = 300_000
# An invitation that said "press pause to answer" waits this long for that pause.
PENDING_INVITATION_MS = 60_000
# A skip goes out at once; more skips within this time (scrubbing) are sent as one, once the viewer has settled.
SEEK_SETTLE_MS = 600
# A skip or pause that would leave the party where it already is changes nothing and is not sent (it is
# almost always this device's own follow-up coming back, not the viewer).
SAME_SPOT_S = 2.0

DEFAULT_SETTINGS = {'catchup_threshold_s': 15, 'status_interval_s': 5, 'countdown_s': 5, 'notice_s': 4,
                    'notices': 'essential', 'control': 'everyone', 'diagnostics': 'off', 'stay_online': '4'}
# Sync diagnostics (when the admin switches them on): how far this player is from the party this long after every
# start, resume, rejoin or skip; sent in batches small enough for the server's 2 KB request limit.
DIAG_SAMPLES_MS = (250, 500, 1000, 2000, 4000, 8000)
DIAG_FLUSH_MS = 3000
DIAG_BATCH_BYTES = 1500
DIAG_BATCH_EVENTS = 40
DIAG_KEEP = 400


class SendError(Exception):
    """The server refused a request, or could not be reached. `code` says which."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def _older(version, other):
    def parts(text):
        try:
            return tuple(int(p) for p in str(text).split('.')[:3])
        except ValueError:
            return None
    mine, theirs = parts(version), parts(other)
    return bool(mine and theirs and mine < theirs)


def _same_title(party_item, item):
    """The party's title, or another version of it (the server lists every version's file ID in `keys`)."""
    if not party_item or not item:
        return False
    return item.get('key') == party_item.get('key') or item.get('key') in (party_item.get('keys') or ())


def member_key(member):
    """Which member this is, from one update to the next. The server's own number for it; from an older server, the
    person and device name (but other people's device names are not sent, so all of one person's devices looked
    alike: the WAN test told "Sam stopped watching" eight times in a minute)."""
    return member.get('mid') or (member.get('person'), member.get('device_name'))


class Engine:
    def __init__(self, player, screen, send, clock, version='0.0.0', log=None, clock_info=None,
                 leave_old_party=False, learned=None, on_learned=None):
        self.version = version
        # Kodi just started: a watch party from before is left quietly instead of picked up (see on_state).
        self.leave_old_party = leave_old_party
        self.clock_info = clock_info
        self.diag_events = []
        self.diag_samples = []
        self.diag_sent = 0
        self.log = log or (lambda text: None)
        # What this device learned about its player before (by name, see learned.NAMES), kept with on_learned.
        self.learned = Learned(learned, on_learned)
        self.lined_up_seq = None  # the skip this device last lined up after (once a skip)
        self.skip_check = None
        self.jump_check = None
        self.jump_landing = None  # the last jump while playing: (its aim, where it landed, aligned)
        self.aligned_seq = None  # the party's change this device made by its align after a followed skip
        self.play_check = None
        self.update_told = False
        self.cannot_told = None
        self.last_item = None
        self.player = player
        self.screen = screen
        self.send = send
        self.clock = clock
        self.view = None
        self.settings = dict(DEFAULT_SETTINGS)
        self.applied = None
        self.fresh_start = False  # a video just started: the next state is followed, whoever changed it
        self.held = False  # the player is paused by the add-on itself (a hold), not by the viewer
        self.line_up_at = None  # a skip landed near the party, or a start was late: line up with it then
        self.member_news = None  # who joined, left, lost or regained the connection, said together (see _gather)
        self.applied_alone = False  # the last state was set aside alone in the party (applied once others are in)
        self.offer_at = 0
        self.offer_quiet_until = 0
        self.pending_invitation_at = 0
        self.movement = Movement(clock)  # whose move it was: our own pause, play or jump, or the viewer's
        self.skip_until = 0
        self.starting = False
        self.steady_since = None
        self.item = None
        self.offer = None
        self.fast = False
        self.pending_invitation = None
        self.seen_invitations = set()
        self.last_status = 0
        self.dnd = False
        self.online = True
        self.unsent_skip = None  # (party, seq, when, target) of a skip whose request failed (see UNSENT_SKIP_MS)
        self.unsent_resume = None  # (party, seq, when) of a play press whose request failed, likewise
        self.pending_seek = None
        self.last_seek_sent = -SEEK_SETTLE_MS
        self.sync_check = None
        self.calling = None
        self.awaiting_seq = None
        self.pm4k_skip = None
        self.early_hold = False  # paused at once as the party's title opened (_hold_at_start)
        self.last_skip_said = None  # (who, where, when) of the last "skipped to" said (_say_skip)
        self.offline_since = None
        self.offline_told = False
        self.paused_alone = False
        # The shared start: a countdown, getting into position, a landing (see start.py).
        self.start = Start(clock, player, screen, self.movement, self.learned, self._pause, self._play,
                           lambda spot, seq: self._send_playback('align', spot, seq=seq),
                           lambda: self.party()['playback']['seq'] if self.party() else None,
                           lambda: bool(self.item), self._diag, lambda text: self.log(text))

    # Reading the party -----------------------------------------------------

    def party(self):
        return (self.view or {}).get('party')

    def _on_party_item(self, party):
        return bool(self.item and party and _same_title(party.get('item'), self.item))

    def _expected(self, party, now):
        playback = party['playback']
        if playback['state'] == 'playing':
            return playback['position'] + max(0, now - playback['at']) / 1000.0
        return playback['position']

    def _near_end(self, party, now):
        duration = (party.get('item') or {}).get('duration')
        return bool(duration) and self._expected(party, now) >= duration - NEXT_ITEM_WINDOW_S

    def _may_control(self, party):
        return self.settings.get('control') != 'host' or party.get('i_am_host')

    def _my_person(self):
        return ((self.view or {}).get('me') or {}).get('person')

    def _waiting_text(self, party):
        return wording.waiting(party, self._my_person(), self._may_control(party))

    def _diagnosing(self):
        return self.settings.get('diagnostics') == 'on'

    def _diag(self, kind, **data):
        if not self._diagnosing():
            return
        event = {'k': kind, 't': int(self.clock())}
        for key, value in data.items():
            event[key] = round(value, 3) if isinstance(value, float) else value
        self.diag_events.append(event)
        del self.diag_events[:-DIAG_KEEP]

    NOT_SENT = {'paused': 'the party is already paused', 'samespot': 'the skip lands where the party already is'}

    def _not_sent(self, why):
        self.log('not sent: ' + self.NOT_SENT[why])
        self._diag('nx', why=why)

    def _sample_after(self, seq):
        """Measure how far this player is from the party at fixed moments after a start."""
        if self._diagnosing() and isinstance(seq, int):
            now = self.clock()
            self.diag_samples = [(now + delay, seq, delay) for delay in DIAG_SAMPLES_MS]

    def _take_samples(self, now):
        due = [s for s in self.diag_samples if s[0] <= now]
        if not due:
            return
        self.diag_samples = [s for s in self.diag_samples if s[0] > now]
        party = self.party()
        for _, seq, delay in due:
            if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                    or not self._on_party_item(party)):
                self.diag_samples = []
                return
            if self.player.paused():
                continue  # PM4K's own skip pauses for a moment: this sample only
            position = self.player.position()
            if position is not None:
                self._diag('sm', seq=seq, d=delay, err=int(round((position - self._expected(party, now)) * 1000)))

    def _flush_diag(self, now):
        if not self.diag_events or now - self.diag_sent < DIAG_FLUSH_MS or not self.online:
            return
        self.diag_sent = now
        batch = []
        if self.clock_info:
            batch.append(dict(self.clock_info(), k='ck', t=int(now)))
        size = 0
        while self.diag_events and len(batch) < DIAG_BATCH_EVENTS:
            size += len(json.dumps(self.diag_events[0], separators=(',', ':'))) + 1
            if size > DIAG_BATCH_BYTES and batch:
                break
            batch.append(self.diag_events.pop(0))
        try:
            self.send({'type': 'diag', 'events': batch})
        except SendError:
            pass  # diagnostics are best effort: a lost batch is not sent again

    # Player commands, remembered so their echo is not taken for the viewer ---

    def _pause(self):
        if not self.player.paused():
            self.movement.expect('paused')
            self.player.pause()
            self.held = True  # paused by the add-on (a hold), not by the viewer
            self.log('pause at {}'.format(self.player.position()))

    def _play(self):
        self.held = False
        if self.player.paused():
            self.movement.expect('resumed')
            self.player.play()
            self.log('play at {}'.format(self.player.position()))

    def _jumping(self, target):
        self.movement.jumped(target, not self.player.paused())

    def _jump_to(self, spot, followed=None):
        """Jump so the picture moves on from where the party is: `spot` is where it is now; the jump aims this
        device's own lead further, since the picture only moves that long after the jump starts. `followed`: the
        party's seq when this jump follows someone's skip (then a landing far off is said, see _align_after)."""
        # A playing player jumps while playing: pausing first would show up in Plex as a pause (and in anything
        # that listens to it, such as lights), and gives one more event to tell apart from the viewer.
        if self.player.paused():
            self.start.land(self.clock(), spot)
            return
        lead = self.learned.jump_lead()
        seconds = max(0.0, spot + lead)
        # Only the seek is ours: a jump while playing reports nothing else (the TV's and the laptop's diagnostics,
        # 67 jumps), and taking a pause or a play in the next seconds for ours swallowed the viewer's own.
        self.movement.expect('seek')
        self._jumping(seconds)
        began = self.clock()
        landed = self.player.jump(seconds)
        self.jump_landing = (seconds, landed, False)
        self.log('jump to {:.3f} (lead {:.2f}), landed at {}'.format(
            seconds, lead, 'an unknown spot' if landed is None else '{:.3f}'.format(landed)))
        self._diag('jp', to=float(seconds), lead=round(lead, 3), at=None if landed is None else float(landed),
                   **jump_trace(self.player))
        party = self.party()
        if party:
            # Once it has settled, see how far behind or ahead the jump landed and learn from it.
            self.jump_check = (party['playback']['seq'], self.clock() + JUMP_SETTLE_MS)
            if followed is not None and landed is not None:
                self._align_after(party, followed, spot, began, landed)

    def _align_after(self, party, seq, spot, began, landed):
        """A jump following someone's skip, landed (on a keyframe) ALIGN_FOLLOW_S or more from where the party will
        be once its picture moves: everyone plays from where this player will play instead, said to nobody. The
        box's Kodi lands a jump up to 4 s before its aim, and knows where some 0.4 s before the picture moves on;
        no lead can allow for it, the keyframes fall anywhere (owner, 2026-10-18: the precise players line up to it,
        past 1 s off; PLAN F2)."""
        plays_at = began + self.learned.jump * 1000  # when its picture moves on: the jump lead is that delay
        off = landed - (spot + (plays_at - began) / 1000.0)
        if abs(off) < ALIGN_FOLLOW_S or party['playback']['seq'] != seq or self._alone_on_title(party):
            return
        now = self.clock()
        here = landed + (now - plays_at) / 1000.0  # where it is on its own clock now (still before, while still)
        self.log('followed skip landed {:+.3f} s from the party: everyone plays from here'.format(off))
        self._diag('fa', seq=seq, off=float(off))
        result = self._send_playback('align', here, seq=seq)
        if result and isinstance(result.get('seq'), int) and result['seq'] != seq:  # (refused: said nothing)
            # The lesson then measures against this player's own timeline: what is off is its delay alone.
            self.jump_landing = self.jump_landing[:2] + (True,)
            self.jump_check = (result['seq'], now + JUMP_SETTLE_MS)
            self.aligned_seq = (party['id'], result['seq'])

    def _after_start(self, started, now):
        """What a start from hold or a landing leaves to the engine once the player plays: the notice kept for it,
        the play lesson (or, when it was late, a line-up once settled) and the report of where it is."""
        if started.say:
            self._tell(started.say, extra=True)
        if started.learn is not None:
            self.play_check = (started.learn, now + PLAY_SETTLE_MS)
        elif started.line_up:
            self.line_up_at = now + PLAY_SETTLE_MS
        self._started()

    def _measure(self, check, now, settle_ms):
        """(the change, how far off the party the player is now) for a check made once a move has settled, or None
        when the party has moved on, the player is not playing on its title, or its viewer moved it since."""
        seq, due = check
        if self.movement.jumped_since(due - settle_ms):
            # Its viewer skipped meanwhile, not reported yet: the laptop's skip back to the start, 2.5 s, came between
            # a jump of ours and its check, and taught it a lead 0.25 s too long (the next jump landed 0.35 s ahead:
            # the simulation, round 36). Misses over 5 s were already put down to something else.
            return None
        party = self.party()
        if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                or not self._on_party_item(party) or self.player.paused()):
            return None
        position = self.player.position()
        if position is None:
            return None
        return seq, position - self._expected(party, now)

    def _learn_jump(self, now):
        measure, self.jump_check = self._measure(self.jump_check, now, JUMP_SETTLE_MS), None
        if measure is None:
            return
        seq, error = measure
        # Judged before this lesson: the miss itself widens the spread, and the nephew's slow jump (1.69 s behind)
        # made his device "imprecise" just as it needed the line-up; he stayed behind 20 s (2026-10-16).
        precise = self.learned.precise()
        short = None
        if self.jump_landing and self.jump_landing[1] is not None:
            aim, landed, aligned = self.jump_landing
            if -LANDED_MOVE_S <= aim - landed <= LANDED_SHORT_MAX_S:
                short = aim - landed
                if aligned:
                    # Measured against where it said it would play: the miss had it stayed on the party's spot.
                    error += self.learned.shortfall - short
        lesson = self.learned.learn_jump(error, short)
        if lesson is None:
            return  # something else happened meanwhile (a skip, a stall): not a measure of the jump
        self.log('jump while playing landed {:+.3f} s from the party{}; lead {:.2f} -> {:.2f}'.format(
            error, '' if short is None else ', {:.3f} s short of its aim'.format(short), *lesson))
        self._diag('ls', err=float(error), lead=float(lesson[1]), sh=None if short is None else float(short))
        self._line_up_once(seq, now, precise)

    def _line_up_once(self, seq, now, precise):
        """After a skip has settled: a device that lands precisely (as known before this skip's lesson) lines up with
        the party once (PRECISE_JUMP_S)."""
        if precise and self.lined_up_seq != seq:
            self.lined_up_seq = seq
            self._line_up(now)

    def _learn_play(self, now):
        measure, self.play_check = self._measure(self.play_check, now, PLAY_SETTLE_MS), None
        if measure is None:
            return
        error = measure[1]
        lesson = self.learned.learn('play', error)
        if lesson is None:
            return
        self.log('start from hold landed {:+.3f} s from the party; play lead {:.2f} -> {:.2f}'.format(error, *lesson))
        self._diag('lp', err=float(error), lead=float(lesson[1]))

    def wake_in_ms(self):
        """When the engine next needs to run, if sooner than its usual pace (for precise starts)."""
        return self.start.wake_in_ms(self.clock())

    def _send(self, payload):
        if not self.online:
            # Nothing is queued while the server is away: on return, this device follows the party.
            return None
        try:
            result = self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)
            else:
                self._refused(error.code)
            return None
        return result

    def _tell(self, text, extra=False, person=None, seconds=None):
        """A notice. Extra ones (pressed play, back in sync, reachable again) only show if the admin chose All."""
        if extra and self.settings.get('notices') != 'all':
            return
        how = self.screen.notice(text, person=person, seconds=seconds)
        self._diag('nt', how=how, txt=text)

    def set_online(self, online):
        """Told by the connection (or found out by a failed send). Said only while watching along with someone,
        and a loss only once it has lasted (see _check_offline). Nothing is re-applied on return: playback is not
        moved for a blip, and a change meanwhile comes back with a new number anyway."""
        if online == self.online:
            return
        self.online = online
        if online:
            if self.offline_told:
                self._tell('Connection restored.', extra=True)
            self.offline_since, self.offline_told = None, False
        else:
            self.offline_since = self.clock()

    def _check_offline(self, now):
        party = self.party()
        if (self.offline_since is not None and not self.offline_told and now - self.offline_since >= OFFLINE_NOTICE_MS
                and party and self._watching_together(party)):
            self.offline_told = True
            self._tell('Connection to Watch Party lost. Playback continues on this device.')

    def _watching_together(self, party):
        """This device is on the party's title and someone else is on it too."""
        return self._on_party_item(party) and not self._alone_on_title(party)

    def needs_quick_pace(self):
        """Whether the service loop should run four times a second: only while something is under way here
        or while watching along with someone. Alone (or in no party) a video plays undisturbed."""
        if (self.start.busy() or self.starting or self.pm4k_skip or self.pending_seek or self.diag_samples
                or self.jump_check or self.play_check or self.skip_check):
            return True
        party = self.party()
        return bool(party and self.item and self._watching_together(party))

    def needs_quick_wake(self):
        """Whether the service loop should look for the player's news every BUSY_WAKE_S, not IDLE_WAKE_S: at its
        quick pace, and while a party with others in it waits or is paused, where the title may be opened any moment
        and is held as it starts (the early hold). Handled up to 0.25 s late, 0.1 to 0.3 s of the film played
        first: in the rig 8 of 8 times at 0.25 s, 0 of 8 at 0.05 s (PLAN F1)."""
        if self.needs_quick_pace():
            return True
        party = self.party()
        return bool(party and party['playback']['state'] in ('waiting', 'paused') and not self._alone_in_party(party))

    def _refused(self, code):
        text = wording.refused_during_playback(code, self.party())
        if text:
            self._tell(text)

    def _send_playback(self, kind, position, item=None, seq=None):
        payload = {'type': 'playback', 'kind': kind, 'item': item or self.item,
                   'position': round(max(0.0, position or 0.0), 3)}
        if seq is not None:
            payload['seq'] = seq  # the state this was measured against: the server ignores it once that moved on
        result = self._send(payload)
        if result is not None:
            self._clear_offer()
            if isinstance(result.get('seq'), int):
                # Until the party's state carries this change, the distance to it means nothing: right after
                # a skip this player is already there and the party not yet (it read as "28 seconds ahead").
                self.awaiting_seq = (result.get('party'), result['seq'])
        return result

    def _started(self):
        """Playback just started for the party: report how well in a moment."""
        party = self.party()
        if party:
            self.sync_check = (party['playback']['seq'], self.clock() + SYNC_CHECK_MS)
            self._sample_after(party['playback']['seq'])

    def _send_status(self, state=None, check=None):
        now = self.clock()
        self.last_status = now
        if state is None:
            state = 'idle' if not self.item else ('paused' if self.player.paused() else 'playing')
        payload = {'type': 'status', 'state': state}
        if state != 'idle':
            # When the position was read, so the server can tell how far this player is from the party.
            payload.update(item=self.item, position=round(self.player.position() or 0.0, 3), sampled_at=now)
            if check is not None:
                payload.update(check=check)
        if not self.online:
            return
        try:
            self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)

    def respond(self, party_id, accept):
        """The viewer answered an invitation. A refusal is said (it used to vanish without a word)."""
        result = self._send({'type': 'respond', 'party': party_id, 'accept': bool(accept)})
        self.log('answered {}: {}'.format('join' if accept else 'not now', 'ok' if result is not None else 'not done'))
        if result is None and accept and not self.online:
            # The server away (known before, or found out by this request): the press went nowhere.
            self._tell('Watch Party cannot be reached right now, so you did not join. The invitation waits in the '
                       'Watch Party menu.')

    def set_do_not_disturb(self, value):
        self.dnd = bool(value)

    # What the player reports -----------------------------------------------

    def on_local(self, name, position=None, target=None, seeking=False, speed=None, age_ms=0):
        """What the player reported. `age_ms`: how long ago Kodi raised it (events wait while the loop is busy, a
        request to the server held up, say); whether it is the echo of a command of ours goes by when it happened."""
        now = self.clock()
        happened = now - max(0, int(age_ms or 0))
        # In no party (and no invitation waiting for a pause to answer it) only the video is kept track of: nothing
        # is judged, sent or logged (the owner found "taken as the viewer: paused" in kodi.log, in no party).
        quiet = not self.party() and not self.pending_invitation
        if not quiet:
            self.log('event {} at {}{}{}'.format(name, position, ' target {}'.format(target) if target is not None
                                                 else '', ' (PM4K skip)' if seeking else ''))
            self._diag('ev', n=name, pos=position, tg=target, pm=bool(seeking), sp=speed)
        if name == 'started':
            self.starting, self.steady_since, self.item, self.fast = True, None, None, False
            self.held = False
            # A new start of a video, even of the same title (opened again, played from the beginning): once
            # steady, it follows the party again instead of counting the party's state as already applied, nor
            # taking the party's last change for its own and itself for already there.
            self.applied = None
            self.fresh_start = True
            self.skip_until = 0
            self.movement.new_video()
            self.unsent_skip = None  # a skip in the video before is not sent from this one (the simulation)
            self.unsent_resume = None
            self._forget_video_work()
            self._clear_offer()
            self.early_hold = self._hold_at_start()  # last: the video's fresh start forgets expected echoes
            return
        if name in ('stopped', 'ended'):
            self._stopped(name == 'ended', position)
            return
        if name == 'seek':
            self.movement.seek_reported(target, now, lambda: None if self.player.paused() else self.player.position())
        if self.starting and self.early_hold and name == 'resumed':
            # PM4K plays the video on as it finishes opening it (its resume): held again, the party still holds.
            self._diag('tk', n=name, how='opening')
            self._pause()
            return
        if self.starting or quiet:
            if not quiet:
                self._diag('tk', n=name, how='opening')  # PM4K still opening the video: nobody's move
            return
        if name == 'speed':
            if speed == 1:
                if self.fast:
                    self.fast = False
                    self._user_seek(position)
            else:
                self.fast = True
            return
        if name == 'paused' and seeking:
            # PM4K's own skip (its flag is up): never our echo, even if one of ours is expected.
            self.skip_until = now + SKIP_MS
            self._diag('tk', n=name, how='pm4kskip')
            return
        # A seek PM4K flags as its own skip is the viewer's too: our jumps never raise PM4K's flag. Taken for the
        # echo of a jump of ours seconds before (it landed within SEEK_ECHO_S of it), the viewer's skip was never
        # said, the device stayed seconds off the party, and the jump check learned from it (the simulation).
        if not (name == 'seek' and seeking) and self.movement.is_echo(name, happened,
                                                                     target if target is not None else position):
            self._diag('tk', n=name, how='ours')
            return
        self.log('taken as the viewer: {}'.format(name))
        # Who made each move, for the diagnostics (the owner, 2026-10-16: the cause had to be pieced together).
        self._diag('tk', n=name, how='viewer')
        if name == 'resumed' and self.start.landing and self.skip_until < now:
            # Play pressed while this player lands in a party that already plays ("Syncing"): it starts in step
            # within seconds anyway, so it is held again and left to land. Taken as a resume, it restarted the party
            # for everyone from the landing spot, seconds ahead: a pause and a skip nobody else asked for.
            self._pause()
            return
        if name in ('paused', 'resumed'):
            self.held = False  # paused or playing now because the viewer said so (a skip changes only where)
        if self.start.drop_landing():  # the viewer's own move: theirs from here
            if name == 'seek' and self.held and self.player.paused():
                # Held by the add-on for the landing it no longer makes: let go, it plays from where the viewer went.
                # (Left paused, the box sat held while the party played, its skip lost on the way: the simulation.)
                self._play()
        if name == 'resumed' and self.start.counting_down:
            self._pause()
            if self.skip_until >= now:
                # PM4K's own skip (pause, jump, play) during a countdown: not a press. Held again; the skip itself
                # moves the countdown's spot.
                self.skip_until = 0
                return
            # A press during a countdown (Kodi's pause is a toggle, so play and pause look the same) stops it.
            self._cancel_countdown()
            return
        if name == 'paused':
            self._user_pause(position)
        elif name == 'resumed':
            if self.skip_until >= now:
                self.skip_until = 0
                if self.pm4k_skip:
                    self.pm4k_skip['resumed_at'] = now
                party = self.party()
                playback = (party or {}).get('playback') or {}
                not_playing = (playback.get('state') in ('waiting', 'paused')
                               or (playback.get('state') == 'playing' and (playback.get('at') or 0) > now))
                if party and not_playing and self._on_party_item(party) and not self._alone_in_party(party):
                    # PM4K's skip ends playing, but it is a skip, not a press of play: the party still waits for the
                    # others, is paused, or counts down to its start, so it is held again (as in a countdown). It
                    # played on alone, and was paused and moved back once the party started; or, its countdown's
                    # update held up, it played from the skip 3 s before everyone (the release check of 0.3.23).
                    self._pause()
                return
            self._user_resume(position)
        elif name == 'seek' and not self.fast:
            spot = target if target is not None else position
            party = self.party()
            if (seeking and party and party['playback']['state'] == 'playing' and party['playback']['at'] <= now
                    and not self.start.counting_down):
                # PM4K's own skip while the party plays: said at once from where this device's PM4K skips land.
                # Held until PM4K played again, it reached the others 5 s late on every device that PM4K does not
                # pause around a skip (2026-10-16). Where it really lands is measured meanwhile (_measure_landing).
                change = (party['id'], party['playback']['seq'])
                # Which way, from where the party plays: the event's own position is the aim on some players.
                back = spot < self._expected(party, now)
                past_aim = self.learned.landing(back)
                predicted = spot + past_aim
                self._user_seek(spot, reported=position, past_aim=past_aim)
                if self._may_control(party) and self.pm4k_skip is None:  # not when held back to the very start
                    self.pm4k_skip = {'target': spot, 'predicted': predicted, 'back': back, 'since': now,
                                      'resumed_at': None, 'change': change}
                return
            self._user_seek(spot, reported=position)

    def _cancel_countdown(self):
        party = self.party()
        if self._on_party_item(party) and not self._may_control(party):
            # A guest pressing during a host-only countdown: refused, and the shared start goes on for this device
            # too (cancelled here only, everyone else started and this one stayed paused).
            self._refused('host_only')
            return
        at, position = self.start.cancel()
        if not self._on_party_item(party):
            return
        if self._send_playback('pause', position) is not None:
            self.screen.hold('You paused')
        else:
            # Not sent (the connection is away): the countdown stopped here only, and the others start. Said, as for
            # any pause that does not get through, and play rejoins the party where it is by then. (Said nothing,
            # the device stayed paused while the party played: the simulation with dropped requests.)
            self.paused_alone = True
            self.screen.hold('Paused on this device only. Watch Party cannot be reached right now.')

    def _user_pause(self, position):
        party = self.party()
        if not party and self.pending_invitation:
            invitation, self.pending_invitation = self.pending_invitation, None
            if self.clock() - self.pending_invitation_at <= PENDING_INVITATION_MS:
                self.screen.ask(invitation)
                return
            # Long after the notice: a pause is a pause (the invitation is in the menu).
        if not self._on_party_item(party):
            return
        if self.offer:
            self._catch_up(party)
            return
        if not self._may_control(party):
            self._play()
            self._refused('host_only')
            return
        if party['playback']['state'] == 'paused':
            self._not_sent('paused')
            return
        sent = self._send_playback('pause', position) is not None
        # Not sent (the connection is away): paused here only, while the party plays on.
        self.paused_alone = not sent
        if self._alone_on_title(party):
            return
        if sent:
            self.screen.hold('You paused')
        else:
            # Said, so nobody takes it for everyone pausing; play rejoins the party where it is by then.
            self.screen.hold('Paused on this device only. Watch Party cannot be reached right now.')

    @staticmethod
    def _alone_in_party(party):
        """Nobody else is in the party: nothing to wait for or start with, so the player is left alone. (As the server
        decides it: someone offline a while is still in the party and may be watching.)"""
        return not any(not m.get('me') for m in party.get('members', []))

    def _alone_on_title(self, party):
        """Nobody else in the party is on this title right now: pausing and playing are just this player's."""
        return not any(m.get('ready') and m.get('online') for m in party.get('members', []) if not m.get('me'))

    def _user_resume(self, position):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._pause()
            self._refused('host_only')
            return
        self.screen.clear_hold()
        playback = party['playback']
        paused_alone, self.paused_alone = self.paused_alone, False
        if self._alone_on_title(party):
            # Nobody to start with: it just plays; the party follows (the server starts it from here at once).
            # Before anything else: a lone player is never moved (it was jumped ahead by however long it had been
            # paused when that pause had not reached the server).
            result = self._send_playback('resume', position)
            if result is None and not self.online:
                self.unsent_resume = (party['id'], playback['seq'], self.clock())
            elif result and isinstance(result.get('seq'), int):
                # Once it has settled, it says exactly where it plays, and the party follows it there: pressed right
                # after a skip, the picture moves only once the skip has buffered (the box played 0.93 s behind the
                # party it had started, and whoever opened the title later followed the party: the simulation).
                self.sync_check = (result['seq'], self.clock() + LONE_REPORT_MS)
            return
        if paused_alone and playback['state'] == 'playing' and playback['at'] <= self.clock():
            # Paused here only (the connection was away) while the party played on: back into it, the others are
            # not moved.
            self._jump_to(self._expected(party, self.clock()))
            return
        # Everyone starts together a moment from now, this player included, so hold it until then.
        self._pause()
        if self._send_playback('resume', position) is None:
            self._play()

    def _measure_landing(self, now):
        """Where PM4K's skip, said at once, really landed: read once it plays (PM4K_LANDING_MS after its play, or
        after the skip when PM4K did not pause around it). Teaches the landing lead, and puts the party right if this
        player ended up CORRECT_LANDING_S or more from it."""
        skip = self.pm4k_skip
        if 'predicted' not in skip:
            self._send_held_skip(now)  # a skip back to the very start, held until it plays from there
            return
        if self._skipped_since(skip['change']):
            # Someone else skipped since and this player followed them: nothing of this skip to measure.
            self.pm4k_skip = None
            self.log('landing not measured: someone else skipped since')
            return
        settle = skip['resumed_at'] if skip['resumed_at'] is not None else skip['since']
        if now - settle < PM4K_LANDING_MS:
            return
        if self.player.paused():
            if now - skip['since'] > SKIP_MS:
                self.pm4k_skip = None  # it never played again: nothing to read
            return
        self.pm4k_skip = None
        here = self.player.position()
        if here is None:
            return
        landed = here - (now - settle) / 1000.0
        lesson = self.learned.learn_landing(skip['back'], landed - skip['target'])
        if lesson:
            self.log('PM4K skip {} aimed at {:.3f}, landed at {:.3f}; landing lead {:.2f} -> {:.2f}'.format(
                'back' if skip['back'] else 'forward', skip['target'], landed, *lesson))
        party = self.party()
        corrected = False
        playback = (party or {}).get('playback') or {}
        # Only against this skip itself, back from the server: measured against the state before it (its answer
        # held up), the player read 499 s off and was "put right" for nothing (a test, building W3).
        ours = (party and party['id'] == skip['change'][0] and playback.get('seq', 0) > skip['change'][1]
                and playback.get('kind') == 'seek' and playback.get('by_me'))
        # Alone on the title too: the others may open it any moment, before the server follows a lone player (the
        # PC 1.8 s after the box's skip, and everyone played 1.6 s off the box: the release check of 0.3.26). Alone
        # in the party, the server follows this player anyway.
        if (ours and self._on_party_item(party) and playback['state'] == 'playing' and playback['at'] <= now
                and not self._alone_in_party(party)):
            off = here - self._expected(party, now)
            if abs(off) >= CORRECT_LANDING_S:
                self.log('PM4K skip left this player {:+.3f} s off the party: put right'.format(off))
                self._send_seek(here, landed=True)
                corrected = True
            else:
                # Nearer, a precise player lines up once, as after any skip of its own (no skip lead lesson comes
                # for this one to do it: the simulation left the PC 0.7 s off, building F3).
                self._line_up_once(playback['seq'], now, self.learned.precise())
        self._diag('pk', aim=float(skip['target']), pred=float(skip['predicted']), at=float(landed),
                   cor=corrected, back=skip['back'])

    def _send_held_skip(self, now):
        """A skip back to the very start, said once it plays from there (or, should it not, where it was aimed)."""
        skip = self.pm4k_skip
        if self._skipped_since(skip['change']):
            # Someone else skipped while this one waited to be said, and this player followed them: theirs came
            # last. Said now, this older skip would take the party back from theirs (the simulation, round 35).
            self.pm4k_skip = None
            self.log('not sent: someone else skipped since')
            return
        if skip['resumed_at'] is not None and now - skip['resumed_at'] >= PM4K_LANDING_MS:
            self.pm4k_skip = None
            here = None if self.player.paused() else self.player.position()
            elsewhere = here is not None and abs(here - skip['target']) > SEEK_ECHO_S + (now - skip['since']) / 1000.0
            if elsewhere:
                # Nowhere near where it was aimed: moved by something else since (the add-on's landing, made before
                # the viewer's skip was reported: the simulation). Said where the viewer went.
                here = None
            self.log('skip aimed at {}, landed at {}'.format(skip['target'], here))
            if elsewhere:
                self._user_seek(skip['target'], since=skip['since'])
            else:
                self._user_seek(here if here is not None else skip['target'], landed=here is not None)
        elif now - skip['since'] > SKIP_MS:
            self.pm4k_skip = None
            self._user_seek(skip['target'], since=skip['since'])

    def _say_skip(self, playback, by, now):
        """"Sam skipped to 4:58.", unless it is Sam's last skip settling (a PM4K skip put right once it landed:
        CORRECT_LANDING_S): followed all the same, not said twice."""
        who = playback.get('by_person') or by
        last = self.last_skip_said
        self.last_skip_said = (who, playback['position'], now)
        if (last and last[0] == who and now - last[2] <= SETTLING_SKIP_MS
                and abs(playback['position'] - (last[1] + (now - last[2]) / 1000.0)) <= SEEK_ECHO_S):
            self.log('not said: {} skip settling'.format(by))
            return
        self._tell(wording.skipped(by, playback['position']), person=playback.get('by_person'))

    def _skipped_since(self, change):
        party = self.party()
        playback = (party or {}).get('playback') or {}
        return bool(party and party['id'] == change[0] and playback.get('seq', 0) > change[1]
                    and playback.get('kind') == 'seek' and not playback.get('by_me'))

    def _user_seek(self, target, landed=False, since=None, reported=None, past_aim=None):
        if self.pm4k_skip:
            # This viewer skipped again while PM4K's skip was measured: the newer one counts, and the older one's
            # landing is not read (held then, the older one went out after the newer: the owner's PC, 2026-10-16).
            self.pm4k_skip = None
            self.log('landing not measured: a newer skip on this device')
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            if party['playback']['state'] == 'playing':
                self._jump_to(self._expected(party, self.clock()))
            self._refused('host_only')
            return
        now = self.clock()
        playback = party['playback']
        where = self._expected(party, now) if playback['state'] == 'playing' else playback['position']
        if target is not None and abs(target - where) < SAME_SPOT_S:
            self._not_sent('samespot')
            if playback['state'] == 'playing':
                # Near, not on: once settled, this player (the one that skipped) lines up with the party; it was
                # left up to a second off, too little for the resync offer to notice.
                self.line_up_at = now + JUMP_SETTLE_MS
            return
        if (not landed and since is None and target is not None and target < self.learned.skip
                and not self.player.paused()):
            # Back to the very start: said a skip's time early, the spot would be before 0:00 (cut to 0:00, this
            # player then ran that far behind everyone). Said once it plays from there, like PM4K's skips. Whatever
            # the party's state as last heard: play pressed a moment before may not have come back yet (the party
            # still read "waiting", and the skip went out at once: 0.4 s behind).
            self.pm4k_skip = {'target': target, 'since': now, 'resumed_at': now,
                              'change': (party['id'], playback['seq'])}
            return
        if landed:
            self._send_seek(target, landed=True)  # where this player already plays: nothing to settle
        elif self.pending_seek is None and now - self.last_seek_sent >= SEEK_SETTLE_MS:
            # The first skip goes out at once, so the others follow now.
            self._send_seek(target, since=since, reported=reported, past_aim=past_aim)
        else:
            # More skips in a row (scrubbing): sent once the viewer settles, where they ended up.
            self.pending_seek = (target, now)

    def _send_unsent_resume(self, now):
        """Play pressed alone on the title as the connection dropped: it played on here while the party, never told,
        still waited; once others opened the title it started from the old spot and pulled this player back 25 s (the
        release check of 0.3.23). Sent once back, like a lost skip: the party then plays from here, at once."""
        party_id, seq, at = self.unsent_resume
        self.unsent_resume = None
        party = self.party()
        if (now - at > UNSENT_SKIP_MS or not party or party['id'] != party_id or party['playback']['seq'] != seq
                or not self._on_party_item(party) or self.player.paused() or not self._alone_on_title(party)
                or self.movement.moved_since(at)):
            return
        here = self.player.position()
        if here is not None:
            self.log('the play press that did not get through, sent again from {:.3f}'.format(here))
            self._send_playback('resume', here)

    def _send_unsent_skip(self, now):
        party_id, seq, at, target = self.unsent_skip
        self.unsent_skip = None
        party = self.party()
        if (now - at > UNSENT_SKIP_MS or not party or party['id'] != party_id or party['playback']['seq'] != seq
                or not self._on_party_item(party) or self.player.paused()
                or self.movement.moved_since(at)):
            # Too late, the party has moved on, or this player was moved to the party since (a state applied on
            # return): it follows the party from here. (Sent from where the add-on had put it, the TV "skipped" to
            # the party's own spot: the simulation.)
            return
        here = self.player.position()
        if here is None:
            return
        if target is not None and abs(here - target) > SEEK_ECHO_S + (now - at) / 1000.0:
            # Nowhere near where the viewer went: moved by the add-on before the skip was reported (a landing, the
            # simulation). Said where the viewer went; this player follows like the others.
            self.log('the skip that did not get through, sent again: {:.3f}'.format(target))
            self._send_seek(target, since=at)
            return
        self.log('the skip that did not get through, sent again from {:.3f}'.format(here))
        self._send_seek(here, landed=True)

    def _send_settled_seek(self, now):
        target, at = self.pending_seek
        if now - at < SEEK_SETTLE_MS:
            return
        self.pending_seek = None
        if not self._on_party_item(self.party()):
            return
        seen = self.movement.seen_near(target) if target is not None else None
        if seen is not None and seen < at:
            # Reported late: its time was read at the new spot before the report came. It landed then (said from
            # the report's moment, a skip reported 5 s late went out a skip's lead early and left the laptop 0.75 s
            # ahead: the simulation with Plex's timings, round 35).
            at = seen
        if not self.player.paused() and now - at >= self.learned.skip * 1000:
            # Said this long after the last skip, it has landed and plays: where it plays now is the spot, with no
            # skip time to allow for (taking it off again left the laptop 0.4 s ahead after scrubbing, and taught
            # it a wrong skip time). Unless it still reports where it was (see _moved_to).
            here = self._moved_to(target, slack_s=(now - at) / 1000.0)
            if here is not None and here != target:
                self._send_seek(here, landed=True)
                return
        self._send_seek(target, since=at)

    def _moved_to(self, target, slack_s=0.0):
        """Where this player plays after a skip to `target`: its own position once it has got there, else the
        target. Right after a skip a real Kodi streaming from Plex still reports where it was: two real Kodis in
        the rig, a skip to 5:00 went out as 0:23 and the others never moved (the stand-ins move at once). Its
        position counts as there within SEEK_ECHO_S of the target, plus however long it may have played since."""
        here = self.player.position()
        if here is None or self.player.paused() or target is None or abs(here - target) > SEEK_ECHO_S + slack_s:
            return target
        return here

    def _send_seek(self, target, landed=False, since=None, reported=None, past_aim=None):
        """`past_aim`: how far past `target` this player will play from, for a PM4K skip whose landing is measured
        (_measure_landing): that lesson is its own, so it teaches the skip lead nothing."""
        now = self.clock()
        self.last_seek_sent = now
        # Where this player is now, not where the skip landed: it may have played on meanwhile (since `since`).
        # Plus where it will land: passed in as the target, a prediction within SEEK_ECHO_S was taken for the
        # player's own reading, which still reads the aim, and every PM4K skip in 0.3.25 went out at its aim.
        spot = (self._moved_to(target, slack_s=(now - since) / 1000.0 if since else 0.0) or 0.0) + (past_aim or 0.0)
        party = self.party()
        # Its picture only moves on once the skip has landed. A measured PM4K landing already counts from PM4K's
        # play, as if it played from there at once: that wait is in it (the laptop's landings read -0.5 s, its lead).
        lead = self.learned.skip if past_aim is None else 0.0
        if not landed and since is None and reported is not None:
            # Kodi may report a skip late (1.7 s seen over the internet). Said a skip's lead early as if just made, it
            # put the party that far behind this player (the release check of 0.3.18: the laptop 0.4 s ahead). How
            # long ago it was made: it has played on from where the report says it was by more than a jump takes, or
            # the distance check read it at the new spot a while before the report came.
            here = self.player.position()
            own = self.movement.last_jump_at()
            seen = self.movement.seen_near(reported)
            # (By the skip's own time, not the lead said with it: none with a measured PM4K landing, and a float's
            # hair, 2900.0 read for 2899.9999999999995, dropped the landing: the simulation, building F2.)
            takes = self.learned.skip
            if (here is not None and not self.player.paused() and 0 < here - reported - takes <= REPORT_LATE_MAX_S
                    and own < now - (here - reported) * 1000):
                spot, lead = here, 0.0
            elif seen is not None and 0 < now - seen <= REPORT_LATE_MAX_S * 1000 and own < seen:
                lead = max(0.0, lead - (now - seen) / 1000.0)
        # Alone on the title and playing, the party plays with this player at once (the server starts it from here),
        # whatever the last update said: a skip right after play was pressed, the update for it held up, went out
        # without the lead and landed 0.4 s behind the party it had started (the simulation, round 34).
        plays_alone = (bool(party) and self._on_party_item(party) and self._alone_on_title(party)
                       and not self.player.paused())
        if landed:
            spot = target  # read while playing, where it really is: nothing to allow for
        elif party and (plays_alone or (party['playback']['state'] == 'playing'
                                        and (party['playback'].get('at') or 0) <= now)):
            # Its picture only moves on once the skip has landed: say where it will be on the party's clock.
            # (While the party is paused or counting down nothing moves, so the spot is the spot.)
            spot = max(0.0, spot - lead)
        result = self._send_playback('seek', spot)
        if result is None and not self.online and party:
            self.unsent_skip = (party['id'], party['playback']['seq'], now, target)
        if result and isinstance(result.get('seq'), int):
            # The skipper reports and learns too (the party's new number comes back in the answer).
            self.sync_check = (result['seq'], self.clock() + SYNC_CHECK_MS)
            if not landed and lead == self.learned.skip and past_aim is None:
                # Learnt only from a skip said at once (one reported late says nothing sure about the skip time).
                self.skip_check = (result['seq'], self.clock() + JUMP_SETTLE_MS)
            self._sample_after(result['seq'])

    def _learn_skip(self, now):
        measure, self.skip_check = self._measure(self.skip_check, now, JUMP_SETTLE_MS), None
        if measure is None:
            return
        seq, error = measure
        precise = self.learned.precise()
        lesson = self.learned.learn('skip', error)
        if lesson is None:
            return  # something else happened meanwhile: not a measure of the skip
        self.log('own skip landed {:+.3f} s from the party; skip lead {:.2f} -> {:.2f}'.format(error, *lesson))
        self._diag('lk', err=float(error), lead=float(lesson[1]))
        self._line_up_once(seq, now, precise)

    def _forget_video_work(self):
        """What belonged to the video that was playing: a skip still to be said, checks still to be made."""
        self.pm4k_skip = self.pending_seek = self.line_up_at = None
        self.jump_check = self.play_check = self.skip_check = None
        self.jump_landing = self.aligned_seq = None
        self.start.forget_video()
        self.diag_samples = []

    def _stopped(self, ended, position):
        was, self.item = self.item, None
        self._forget_video_work()
        self.last_item = was or self.last_item
        self.starting, self.pending_seek, self.sync_check = False, None, None
        self.start.cancel()
        self.screen.clear_hold()
        self._clear_offer()
        party = self.party()
        if party and was and _same_title(party.get('item'), was):
            duration = was.get('duration') or 0
            finished = ended or (duration and (position or 0) >= duration - FINISH_WINDOW_S)
            if not finished:
                self._send_playback('stop', position, item=was)
        if party:
            self._send_status('idle')

    # Housekeeping, about four times a second ---------------------------------

    def tick(self):
        now = self.clock()
        self.movement.expire(now)
        if self.starting:
            self._check_steady(now)
        for started in self.start.run(now):
            self._after_start(started, now)
        if self.member_news and now >= self.member_news['until']:
            self._say_member_news()
        if self.line_up_at is not None and now >= self.line_up_at:
            self._line_up(now)
        if self.pending_seek:
            self._send_settled_seek(now)
        if self.unsent_skip and self.online:
            self._send_unsent_skip(now)
        if self.unsent_resume and self.online:
            self._send_unsent_resume(now)
        if self.pm4k_skip:
            self._measure_landing(now)
        if self.calling:
            self._remind(now)
        if self.offline_since is not None:
            self._check_offline(now)
        if self.diag_samples:
            self._take_samples(now)
        if not self.start.near(now):
            self._flush_diag(now)
        self.start.check(now)
        if self.jump_check and now >= self.jump_check[1]:
            self._learn_jump(now)
        if self.play_check and now >= self.play_check[1]:
            self._learn_play(now)
        if self.skip_check and now >= self.skip_check[1]:
            self._learn_skip(now)
        if self.sync_check and now >= self.sync_check[1]:
            seq, self.sync_check = self.sync_check[0], None
            if self.item and not self.player.paused():
                self._send_status(check=seq)
        party = self.party()
        # Reported often only while watching along with someone; alone, now and then (and at every change).
        together = bool(self.item and party and self._watching_together(party))
        interval = self.settings['status_interval_s'] * 1000 if together else IDLE_STATUS_MS
        if party and now - self.last_status >= interval and not self.start.near(now):
            self._send_status()
        party = self.party()
        if party and self.item and not self.starting:
            self._watch_time(now)
            self._check_distance(party, now)

    def _hold_at_start(self):
        """The party's title just opened while the party waits or is paused: held at once, not after
        STEADY_MS of film (the nephew's video played 0.9 s, more with a late callback: PLAN D5). Read from Kodi's
        own labels, before PM4K has finished opening it."""
        party = self.party()
        if not party or self._alone_in_party(party) or self._newer_change_on_its_way(party):
            # (Its own change on its way: play pressed a moment before started the party; held "as it waits", the
            # box stayed held while the party it had started played on, the simulation found, 0.3.25 too.)
            return False
        # Waiting or paused only: a countdown may end before this player is steady, and then it joins playing (held
        # early, it stayed held after the start: a test of the countdown's end).
        holds = party['playback']['state'] in ('waiting', 'paused')
        item = self.player.item() if holds else None
        if not item or not _same_title(party.get('item'), item):
            return False
        self.log('opened the title the party holds: held at once')
        self._pause()
        return True

    def _check_steady(self, now):
        if (not self.player.video() or self.player.pm4k_busy()
                or (self.player.paused() and not self.early_hold)):
            self.steady_since = None
            return
        if self.steady_since is None:
            self.steady_since = now
            return
        if now - self.steady_since >= STEADY_MS:
            self.starting = False
            self.early_hold = False
            self.item = self.player.item()
            self._ready()
            self.fresh_start = False  # followed the party just now (if it is on its title); later states as usual

    def _ready(self):
        party = self.party()
        if not party:
            return  # in no party nothing is reported: the server uses what a device plays only in a party
        self._send_status()
        if not self.item:
            if not self._alone_in_party(party):
                self._tell('This video cannot be watched together: it is not playing directly from Plex.')
            return
        if self._on_party_item(party) and not self._alone_in_party(party):
            # Opened what the party is on: follow wherever it is now (paused, waiting or counting down holds this
            # player at once, before the server has even heard of it). Alone in the party there is nobody to
            # follow: the server takes this player's spot instead, and the player is left alone.
            self._follow(party)
        self._join_playback(party)

    def _join_playback(self, party):
        """Tell the server this device is on its title. The next update says what to do."""
        playback = party['playback']
        if (not self._on_party_item(party) and playback['state'] == 'playing'
                and not self._near_end(party, self.clock())):
            self._refused('party_busy')
            return
        # Playing (or counting down) on this title: following it just now started or scheduled this player, so it
        # is not held again here. (Comparing the moment with the clock here disagreed with that within 100 ms of a
        # start: the player was started, then held for a countdown that had ended, and never started again.)
        joins_playing = self._on_party_item(party) and playback['state'] == 'playing'
        alone = self._alone_in_party(party)
        here = self.player.position() or 0.0
        if here < FROM_THE_BEGINNING_S and not alone:
            here = 0.0  # opened from the beginning: said as the beginning, where everyone else opens it too
        # Nobody else online and a new title: the server starts it from here at once (nobody to wait for).
        nobody_here = not self._on_party_item(party) and not any(
            m.get('online') for m in party.get('members', []) if not m.get('me'))
        if self._send_playback('start', here) is not None and not joins_playing and not alone and not nobody_here:
            # The party will wait or count down on this title: hold now instead of playing on until it says so.
            # (Alone in the party it plays on untouched: the server starts the party from where it is.)
            self._pause()

    def _newer_change_on_its_way(self, party):
        return bool(self.awaiting_seq and self.awaiting_seq[0] == party['id']
                    and party['playback']['seq'] < self.awaiting_seq[1])

    def _watch_time(self, now):
        """Read the player every moment, to see its time jump (see Movement.read). Read whether or not anyone else is
        on the title (watching alone, the laptop's late skip was said a whole skip's lead early: the third release
        check of 0.3.18)."""
        self.movement.read(None if self.player.paused() else self.player.position(), now)

    def _check_distance(self, party, now):
        playback = party['playback']
        if self.awaiting_seq and self.awaiting_seq[0] == party['id'] and playback['seq'] < self.awaiting_seq[1]:
            return  # this device's own change is on its way back
        self.awaiting_seq = None
        if self._alone_on_title(party):
            # Nobody else on the title: nobody to be behind or ahead of (a stall while alone is the player's own).
            self._clear_offer()
            return
        if (playback['state'] != 'playing' or playback['at'] > now or not self._on_party_item(party)
                or self.player.paused() or self.movement.expecting_more_than_a_seek() or self.skip_until >= now
                or self.start.counting_down or self.pending_seek or self.fast or self.pm4k_skip):
            return
        position = self.player.position()
        if position is None:
            return
        # A skip may not be reported yet, or its viewer's skip waits to be sent again (the connection dropped as it
        # went out: "330 seconds behind", measured from the party's spot before it, the simulation, round 35):
        # nothing new is offered.
        quiet = (self.movement.quiet(now)
                 or (self.unsent_skip is not None and now - self.unsent_skip[2] <= UNSENT_SKIP_MS))
        distance = position - self._expected(party, now)
        threshold = self.settings['catchup_threshold_s']
        if distance < -threshold:
            wanted = 'behind'
        elif distance > threshold:
            wanted = 'ahead'
        elif abs(distance) < threshold / 2.0:
            wanted = None
        else:
            wanted = self.offer
        if self.offer and now - self.offer_at > OFFER_VALID_MS:
            # The card has gone: a pause is a pause again; offered again later if still this far apart.
            self.offer = None
            self.offer_quiet_until = now + REOFFER_MS
        if wanted and now < self.offer_quiet_until:
            wanted = None
        if wanted and wanted != self.offer and quiet:
            return  # taking an offer down needs no wait; making one does
        if wanted == self.offer:
            return
        self.offer = wanted
        self.offer_at = now
        if wanted:
            self._diag('of', how=wanted, off=float(distance))
        if wanted == 'behind':
            self.screen.offer(wording.offer(distance, party, self._my_person()))
        elif wanted == 'ahead':
            self.screen.offer(wording.offer(distance, party, self._my_person()))
        else:
            self.screen.clear_offer()

    def _catch_up(self, party):
        self._clear_offer()
        self._jump_to(self._expected(party, self.clock()))
        text = wording.back_in_sync(party, self._my_person())
        if not self.start.say_when_landed(text):  # said once it plays, not while it still waits to
            self._tell(text, extra=True)

    def _clear_offer(self):
        if self.offer:
            self.offer = None
            self.screen.clear_offer()

    # What the server reports -----------------------------------------------

    def on_state(self, view):
        previous, self.view = self.view, view
        self.settings.update({k: v for k, v in (view.get('settings') or {}).items() if k in DEFAULT_SETTINGS})
        if previous is None and self.leave_old_party:
            # Kodi just started: invitations already open are in the menu; asking them now would put a question
            # over whatever is starting (PM4K opening at boot, for one).
            self.seen_invitations.update((i['party'], i.get('at')) for i in view.get('invitations', []))
        if self.leave_old_party:
            party_now = view.get('party')
            if not party_now or (isinstance(self.leave_old_party, str) and party_now.get('id') != self.leave_old_party):
                # Nothing to leave, or a party other than the one to leave (joined from the menu meanwhile): kept.
                self.leave_old_party = False
            elif self._quietly_leave(view):
                return
        self._invitations(view)
        minimum = (view.get('addon') or {}).get('minimum')
        if minimum and not self.update_told and _older(self.version, minimum):
            self.update_told = True
            self._tell('A Watch Party update is required. Open Watch Party and choose Check for updates.')
        party, before = view.get('party'), (previous or {}).get('party')
        if before and not party:
            self._party_gone(before, view.get('last_end'))
        elif party and (not before or before['id'] != party['id']):
            self._joined(party, still=previous is None)
        elif party:
            self._membership(before, party)
        if party:
            self._follow(party)

    def left_for_standby(self):
        """Kodi is going to standby and has said goodbye: the party is forgotten without a word. Should the goodbye
        not have arrived, the party is left quietly once the device is back, as after Kodi starts. In no party, a
        standby means nothing (one noticed while the device was quiet would leave a party joined from the menu)."""
        if self.party():
            self.leave_old_party = self.party().get('id') or True  # that party only, not one joined after waking
        self.calling = None
        self.start.drop_landing(clear=False)
        if self.view and self.view.get('party'):
            self.start.cancel()
            self.screen.clear_hold()
            self._clear_offer()
            self.view = dict(self.view, party=None)

    def _quietly_leave(self, view):
        """Kodi just started and this device is still in a watch party from before: leave it without a word.
        True while that party is to be left (nothing of it is shown or followed)."""
        party = view['party']
        try:
            self.send({'type': 'leave'})
        except SendError as error:
            if error.code != 'not_in_party':
                self.log('watch party from before Kodi started not left yet: {}'.format(error.code))
                self.view = dict(view, party=None)
                return True
        self.leave_old_party = False
        self.log('left the watch party from before Kodi started ({})'.format(party['id'][:6]))
        self.view = dict(view, party=None)
        return True

    def _invitations(self, view):
        current = {i['party'] for i in view.get('invitations', [])}
        # Only invitations still listed are remembered: one that left the list never comes back with the same time
        # (invited again, it has a new one), and a connection lasts weeks on a TV (it grew by one an invitation).
        self.seen_invitations &= {(i['party'], i.get('at')) for i in view.get('invitations', [])}
        if self.pending_invitation and self.pending_invitation['party'] not in current:
            self.pending_invitation = None
        self.screen.withdraw_questions(current)
        for invitation in view.get('invitations', []):
            # By party and time: inviting again (after "Not now") is a new invitation and is asked again.
            key = (invitation['party'], invitation.get('at'))
            if key in self.seen_invitations or invitation.get('declined'):
                continue
            self.seen_invitations.add(key)
            self.log('invitation: do not disturb is on, not shown' if self.dnd else
                     'invitation: {}'.format('told during playback' if self.player.video() and not self.player.paused()
                                             else 'asked'))
            if self.dnd:
                continue
            text = wording.invited(invitation)
            if self.player.video() and not self.player.paused():
                # Long enough to read and act on during a film (a short notice was gone before anyone could).
                if view.get('party'):
                    self._tell(text + ' Open Watch Party to answer.', seconds=INVITATION_NOTICE_S)
                else:
                    self.pending_invitation = invitation
                    self.pending_invitation_at = self.clock()
                    self._tell(text + ' Press pause to answer.', seconds=INVITATION_NOTICE_S)
            else:
                self.screen.ask(invitation)

    def _party_gone(self, before, end):
        self.start.forget_video()
        self.member_news = None  # the party's end says it all
        # Joined again later (even the same party), its state is followed afresh.
        self.applied = None
        if self.held and self.player.paused():
            # Held for the party (its countdown, say), now gone: its own hold is undone, the viewer's pause is not.
            self._play()
        self.start.cancel()
        self.screen.clear_hold()
        self._clear_offer()
        end = end if end and end.get('party') == before.get('id') else {}
        reason = end.get('reason')
        if reason == 'left':
            self._tell('You left the watch party.')
        elif reason == 'ended' and end.get('by_me'):
            self._tell('You ended the watch party.')
        elif reason == 'ended' and end.get('by_name'):
            self._tell(wording.ended_by(end['by_name']))
        elif reason == 'idle':
            self._tell('The watch party ended because nothing was played for a while.')
        elif reason == 'gone':
            self._tell('This device was out of reach for a while and is no longer in the watch party.')
        else:
            self._tell('The watch party has ended.')

    def _joined(self, party, still=False):
        if still:
            # Kodi (or Watch Party) just started and this device is still in a party.
            self._tell(wording.in_party(party, self._my_person(), still=True))
        elif not (party.get('i_am_host') and len(party.get('members', [])) == 1):
            # Starting one is said by the menu, together with who was invited.
            self._tell(wording.in_party(party, self._my_person()))
        if self.item and not self.starting:
            self._send_status()  # nothing was reported outside the party: what this player plays, now
            self._join_playback(party)

    def _membership(self, before, party):
        key = member_key
        old = {key(m) for m in before.get('members', [])}
        new = {key(m) for m in party.get('members', [])}
        was_online = {key(m): m.get('online') for m in before.get('members', [])}
        joined, lost, back = [], [], []
        for member in party.get('members', []):
            if member.get('me'):
                continue
            if key(member) not in old:
                joined.append(member)
            elif was_online.get(key(member)) and not member.get('online'):
                lost.append(member)
            elif was_online.get(key(member)) is False and member.get('online'):
                back.append(member)
        left = [m for m in before.get('members', []) if key(m) not in new and not m.get('me')]
        # Someone closed the video while the party plays on (the admin chose to keep playing when someone closes
        # it): said, nothing paused. (Paused for everyone, the party's state says it instead.)
        was_ready = {key(m): m.get('ready') for m in before.get('members', [])}
        same_title = (before.get('item') or {}).get('key') == (party.get('item') or {}).get('key')
        if same_title and party['playback']['state'] == 'playing' and self._on_party_item(party):
            closed = [m for m in party.get('members', []) if not m.get('me') and was_ready.get(key(m))
                      and not m.get('ready')]
            if closed:
                self._tell(wording.stopped_watching_members(closed, self._my_person()),
                           person=[m.get('person') for m in closed])
        # Several at once (a big party) are said once, with their pictures.
        self._gather(joined=joined, lost=lost, back=back, left=left)

    def _gather(self, **groups):
        """Membership news, said together a moment later (see MEMBER_NEWS_MS)."""
        if not any(groups.values()):
            return
        news = self.member_news or {'until': self.clock() + MEMBER_NEWS_MS, 'joined': {}, 'lost': {}, 'back': {},
                                    'left': {}}
        opposite = {'joined': 'left', 'left': 'joined', 'lost': 'back', 'back': 'lost'}
        for kind in ('joined', 'lost', 'back', 'left'):
            for member in groups.get(kind) or ():
                key = member_key(member)
                if kind == 'left':
                    news['lost'].pop(key, None)  # "lost connection" then "left": only that they left
                    news['back'].pop(key, None)
                if news[opposite[kind]].pop(key, None) is None:
                    news[kind][key] = member  # anything else cancels out: back where they were
        self.member_news = news

    def _say_member_news(self):
        news, self.member_news = self.member_news, None
        for kind, words, extra in (('joined', 'joined the watch party', False), ('lost', 'lost connection', False),
                                   ('back', 'reconnected', True), ('left', 'left the watch party', False)):
            group = list(news[kind].values())
            if group:
                self._tell(wording.member_news(group, self._my_person(), words), extra=extra,
                           person=[m.get('person') for m in group])

    def _follow(self, party):
        playback = party['playback']
        item_key = (party.get('item') or {}).get('key')
        if party.get('cannot_watch') and item_key and self.cannot_told != item_key and self._on_party_item(party):
            self.cannot_told = item_key
            self._tell(wording.cannot_watch(party['cannot_watch']))
        # A state is applied once per title this device plays, so opening the party's title
        # after a change still brings this player to where the party is.
        key = (party['id'], playback['seq'], (self.item or {}).get('key'))
        company_came = (self.applied_alone and self._on_party_item(party) and not self.starting
                        and not self._alone_in_party(party))
        if key != self.applied or company_came:
            # A state set aside while alone in the party is followed once someone else is in it (only who was in
            # the party changed, not its state, so it was never applied again: 217 s apart in the simulation).
            self.applied = key
            self._apply(party, playback)
        elif (self._on_party_item(party) and not self.starting and self._alone_in_party(party)
              and (self.start.counting_down or self.start.landing or (self.held and self.player.paused()))):
            # The others left (only who is in the party changed): alone now, nothing to hold for.
            self._alone_now()
        elif playback['state'] == 'waiting' and self._on_party_item(party):
            self.screen.hold(self._waiting_text(party), until_cleared=True)

    def _say_call(self, text, person):
        """Kodi's notification outside video, a card during another video. Returns (shown for, say again after)."""
        if self.player.video():
            self._tell(text, person=person, seconds=CALL_VIDEO_S)
            return CALL_VIDEO_S, CALL_REPEAT_VIDEO_S
        self._tell(text, person=person, seconds=CALL_S)
        return CALL_S, CALL_REPEAT_S

    def _call(self, party, playback, by):
        """Someone started a title: say so, and keep saying it until this device opens it or it stops applying."""
        now = self.clock()
        if party.get('can_watch') is False:
            # Nothing to do about it: said once.
            self._tell(wording.starting(party, by, self.last_item, self.clock()), person=playback.get('by_person'))
            self.calling = None
            return
        seconds, repeat = self._say_call(wording.starting(party, by, self.last_item, self.clock()), playback.get('by_person'))
        self.calling = {'party': party['id'], 'key': party['item']['key'], 'since': now, 'next': now + repeat * 1000,
                        'by': by, 'person': playback.get('by_person'), 'shown_until': now + seconds * 1000}

    def _remind(self, now):
        call, party = self.calling, self.party()
        still = (party and party['id'] == call['party'] and (party.get('item') or {}).get('key') == call['key']
                 and party['playback']['state'] in ('waiting', 'playing') and not self._on_party_item(party)
                 and not self.starting and now - call['since'] < CALL_MAX_S * 1000)
        if not still:
            self.calling = None
            if now < call['shown_until']:
                self.screen.clear_notice()  # opened it, or the party moved on: the call no longer applies
            return
        if now < call['next']:
            return
        text = wording.call(party, call['by'])
        seconds, repeat = self._say_call(text, call['person'])
        call.update(next=now + repeat * 1000, shown_until=now + seconds * 1000)

    def _me_ready(self, party):
        return any(m.get('ready') for m in party.get('members', []) if m.get('me'))

    def _line_up(self, now):
        self.line_up_at = None
        party = self.party()
        if (not party or not self._on_party_item(party) or self.player.paused() or self.start.counting_down
                or self.start.landing
                or party['playback']['state'] != 'playing' or party['playback']['at'] > now
                or self._alone_on_title(party)):
            return
        position = self.player.position()
        expected = self._expected(party, now)
        if position is not None and IN_STEP_S < abs(position - expected) < SAME_SPOT_S + 1:
            self.log('lined up with the party: {:+.3f} s off'.format(position - expected))
            self._diag('lu', off=float(position - expected))
            self._jump_to(expected)

    def _alone_now(self):
        """Alone in the party (now, or as just learnt): nothing is held for anyone. A countdown or a landing still
        under way is dropped, and a hold of the add-on's own (made while others were there) is undone; a viewer's
        pause never is. The party is told where this player is: it may have started from where this player was
        before the hold."""
        self.start.drop(with_check=True)
        self.screen.clear_hold()
        if self.held and self.player.paused():
            self._play()
            self._send_playback('resume', self.player.position())

    def _near(self, party, playback, now):
        """This player is about where the party is (its own skip lands within SAME_SPOT_S of what it said)."""
        mine = self.player.position()
        if mine is None:
            return True
        there = self._expected(party, now) if playback['state'] == 'playing' else playback['position']
        return abs(mine - there) < SAME_SPOT_S

    def _apply(self, party, playback):
        now = self.clock()
        by, kind = wording.actor(playback, self._my_person()), playback.get('kind')
        self.log('party {} #{} {} at {} ({} ms){}'.format(playback['state'], playback['seq'], kind, playback['position'],
                                                        (playback.get('at') or now) - now,
                                                        ' by me' if playback.get('by_me') else ''))
        self._diag('ap', seq=playback['seq'], kd=kind, st=playback['state'], pos=float(playback['position']),
                   inms=int((playback.get('at') or now) - now), me=self.player.position(), pz=self.player.paused(),
                   mine=bool(playback.get('by_me')), on=self._on_party_item(party))
        if not self._on_party_item(party) or self.starting:
            # The party moved to another title during a countdown: this one no longer starts.
            self.start.drop()
            if (kind == 'start' and not playback.get('by_me') and playback['state'] in ('waiting', 'playing')
                    and not self.starting and party.get('item')):
                self._call(party, playback, by)
            return
        self.start.drop_landing()  # the party moved on: this state decides now
        self.applied_alone = self._alone_in_party(party)
        if self.applied_alone:
            # The only one in the party: the server follows this player, never the other way round. Nothing is
            # held, moved or said for the party's state, which is this player's own. (The TV paused, showed the
            # waiting text and jumped each time it opened the title again alone.)
            self._alone_now()
            return
        counting_down = playback['state'] == 'playing' and (playback.get('at') or 0) > now + 100
        if (playback.get('by_me') and kind in ('pause', 'seek') and not counting_down and not self.fresh_start
                and self._near(party, playback, now) and self.player.paused() == (playback['state'] != 'playing')):
            # This device's own pause or skip coming back: it is already there. (One made during a countdown still
            # has to be held for the shared moment, so it goes on below; a title opened again since is not there, so
            # it follows like any other; and a player still held for a start that has passed meanwhile, its own
            # skip during the countdown arriving late, is not there either: it starts late.)
            self.start.cancel()
            if kind == 'pause' and self.paused_alone:
                # Its pause reached the party after all (the answer was lost on the way back): everyone paused, not
                # this device only, as it had said.
                self.paused_alone = False
                self.screen.hold('You paused')
            return
        state = playback['state']
        if state == 'paused':
            self.start.cancel()
            self.screen.clear_hold()
            self._pause()
            if playback.get('by_me'):
                if kind == 'stopped' and any(not m.get('ready') for m in party.get('members', []) if not m.get('me')):
                    # Back on the title after closing it, while someone else is still away.
                    self.screen.hold(self._waiting_text(party), until_cleared=True)
                else:
                    # Paused by this device (closed, or paused by choice): nothing starts by itself.
                    self.screen.hold('You paused. Press play to continue.')
            else:
                if kind == 'stopped':
                    self.screen.hold(wording.stopped_watching(by, self._may_control(party),
                                                              wording.own_device(playback, self._my_person())))
                elif kind == 'seek':
                    self._say_skip(playback, by, now)
                else:
                    self.screen.hold(wording.paused(by))
        elif state == 'playing':
            self.screen.clear_hold()
            if playback['at'] > now + 100:
                self.start.begin(playback['at'], playback['position'], kind)
                if kind == 'rejoin' and not playback.get('by_me'):
                    self._tell(wording.returned(by), person=playback.get('by_person'))
                elif kind == 'resume' and not playback.get('by_me'):
                    self._tell(wording.resumed(by), extra=True)
                elif kind == 'seek' and not playback.get('by_me'):
                    self._say_skip(playback, by, now)
                return
            self.start.cancel()
            # Read now: the update thread may bring this between the viewer's skip and the next reading of the time.
            self._watch_time(now)
            mine = None if self.player.paused() else self.player.position()
            if mine is not None and abs(mine - self._expected(party, now)) <= IN_STEP_S:
                # Already playing where the party is (the same state again, after a reconnect): leave it be.
                self.log('already in step')
            elif playback.get('by_me') and kind == 'align' and self.aligned_seq == (party['id'], playback['seq']):
                # Its own word that the party plays where this player landed after a skip: it is there (moved again,
                # it would land on a keyframe as far off once more). That align only: an older one of its own (when
                # it got into position for a start) left the TV at 0:18 as the party played at 5:57, opened again
                # (the simulation, building F2).
                self.log('not moved: the party plays where this player landed')
            elif playback.get('by_me') and kind == 'seek' and self.pm4k_skip and 'predicted' in self.pm4k_skip:
                # Its own PM4K skip, said at once, back while PM4K still lands it (paused, on a keyframe): moved now,
                # the player would be jumped in the middle of PM4K's skip. Measured once it plays (_measure_landing).
                self.log('not moved: its PM4K skip is still landing')
            elif playback.get('by_me') and kind == 'seek' and (self.movement.not_reported(now) or self.pending_seek
                                                                or self._newer_change_on_its_way(party)):
                # Its viewer has skipped again since, not reported yet (the internet simulation, U2), or reported and
                # not said yet or not back yet (two skips reported together, the second held as scrubbing: the
                # simulation with Plex's timings, round 35): not pulled back to the earlier skip, and then moved again
                # once the newer one comes.
                self.log('not moved: its viewer skipped again since')
            else:
                followed = playback['seq'] if kind == 'seek' and not playback.get('by_me') else None
                self._jump_to(self._expected(party, now), followed=followed)
                self._started()
            if not playback.get('by_me'):
                if kind == 'seek':
                    self._say_skip(playback, by, now)
                elif kind == 'resume':
                    self._tell(wording.resumed(by), extra=True)
        elif state == 'waiting':
            # Back to waiting (a finished title opened again): any countdown before it no longer applies.
            self.start.cancel()
            self._pause()
            # On screen for as long as the wait lasts (it used to leave after a few seconds).
            self.screen.hold(self._waiting_text(party), until_cleared=True)
            if not self._me_ready(party):
                # On the party's title but not counted as ready (the party moved titles meanwhile): say so again.
                self._send_playback('start', self.player.position() or 0.0)
