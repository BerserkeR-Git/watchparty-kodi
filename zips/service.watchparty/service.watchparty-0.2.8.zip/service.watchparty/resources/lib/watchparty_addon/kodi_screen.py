"""What Watch Party shows on screen.

During a video, cards are drawn straight onto the player window. Measured on the
CoreELEC box, that leaves the remote with PM4K; a dialog would take it. Outside a
video, Kodi's own notifications are used. Questions (invitations) are dialogs and
are only asked when nothing is playing or the viewer has paused.
"""
import math
import os
import tempfile
import threading
import time

import xbmc
import xbmcgui

from . import card_art
from .engine import device_label

HEADING = 'Watch Party'
PLAYER_WINDOW = 12005
CARD_TINT = 'E6101418'
TITLE_COLOUR = 'FFFFFFFF'
BODY_COLOUR = 'CCFFFFFF'
REPEAT_QUIET_S = 30
# Kodi's own notification beside an invitation question; closed as soon as it is answered.
INVITATION_TOAST_MS = 120_000

# Positions on a 1920 x 1080 window; scaled to the window's real size. One card at a time, top right.
EDGE = {'top': 32, 'right': 32}
COUNTDOWN = {'size': 180}
# Kodi's label alignment: left, centred vertically.
ALIGN_LEFT_MIDDLE = 0x00000004


class Card:
    """A set of controls drawn onto the player window, removable as one."""

    def __init__(self, window, controls):
        self.window = window
        self.controls = controls

    def remove(self):
        try:
            self.window.removeControls(self.controls)
        except Exception:  # noqa: BLE001 - the window may already be gone
            pass


class Screen:
    """One card at a time in the top right corner.

    A lasting card says why playback is held (paused, waiting, an offer to catch up) and leaves after a while.
    A notice takes the corner for a few seconds; a lasting card that still applies comes back after it.
    """

    def __init__(self, addon_path, clock, notice_seconds, on_answer, avatar=None, card_folder=None, log=None):
        media = os.path.join(addon_path, 'resources', 'media')
        self.card_folder = card_folder or os.path.join(tempfile.gettempdir(), 'watchparty-cards')
        self.square_image = os.path.join(media, 'countdown.png')
        self.mark_image = os.path.join(media, 'mark.png')
        self.mask_image = os.path.join(media, 'avatar-mask.png')
        self.avatar = avatar or (lambda person: None)
        self.icon = os.path.join(addon_path, 'resources', 'icon.png')
        self.clock = clock
        self.notice_seconds = notice_seconds
        self.on_answer = on_answer
        self.log = log or (lambda text: None)
        self.lock = threading.RLock()
        self.shown = None
        self.steady = None
        self.countdown_at = None
        self.last_notice = ('', 0.0)
        self.last_hold = ('', 0.0)

    # Drawing -------------------------------------------------------------

    @staticmethod
    def _player_window():
        if xbmcgui.getCurrentWindowId() != PLAYER_WINDOW:
            return None
        return xbmcgui.Window(PLAYER_WINDOW)

    def _draw_card(self, text, person=None):
        window = self._player_window()
        if window is None:
            return None
        scale = window.getHeight() / 1080.0
        shape = card_art.layout(text)
        try:
            image = card_art.card_image(self.card_folder, shape['width'], shape['height'])
        except OSError:
            return None
        width, height = int(shape['width'] * scale), int(shape['height'] * scale)
        x = int(window.getWidth() - (shape['width'] + EDGE['right']) * scale)
        y = int(EDGE['top'] * scale)
        icon_x, icon_y, icon = (int(v * scale) for v in shape['icon'])
        text_x, text_y, text_w = (int(v * scale) for v in shape['text'])
        line_h = int(card_art.LINE_H * scale)
        picture = self.avatar(person) if person else None
        controls = [xbmcgui.ControlImage(x, y, width, height, image, colorDiffuse=CARD_TINT)]
        if picture:
            # Kodi cannot crop to a circle; card-coloured corners on top make the picture read as round.
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, picture, aspectRatio=1))
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mask_image))
        else:
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mark_image))
        for number, line in enumerate(shape['lines']):
            controls.append(xbmcgui.ControlLabel(x + text_x, y + text_y + number * line_h, text_w, line_h, line,
                                                 font='font12', textColor=TITLE_COLOUR,
                                                 alignment=ALIGN_LEFT_MIDDLE))
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001 - the player closed in between
            return None
        # Something drawn over the player window (PM4K's own controls are a dialog) would hide the card.
        self.log('card drawn, dialog on top: {}'.format(xbmcgui.getCurrentWindowDialogId()))
        return Card(window, controls)

    def _show(self, kind, text, person, seconds):
        self._take_down()
        card = self._draw_card(text, person)
        if card is None:
            return False
        timer = threading.Timer(seconds, self._expire, args=(card,))
        timer.daemon = True
        self.shown = {'kind': kind, 'card': card, 'timer': timer}
        timer.start()
        return True

    def _take_down(self):
        if self.shown:
            self.shown['timer'].cancel()
            self.shown['card'].remove()
            self.shown = None

    def _expire(self, card):
        with self.lock:
            if not self.shown or self.shown['card'] is not card:
                return
            kind = self.shown['kind']
            self._take_down()
            if kind == 'notice':
                self._bring_back_steady()
            else:
                self.steady = None

    def _bring_back_steady(self):
        if not self.steady:
            return
        left = self.steady['end'] - time.monotonic()
        if left > 0.5:
            self._show('steady', self.steady['text'], None, left)
        else:
            self.steady = None

    # What the engine calls -------------------------------------------------

    def notice(self, text, person=None, seconds=None):
        now = time.monotonic()
        with self.lock:
            if text == self.last_notice[0] and now - self.last_notice[1] < REPEAT_QUIET_S:
                return
            self.last_notice = (text, now)
            seconds = seconds or self.notice_seconds()
            if self._show('notice', text, person, seconds):
                return
        xbmcgui.Dialog().notification(HEADING, text, self.icon, int(seconds * 1000), False)

    def _lasting_seconds(self):
        return max(8, 2 * self.notice_seconds())

    def _lasting(self, text):
        seconds = self._lasting_seconds()
        with self.lock:
            self.steady = {'text': text, 'end': time.monotonic() + seconds}
            if self.shown and self.shown['kind'] == 'notice':
                return  # it comes up once the notice has had its time
            if self._show('steady', text, None, seconds):
                return
        xbmcgui.Dialog().notification(HEADING, text, self.icon, int(seconds * 1000), False)

    def offer(self, text):
        # Shown once for a while, not left on screen: pressing pause still catches up afterwards.
        self._lasting(text)

    def clear_offer(self):
        with self.lock:
            self.steady = None
            if self.shown and self.shown['kind'] == 'steady':
                self._take_down()

    def hold(self, text):
        """Why playback is paused or waiting. Shown for a while, then out of the way; not repeated unchanged."""
        now = time.monotonic()
        with self.lock:
            if text == self.last_hold[0] and now - self.last_hold[1] < self._lasting_seconds() + REPEAT_QUIET_S:
                return
            self.last_hold = (text, now)
        self._lasting(text)

    def clear_hold(self):
        with self.lock:
            self.last_hold = ('', 0.0)
        self.clear_offer()

    def close(self):
        """Take everything off the screen and forget it (the connection ended)."""
        with self.lock:
            self.steady = None
            self._take_down()
            self.countdown_at = None

    def countdown(self, at, caption='Starting'):
        with self.lock:
            self.countdown_at = at
        threading.Thread(target=self._run_countdown, args=(at, caption), name='watchparty-countdown',
                         daemon=True).start()

    def clear_countdown(self):
        with self.lock:
            self.countdown_at = None

    def _run_countdown(self, at, caption_text):
        window = self._player_window()
        if window is None:
            return
        scale = window.getHeight() / 1080.0
        size = int(COUNTDOWN['size'] * scale)
        x, y = (window.getWidth() - size) // 2, (window.getHeight() - size) // 2
        number = xbmcgui.ControlLabel(x, y + int(26 * scale), size, int(96 * scale), '', font='font_clock',
                                      textColor=TITLE_COLOUR, alignment=0x00000002)
        caption = xbmcgui.ControlLabel(x, y + int(124 * scale), size, int(34 * scale), caption_text,
                                       font='font10', textColor=BODY_COLOUR, alignment=0x00000002)
        controls = [xbmcgui.ControlImage(x, y, size, size, self.square_image, colorDiffuse=CARD_TINT), number, caption]
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001
            return
        card = Card(window, controls)
        try:
            while True:
                with self.lock:
                    if self.countdown_at != at:
                        break
                left = (at - self.clock()) / 1000.0
                if left <= 0:
                    break
                number.setLabel(str(int(math.ceil(left))))
                time.sleep(0.1)
        finally:
            card.remove()

    def ask(self, invitation):
        threading.Thread(target=self._ask, args=(invitation,), name='watchparty-question', daemon=True).start()

    def _ask(self, invitation):
        if invitation.get('from_me'):
            text = 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
        else:
            others = [p for p in invitation.get('people', []) if p and p != invitation.get('from')]
            text = '{} invited you to a watch party'.format(invitation.get('from') or 'Someone')
            text += ' with {}.'.format(', '.join(others)) if others else '.'
        item = invitation.get('item')
        if item and invitation.get('can_watch') is False:
            text += '[CR]They are watching a title you do not have access to.'
        elif item:
            text += '[CR]They are watching {}.'.format(item.get('show') or item.get('title') or '')
        # Kodi's own notification as well: it shows above every add-on window, should PM4K's screens hide the
        # question (the owner saw nothing on the CoreELEC box at times).
        # It stays until the question is answered (closed below), so the viewer can see who is asking.
        xbmcgui.Dialog().notification(HEADING, text.split('[CR]')[0], self.icon, INVITATION_TOAST_MS, True)
        self.log('invitation question shown, dialog on top: {}'.format(xbmcgui.getCurrentWindowDialogId()))
        answer = xbmcgui.Dialog().yesno(HEADING, text, nolabel='Not now', yeslabel='Join')
        xbmc.executebuiltin('Dialog.Close(notification,true)')
        self.log('invitation answered: {}'.format('join' if answer else 'not now'))
        self.on_answer(invitation['party'], bool(answer))
