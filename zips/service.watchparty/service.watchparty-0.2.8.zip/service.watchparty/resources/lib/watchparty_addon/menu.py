"""The Watch Party menu, opened from Add-ons. Uses Kodi's own dialogs so it matches the skin."""
import json
import os
import threading
import time
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import shortcut, updates
from .avatars import Avatars
from .client import AddressProblem, Client
from .engine import SendError, describe, device_label

HEADING = 'Watch Party'
RELOAD_PROPERTY = 'watchparty.reload'
# Ready-made shortcuts. Kodi cannot tell a long press of a remote button from a short one, so none of these
# is a long press; Red opens TV channels by default, which nobody watching Plex through PM4K needs.
PRESETS = (
    ('altp', 'Alt+P on a keyboard', {'kind': 'keyboard', 'code': shortcut.ALT_P}),
    ('red', 'The red button on a remote (instead of TV channels)', {'kind': 'remote', 'name': 'red'}),
)
# Keys nobody should lose (Kodi action numbers): moving around (1-6), OK (7), back (9, 10, 92), pause (12),
# stop (13), next and previous (14, 15), fast forward and rewind (16, 17, 77, 78), the menu (18), jumps (20-23),
# the player controls (24), play (79), play/pause (229), volume (88, 89, 91) and the context menu (117).
PROTECTED_ACTIONS = {1, 2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 77, 78, 79, 88, 89,
                     91, 92, 117, 229}
CANCEL_ACTIONS = {10, 92}
LISTEN_S = 5
# How long Kodi gets to look at its repositories before its list of updates is opened.
UPDATE_WAIT_S = 6


class KeyListener(xbmcgui.WindowXMLDialog):
    """Waits a few seconds for one key or button, on Watch Party's own small screen (the same on every skin)."""

    def __new__(cls, addon_path=''):
        return super().__new__(cls, 'watchparty-shortcut.xml', addon_path, 'default', '1080i')

    def __init__(self, addon_path=''):
        self.code = None
        self.action = None
        self.cancelled = False

    def onInit(self):
        for control, text in ((2, 'Press the key or button for Watch Party'),
                              (3, 'Waiting {} seconds. Back cancels.'.format(LISTEN_S))):
            try:
                self.getControl(control).setLabel(text)
            except (RuntimeError, AttributeError, TypeError):
                pass

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True
        else:
            code = action.getButtonCode()
            if code:
                self.code, self.action = code, action.getId()
        self.close()

    @classmethod
    def listen(cls, addon_path=''):
        dialog = cls(addon_path)
        timer = threading.Timer(LISTEN_S, dialog.close)
        timer.start()
        dialog.doModal()
        timer.cancel()
        return dialog.code, dialog.action, dialog.cancelled

PROBLEMS = {
    'offline': 'Watch Party cannot be reached right now. Check the internet connection and try again.',
    'disconnected': 'This device is no longer connected. Open Watch Party again and enter a new connection code.',
    'wrong_code': 'That code was not accepted. A code can be used once and expires after a few minutes; ask for a new one.',
    'party_full': 'The watch party is full.',
    'nobody_to_invite': 'Everyone you chose is already in the watch party, or has no other device connected.',
    'no_invitation': 'That invitation is no longer open. Ask for a new one.',
    'host_only': 'Only the host can do that.',
    'not_in_party': 'You are not in a watch party.',
}


def tell(text):
    xbmcgui.Dialog().ok(HEADING, text)


def problem(error):
    tell(PROBLEMS.get(error.code, 'Something went wrong. Try again in a moment.'))


def reload_service():
    xbmcgui.Window(10000).setProperty(RELOAD_PROPERTY, str(time.time()))


def item(label, label2='', icon=None):
    entry = xbmcgui.ListItem(label, label2)
    if icon:
        entry.setArt({'icon': icon, 'thumb': icon})
    return entry


class Menu:
    def __init__(self, storage, addon_icon, version='0.0.0'):
        self.storage = storage
        self.addon_icon = addon_icon
        self.version = version
        self.opener = urllib.request.urlopen

    # Connecting ------------------------------------------------------------

    def connect(self):
        previous = self.storage.preferences().get('last_address', '')
        address = xbmcgui.Dialog().input('Watch Party address, for example sync.example.com', defaultt=previous)
        if not address:
            return
        try:
            client = Client(address, version=self.version)
        except AddressProblem as error:
            tell(str(error))
            return
        code = xbmcgui.Dialog().input('Connection code (for example K7QM-3XPD)')
        if not code:
            return
        try:
            paired = client.pair(code)
        except SendError as error:
            problem(error)
            return
        self.storage.save_device({'address': client.address, 'device': paired['device'], 'secret': paired['secret'],
                                  'generation': paired.get('generation', 0),
                                  'name': paired.get('name', ''), 'device_name': paired.get('device_name', '')})
        preferences = self.storage.preferences()
        preferences['last_address'] = client.address.split('://', 1)[1]
        self.storage.save_preferences(preferences)
        reload_service()
        tell('Connected as {} for {}. You can now start or join watch parties.'.format(
            paired.get('device_name') or 'this device', paired.get('name') or 'you'))

    def disconnect(self):
        if xbmcgui.Dialog().yesno(HEADING, 'Disconnect this device from Watch Party? To use it again, you need a new '
                                           'connection code from your Watch Party administrator.',
                                  nolabel='Cancel', yeslabel='Disconnect'):
            self.storage.forget_device()
            reload_service()

    # The main menu -----------------------------------------------------------

    def run(self):
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            if device and device.get('unreadable'):
                text = ("This device's connection was made on another machine and cannot be used here. "
                        'Connect it with a new code.')
            else:
                text = ('This device was disconnected. ' if device else '') + 'Connect it with the code you were given.'
            if xbmcgui.Dialog().yesno(HEADING, text, nolabel='Cancel', yeslabel='Connect'):
                self.connect()
            return
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        self.avatars = Avatars(self.storage.avatar_folder, client)
        try:
            state = client.state(0)
        except SendError as error:
            problem(error)
            if error.code == 'disconnected' and xbmcgui.Dialog().yesno(HEADING, 'Connect again now?'):
                self.connect()
            return
        self.main(client, state)

    def main(self, client, state):
        party = state.get('party')
        choices = []
        if party:
            others = [m['name'] if m['person'] != state['me']['person'] else 'your ' + device_label(m['device_name'])
                      for m in party['members'] if not m['me']]
            watching = describe(party.get('item')) or 'No title selected yet'
            choices.append((item('In a watch party' + (' with ' + ', '.join(others) if others else ''), watching,
                                 self.addon_icon), None))
            choices.append((item('Invite more people', 'Choose who to add'), lambda: self.invite(client, state)))
            choices.append((item('Leave the watch party', 'The others continue without you'),
                            lambda: self.act(client, {'type': 'leave'})))
            if party.get('i_am_host'):
                choices.append((item('End the watch party for everyone'), lambda: self.end(client)))
        else:
            choices.append((item('Start a watch party', 'Choose who to invite'), lambda: self.invite(client, state)))
        for joinable in state.get('joinable', []):
            choices.append((item('Join the watch party on your {}'.format(device_label(joinable.get('device_name'))),
                                 describe(joinable.get('item')) or 'Your own device: no invitation needed'),
                            lambda j=joinable: self.act(client, {'type': 'respond', 'party': j['party'], 'accept': True},
                                                        'You joined the watch party.')))
        for invitation in state.get('invitations', []):
            label = 'Join {}\'s watch party'.format(invitation['from']) if not invitation.get('from_me') else \
                'Join the watch party from your {}'.format(device_label(invitation.get('from_device')))
            people = ', '.join(invitation.get('people', []))
            if invitation.get('can_watch') is False:
                people += ' \u00b7 watching a title you do not have access to'
            choices.append((item(label, people), lambda i=invitation: self.act(
                client, {'type': 'respond', 'party': i['party'], 'accept': True}, 'You joined the watch party.')))
        preferences = self.storage.preferences()
        dnd = preferences.get('do_not_disturb')
        choices.append((item('Do not disturb: ' + ('on' if dnd else 'off'),
                             'Invitations are hidden' if dnd else 'Invitations are shown'),
                        lambda: self.toggle_dnd(preferences)))
        choices.append((item('People', self.online_summary(state)), lambda: self.people(client, state)))
        choices.append((item('Shortcut to open Watch Party', self.shortcut_label(preferences)),
                        lambda: self.remote_button(preferences)))
        me = state.get('me', {})
        choices.append((item('Disconnect this device', '{} for {}'.format(
            self.storage.device().get('device_name') or 'This device', me.get('name', ''))), self.disconnect))
        choices.append((item('Check for updates', self.update_label(preferences)),
                        lambda: self.check_updates(preferences)))
        picked = xbmcgui.Dialog().select('{} {}'.format(HEADING, self.version), [c[0] for c in choices], useDetails=True)
        if picked >= 0 and choices[picked][1]:
            choices[picked][1]()

    # Updates -------------------------------------------------------------------

    def update_label(self, preferences):
        known = preferences.get('latest_version')
        if known and updates.newer(known, self.version):
            return 'Version {} is available. This device has {}.'.format(known, self.version)
        return 'Version {} installed'.format(self.version)

    @staticmethod
    def _repository_xml():
        try:
            path = xbmcaddon.Addon(updates.REPOSITORY_ID).getAddonInfo('path')
            with open(os.path.join(xbmcvfs.translatePath(path), 'addon.xml'), encoding='utf-8') as handle:
                return handle.read()
        except (RuntimeError, OSError):
            return None

    @staticmethod
    def _auto_update_mode():
        """Kodi's own setting: 0 installs updates by itself, 1 only tells, 2 never looks."""
        try:
            answer = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                'params': {'setting': 'general.addonupdates'}})))
            return int(answer['result']['value'])
        except (ValueError, KeyError, TypeError):
            return None

    def check_updates(self, preferences):
        repository = self._repository_xml()
        if repository is None:
            tell('Updates come through the Watch Party Repository, which is not installed on this device. '
                 'Install it the same way you installed Watch Party.')
            return
        try:
            available = updates.latest(repository, opener=self.opener)
        except updates.UpdateProblem as error:
            tell(str(error))
            return
        preferences['latest_version'] = available
        self.storage.save_preferences(preferences)
        if not updates.newer(available, self.version):
            tell('Watch Party is up to date (version {}).'.format(self.version))
            return
        if not xbmcgui.Dialog().yesno(HEADING, 'Watch Party {} is available. This device has {}. Update now?'.format(
                available, self.version), nolabel='Later', yeslabel='Update'):
            return
        mode = self._auto_update_mode()
        # Kodi looks at repositories only once a day; this makes it look now. What happens next is Kodi's:
        # with automatic updates it installs the new version and restarts Watch Party by itself.
        xbmc.executebuiltin('UpdateAddonRepos')
        if mode == 0:
            tell('Kodi is installing the update now. Watch Party restarts by itself in a few seconds.')
            return
        progress = xbmcgui.DialogProgress()
        progress.create(HEADING, 'Kodi is looking for the update.')
        monitor = xbmc.Monitor()
        for step in range(UPDATE_WAIT_S):
            progress.update(int(100 * (step + 1) / UPDATE_WAIT_S))
            if progress.iscanceled() or monitor.waitForAbort(1):
                break
        progress.close()
        tell('Kodi now shows its list of available updates. Choose Watch Party there, then Update.')
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/,return)')

    # Actions -------------------------------------------------------------------

    def act(self, client, payload, success=None):
        try:
            client.act(payload)
        except SendError as error:
            problem(error)
            return False
        if success:
            xbmcgui.Dialog().notification(HEADING, success, self.addon_icon, 4000, False)
        return True

    def end(self, client):
        if xbmcgui.Dialog().yesno(HEADING, 'End the watch party for everyone?', nolabel='Cancel', yeslabel='End it'):
            self.act(client, {'type': 'end'})

    def toggle_dnd(self, preferences):
        preferences['do_not_disturb'] = not preferences.get('do_not_disturb')
        self.storage.save_preferences(preferences)

    def invite(self, client, state):
        people = [p for p in state.get('people', []) if not p.get('in_my_party') or p.get('me')]
        if not people:
            tell('There is nobody to invite yet. Ask your Watch Party administrator to add people.')
            return
        entries = [item('Your other devices' if p.get('me') else p['name'], self.status_line(p),
                        self.avatar(client, p)) for p in people]
        chosen = xbmcgui.Dialog().multiselect('Who do you want to watch with?', entries, useDetails=True)
        if not chosen:
            return
        names = [people[i]['name'] if not people[i].get('me') else 'your other devices' for i in chosen]
        self.act(client, {'type': 'invite', 'people': [people[i]['id'] for i in chosen]},
                 'Invitation sent to {}.'.format(', '.join(names)))

    def people(self, client, state):
        entries = [item(p['name'] + (' (you)' if p.get('me') else ''), self.status_line(p), self.avatar(client, p))
                   for p in state.get('people', [])]
        xbmcgui.Dialog().select('People', entries, useDetails=True)

    @staticmethod
    def status_line(person):
        if not person.get('online'):
            return 'Not online'
        if person.get('watching'):
            return 'Watching ' + describe(person['watching'])
        return 'Online' + (' · in your watch party' if person.get('in_my_party') and not person.get('me') else '')

    @staticmethod
    def online_summary(state):
        online = [p['name'] for p in state.get('people', []) if p.get('online') and not p.get('me')]
        return 'Online now: ' + ', '.join(online) if online else 'Nobody else is online'

    def avatar(self, client, person):
        """A cached picture for the person (fetched now if missing, since a list is about to show it)."""
        if not person.get('avatar'):
            return self.addon_icon
        return self.avatars.get(person['id'], wait=True) or self.addon_icon

    def shortcut_label(self, preferences):
        chosen, kind = preferences.get('shortcut'), preferences.get('remote_button')
        if kind and not shortcut.present():
            return 'The shortcut is missing, possibly removed by the Keymap Editor. Choose it again'
        if chosen:
            name = shortcut.describe(chosen)
            return name[0].upper() + name[1:] + ' opens Watch Party, also during video'
        if kind == 'own':
            return 'Your own key or button opens Watch Party'
        if kind == 'ctrlw':
            return 'Ctrl+W opens it. Ctrl+W closes windows in many programs, so choose Alt+P instead'
        return 'Open Watch Party with a single key or button, also during playback'

    def remote_button(self, preferences):
        in_editor = shortcut.editor_installed()
        labels = (['Press the key or button you want'] + [label for _, label, _ in PRESETS]
                  + (['Set it up in the Keymap Editor'] if in_editor else []) + ['No shortcut'])
        picked = xbmcgui.Dialog().select('Which key or button opens Watch Party?', labels)
        if picked < 0:
            return
        if in_editor and picked == len(labels) - 2:
            # The Keymap Editor shows what every key does already, window by window, and lists this add-on.
            tell('In the Keymap Editor choose Edit, then Global (or Fullscreen video), then Add-ons, then '
                 'Launch Watch Party, and press the key or button you want. Save when you leave it.')
            xbmc.executebuiltin('RunAddon({})'.format(shortcut.KEYMAP_EDITOR))
            return
        if picked == 0:
            code, action, cancelled = KeyListener.listen(xbmcaddon.Addon().getAddonInfo('path'))
            if cancelled:
                return
            if not code:
                tell('No key or button was pressed. Choose the shortcut again and press it within '
                     '{} seconds.'.format(LISTEN_S))
                return
            chosen, kind = shortcut.from_code(code), 'own'
            if chosen is None:
                tell('That button cannot open Watch Party. Choose another key or button.')
                return
            if action in PROTECTED_ACTIONS or shortcut.essential(chosen):
                tell('That key or button is needed for moving around or playback, so it cannot open Watch Party. '
                     'Choose another one.')
                return
        elif picked == len(labels) - 1:
            chosen, kind = None, None
        else:
            kind, _, chosen = PRESETS[picked - 1]
        if chosen is not None:
            found = shortcut.uses(chosen, shortcut.keymap_files())
            if found and not xbmcgui.Dialog().yesno(
                    HEADING, shortcut.explain(chosen, found) + ' Use it for Watch Party instead?',
                    nolabel='Cancel', yeslabel='Use it'):
                return
        try:
            where = shortcut.save(chosen)
        except shortcut.KeymapUnreadable:
            tell('Watch Party could not read the Keymap Editor\'s file, so it changed nothing. Your own '
                 'shortcuts there are untouched.')
            return
        if chosen is None:
            preferences.pop('remote_button', None)
            preferences.pop('shortcut', None)
            done = 'The shortcut was removed.'
        else:
            preferences['remote_button'], preferences['shortcut'] = kind, chosen
            name = shortcut.describe(chosen)
            done = name[0].upper() + name[1:] + ' now opens Watch Party, also during video.'
            if where == 'editor':
                done += ' It shows up in the Keymap Editor as Launch Watch Party.'
        self.storage.save_preferences(preferences)
        tell(done)
