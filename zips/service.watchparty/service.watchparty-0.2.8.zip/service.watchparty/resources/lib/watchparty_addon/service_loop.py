"""The background service: keeps this device in the watch party while Kodi runs.

Light on purpose (small ARM boxes): one waiting request to the server at a time,
one kept-open connection, a quick loop only while a video plays or a countdown runs,
and patient retries when the server is away.
"""
import json
import os
import queue
import threading
import time

import xbmc
import xbmcgui

from . import shortcut
from .avatars import Avatars
from .client import Client
from .engine import Engine, SendError
from .kodi_player import Observer, PlayerAdapter
from .kodi_screen import Screen

RELOAD_PROPERTY = 'watchparty.reload'
BUSY_TICK_S = 0.25
IDLE_TICK_S = 2.0
RETRY_STEPS_S = (1, 2, 5, 10, 30, 60)
# A refusal has to repeat for this long before this device counts as disconnected,
# so a restart or a deploy on the server cannot knock it out.
DISCONNECTED_AFTER = {'times': 3, 'seconds': 30}


def log(message):
    xbmc.log('[Watch Party] ' + message, xbmc.LOGINFO)


class Updates(threading.Thread):
    """Waits for the server's next update, one request at a time, and hands it to the loop."""

    def __init__(self, client, inbox):
        super().__init__(name='watchparty-updates', daemon=True)
        self.client = client
        self.inbox = inbox
        self.running = True

    def run(self):
        version, step, refusals, first_refusal = 0, 0, 0, None
        while self.running:
            try:
                state = self.client.state(version)
            except SendError as error:
                if error.code == 'disconnected':
                    refusals += 1
                    first_refusal = first_refusal or time.monotonic()
                    if (refusals >= DISCONNECTED_AFTER['times']
                            and time.monotonic() - first_refusal >= DISCONNECTED_AFTER['seconds']):
                        self.inbox.put(('disconnected', None))
                        return
                else:
                    refusals, first_refusal = 0, None
                self.inbox.put(('online', False))
                self._sleep(RETRY_STEPS_S[min(step, len(RETRY_STEPS_S) - 1)])
                step += 1
                continue
            step, refusals, first_refusal = 0, 0, None
            version = state.get('version', version)
            self.inbox.put(('online', True))
            self.inbox.put(('state', state))

    def _sleep(self, seconds):
        deadline = time.monotonic() + seconds
        while self.running and time.monotonic() < deadline:
            time.sleep(0.5)

    def stop(self):
        self.running = False
        self.client.close()


class Service:
    def __init__(self, addon_path, storage, version='0.0.0'):
        self.addon_path = addon_path
        self.storage = storage
        self.version = version
        self.monitor = xbmc.Monitor()
        self.inbox = queue.Queue()
        self.observer = Observer(lambda name, data: self.inbox.put(('local', (name, data))))
        self.player = PlayerAdapter(self.observer)
        self.window = xbmcgui.Window(10000)

    def run(self):
        log('started')
        self._migrate_shortcut()
        while not self.monitor.abortRequested():
            device = self.storage.device()
            if not device or device.get('disconnected') or device.get('unreadable'):
                if self._wait_for_change(5):
                    break
                continue
            if self._run_connected(device):
                break
        log('stopped')

    def _reload_requested(self, seen):
        value = self.window.getProperty(RELOAD_PROPERTY)
        return value != seen, value

    def _wait_for_change(self, seconds):
        """Sleep until the menu connects this device, or Kodi closes. True means Kodi is closing."""
        stamp = self.storage.stamp()
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self.monitor.waitForAbort(1):
                return True
            if self.storage.stamp() != stamp:
                return False
        return False

    def _migrate_shortcut(self):
        """Shortcuts chosen with 0.2.7 or older, written again the way Kodi reads them (see shortcut.migrate)."""
        preferences = self.storage.preferences()
        before = json.dumps(preferences, sort_keys=True)
        try:
            message = shortcut.migrate(preferences)
        except (shortcut.KeymapUnreadable, OSError) as error:
            log('shortcut not updated: {}'.format(type(error).__name__))
            return
        if json.dumps(preferences, sort_keys=True) != before:
            self.storage.save_preferences(preferences)
            log('shortcut written again for this version')
        if message:
            xbmcgui.Dialog().notification('Watch Party', message, os.path.join(self.addon_path, 'resources', 'icon.png'),
                                          15000, False)

    def _save_jump_lead(self, lead):
        # Read just before writing, so a change the menu made meanwhile is kept.
        preferences = self.storage.preferences()
        preferences['jump_lead'] = lead
        self.storage.save_preferences(preferences)

    def _run_connected(self, device):
        """Serve one connection until it changes. True means Kodi is closing."""
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        avatars = Avatars(self.storage.avatar_folder, client)
        engine_box = {}
        screen = Screen(self.addon_path, client.server_now,
                        lambda: engine_box['engine'].settings.get('notice_s', 4),
                        lambda party, accept: self.inbox.put(('answer', (party, accept))),
                        avatar=avatars.get, card_folder=self.storage.card_folder,
                        log=lambda text: log('screen: ' + text))
        engine = Engine(self.player, screen, client.act, client.server_now, version=self.version,
                        log=lambda text: log('sync: ' + text),
                        jump_lead=self.storage.preferences().get('jump_lead'), on_jump_lead=self._save_jump_lead)
        engine_box['engine'] = engine
        engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        updates = Updates(client, self.inbox)
        updates.start()
        stamp = self.storage.stamp()
        seen_reload = self.window.getProperty(RELOAD_PROPERTY)
        log('connected as device ' + device['device'])
        try:
            while True:
                busy = self.player.video() or engine.scheduled is not None or engine.starting
                tick = BUSY_TICK_S if busy else IDLE_TICK_S
                wake = engine.wake_in_ms()
                if wake is not None:
                    # Lining up or about to start: run exactly when needed, not up to a quarter second late.
                    tick = min(tick, max(0.005, wake / 1000.0))
                if self.monitor.waitForAbort(0.001):
                    return True
                try:
                    kind, payload = self.inbox.get(timeout=tick)
                except queue.Empty:
                    kind, payload = None, None
                if kind == 'local':
                    engine.on_local(payload[0], **payload[1])
                elif kind == 'state':
                    engine.on_state(payload)
                elif kind == 'online':
                    engine.set_online(payload)
                elif kind == 'answer':
                    engine.respond(*payload)
                elif kind == 'disconnected':
                    screen.notice('This device was disconnected from Watch Party. Open Watch Party to connect it again.')
                    self.storage.mark_disconnected()
                    return False
                engine.tick()
                changed, seen_reload = self._reload_requested(seen_reload)
                if changed:
                    return False
                if self.storage.stamp() != stamp:
                    stamp = self.storage.stamp()
                    current = self.storage.device()
                    if not current or current.get('device') != device['device']:
                        return False
                    engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        finally:
            updates.stop()
            screen.close()
