"""What this device does when someone in a watch party pauses, plays, skips or starts.

There is no Kodi code in here. The engine works through three small adapters:
a player (what is playing, and pause/play/jump), a screen (cards and questions)
and send (one request to the Watch Party server). The same logic runs in the
tests and in Kodi.

Rules measured on a real device (PLAN.md, phase 0):
- Never hold a pause after a jump: jump, then play straight away.
- PM4K wraps its own skips in pause, jump, play and raises a flag meanwhile.
- PM4K's start-up (resume point) also pauses, jumps and plays. None of that is the viewer.
"""

# One jump-and-play took 0.3 to 0.5 s on the CoreELEC box; start that much ahead.
JUMP_LEAD_S = 0.4
# Our own pause, jump or play comes back as a player event within this time.
ECHO_MS = 3000
# PM4K's own skip, from its pause to its play.
SKIP_MS = 5000
# PM4K has finished opening a video once it has played normally for this long.
STEADY_MS = 800
# Stopping this close to the end is finishing, which does not pause the others.
FINISH_WINDOW_S = 60
# A party moves on to a different title only in its last minutes (same as the server).
NEXT_ITEM_WINDOW_S = 300
IDLE_STATUS_MS = 60_000
# A player this close to the shared spot starts a bit earlier or later instead of jumping.
NO_JUMP_WINDOW_S = 5.0
# Starting more than this late (the message arrived late) jumps to the right spot instead of starting behind.
LATE_START_MS = 250

DEFAULT_SETTINGS = {'catchup_threshold_s': 15, 'status_interval_s': 5, 'countdown_s': 5, 'notice_s': 4,
                    'notices': 'essential', 'control': 'everyone'}


class SendError(Exception):
    """The server refused a request, or could not be reached. `code` says which."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def describe(item):
    """A title the way people say it: "Example Show · S2 E3" or the film's title."""
    if not item:
        return ''
    if item.get('show'):
        if item.get('season') is not None and item.get('episode') is not None:
            return '{} · S{} E{}'.format(item['show'], item['season'], item['episode'])
        return item['show']
    return item.get('title') or ''


def clock_label(seconds):
    seconds = int(max(0, seconds or 0))
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return '{}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{}:{:02d}'.format(minutes, seconds)


def _older(version, other):
    def parts(text):
        try:
            return tuple(int(p) for p in str(text).split('.')[:3])
        except ValueError:
            return None
    mine, theirs = parts(version), parts(other)
    return bool(mine and theirs and mine < theirs)


def names(items):
    items = [i for i in items if i]
    if len(items) <= 1:
        return ''.join(items)
    return ', '.join(items[:-1]) + ' and ' + items[-1]


class Engine:
    def __init__(self, player, screen, send, clock, version='0.0.0'):
        self.version = version
        self.update_told = False
        self.cannot_told = None
        self.last_item = None
        self.player = player
        self.screen = screen
        self.send = send
        self.clock = clock
        self.view = None
        self.settings = dict(DEFAULT_SETTINGS)
        self.applied = None
        self.echo = {}
        self.skip_until = 0
        self.starting = False
        self.steady_since = None
        self.item = None
        self.scheduled = None
        self.offer = None
        self.fast = False
        self.pending_invitation = None
        self.seen_invitations = set()
        self.last_status = 0
        self.dnd = False
        self.online = True

    # Reading the party -----------------------------------------------------

    def party(self):
        return (self.view or {}).get('party')

    def _on_party_item(self, party):
        return bool(self.item and party and party.get('item') and party['item']['key'] == self.item['key'])

    def _expected(self, party, now):
        playback = party['playback']
        if playback['state'] == 'playing':
            return playback['position'] + max(0, now - playback['at']) / 1000.0
        return playback['position']

    def _near_end(self, party, now):
        duration = (party.get('item') or {}).get('duration')
        return bool(duration) and self._expected(party, now) >= duration - NEXT_ITEM_WINDOW_S

    def _may_control(self, party):
        return self.settings.get('control') != 'host' or party.get('i_am_host')

    def _my_person(self):
        return ((self.view or {}).get('me') or {}).get('person')

    def _label(self, member):
        if member.get('person') == self._my_person():
            return 'your ' + (member.get('device_name') or 'other device')
        return member.get('name') or 'Someone'

    def _others(self, party):
        return names([self._label(m) for m in party.get('members', []) if not m.get('me')]) or 'the others'

    # Player commands, remembered so their echo is not taken for the viewer ---

    def _expect(self, name):
        self.echo[name] = self.clock() + ECHO_MS

    def _consume(self, name, now):
        deadline = self.echo.get(name)
        if deadline is not None and deadline >= now:
            del self.echo[name]
            return True
        return False

    def _pause(self):
        if not self.player.paused():
            self._expect('paused')
            self.player.pause()

    def _play(self):
        if self.player.paused():
            self._expect('resumed')
            self.player.play()

    def _jump_and_play(self, seconds):
        self._pause()
        self._expect('seek')
        self.player.jump(max(0.0, seconds))
        self._expect('resumed')
        self.player.play()

    # Talking to the server -------------------------------------------------

    def _send(self, payload):
        if not self.online:
            # Nothing is queued while the server is away: on return, this device follows the party.
            return None
        try:
            result = self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)
            else:
                self._refused(error.code)
            return None
        return result

    def _tell(self, text, extra=False, person=None):
        """A notice. Extra ones (pressed play, back in step, reachable again) only show if the admin chose Everything."""
        if extra and self.settings.get('notices') != 'all':
            return
        self.screen.notice(text, person=person)

    def set_online(self, online):
        """Told by the connection (or found out by a failed send). Only a party member hears about it."""
        if online == self.online:
            return
        self.online = online
        if not self.party():
            return
        if online:
            self._tell('Watch Party is reachable again. Following the watch party.', extra=True)
            self.applied = None
        else:
            self._tell("Watch Party can't be reached right now. Playback here carries on as normal.")

    def _refused(self, code):
        party = self.party()
        if code == 'host_only' and party:
            self._tell('Only {} can pause or skip in this watch party.'.format(party.get('host_name') or 'the host'))
        elif code in ('party_busy', 'other_item') and party and party.get('item'):
            self._tell('The watch party is watching {}. You are watching on your own.'.format(
                describe(party['item'])))

    def _send_playback(self, kind, position, item=None):
        result = self._send({'type': 'playback', 'kind': kind, 'item': item or self.item,
                             'position': round(max(0.0, position or 0.0), 3)})
        if result is not None:
            self._clear_offer()
        return result

    def _send_status(self, state=None):
        now = self.clock()
        self.last_status = now
        if state is None:
            state = 'idle' if not self.item else ('paused' if self.player.paused() else 'playing')
        payload = {'type': 'status', 'state': state}
        if state != 'idle':
            payload.update(item=self.item, position=round(self.player.position() or 0.0, 3))
        if not self.online:
            return
        try:
            self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)

    def respond(self, party_id, accept):
        """The viewer answered an invitation."""
        self._send({'type': 'respond', 'party': party_id, 'accept': bool(accept)})

    def set_do_not_disturb(self, value):
        self.dnd = bool(value)

    # What the player reports -----------------------------------------------

    def on_local(self, name, position=None, target=None, seeking=False, speed=None):
        now = self.clock()
        if name == 'started':
            self.starting, self.steady_since, self.item, self.fast = True, None, None, False
            self.skip_until = 0
            self._clear_offer()
            return
        if name in ('stopped', 'ended'):
            self._stopped(name == 'ended', position)
            return
        if self.starting:
            return
        if name == 'speed':
            if speed == 1:
                if self.fast:
                    self.fast = False
                    self._user_seek(position)
            else:
                self.fast = True
            return
        if name == 'paused' and seeking:
            # PM4K's own skip (its flag is up): never our echo, even if one of ours is expected.
            self.skip_until = now + SKIP_MS
            return
        if self._consume(name, now):
            return
        if name == 'paused':
            self._user_pause(position)
        elif name == 'resumed':
            if self.skip_until >= now:
                self.skip_until = 0
                return
            self._user_resume(position)
        elif name == 'seek' and not self.fast:
            self._user_seek(target if target is not None else position)

    def _user_pause(self, position):
        party = self.party()
        if not party and self.pending_invitation:
            invitation, self.pending_invitation = self.pending_invitation, None
            self.screen.ask(invitation)
            return
        if not self._on_party_item(party):
            return
        if self.offer:
            self._catch_up(party)
            return
        if not self._may_control(party):
            self._play()
            self._refused('host_only')
            return
        if self._send_playback('pause', position) is not None:
            self.screen.hold(self._paused_text(party, 'You paused', None))

    def _user_resume(self, position):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._pause()
            self._refused('host_only')
            return
        self.screen.clear_hold()
        # Everyone starts together a moment from now, this player included, so hold it until then.
        self._pause()
        if self._send_playback('resume', position) is None:
            self._play()

    def _user_seek(self, target):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            if party['playback']['state'] == 'playing':
                self._jump_and_play(self._expected(party, self.clock()) + JUMP_LEAD_S)
            self._refused('host_only')
            return
        self._send_playback('seek', target)

    def _stopped(self, ended, position):
        was, self.item = self.item, None
        self.last_item = was or self.last_item
        self.starting, self.scheduled = False, None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        party = self.party()
        if party and was and party.get('item') and party['item']['key'] == was['key']:
            duration = was.get('duration') or 0
            finished = ended or (duration and (position or 0) >= duration - FINISH_WINDOW_S)
            if not finished:
                self._send_playback('stop', position, item=was)
        self._send_status('idle')

    # Housekeeping, about four times a second ---------------------------------

    def tick(self):
        now = self.clock()
        for name in [n for n, deadline in self.echo.items() if deadline < now]:
            del self.echo[name]
        if self.starting:
            self._check_steady(now)
        if self.scheduled:
            self._run_scheduled(now)
        interval = self.settings['status_interval_s'] * 1000 if self.item else IDLE_STATUS_MS
        if now - self.last_status >= interval:
            self._send_status()
        party = self.party()
        if party and self.item and not self.starting:
            self._check_distance(party, now)

    def _run_scheduled(self, now):
        at, position = self.scheduled
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and abs(mine - position) <= NO_JUMP_WINDOW_S:
            # Already (nearly) there: start a little earlier or later instead of jumping.
            start = at + (mine - position) * 1000
            if now < start:
                return
            self.scheduled = None
            self.screen.clear_countdown()
            if not self.item:
                return
            if now - start > LATE_START_MS:
                self._jump_and_play(position + (now - at) / 1000.0 + JUMP_LEAD_S)
            else:
                self._play()
            return
        if now < at - JUMP_LEAD_S * 1000:
            return
        self.scheduled = None
        self.screen.clear_countdown()
        if self.item:
            # Playback resumes about JUMP_LEAD_S after the jump starts, at at + (now - at) + lead. Jumping early
            # makes (now - at) negative and cancels the lead, so the picture moves on from `position` right at `at`.
            self._jump_and_play(position + (now - at) / 1000.0 + JUMP_LEAD_S)

    def _check_steady(self, now):
        if not self.player.video() or self.player.pm4k_busy() or self.player.paused():
            self.steady_since = None
            return
        if self.steady_since is None:
            self.steady_since = now
            return
        if now - self.steady_since >= STEADY_MS:
            self.starting = False
            self.item = self.player.item()
            self._ready()

    def _ready(self):
        self._send_status()
        party = self.party()
        if not party:
            return
        if not self.item:
            self._tell('This video cannot play in sync: it is not playing directly from the server.')
            return
        self._join_playback(party)
        if self._on_party_item(party):
            # Opened what the party is on: follow wherever it is now (playing, paused, counting down).
            self._follow(party)

    def _join_playback(self, party):
        """Tell the server this device is on its title. The next update says what to do."""
        playback = party['playback']
        if (not self._on_party_item(party) and playback['state'] == 'playing'
                and not self._near_end(party, self.clock())):
            self._refused('party_busy')
            return
        self._send_playback('start', self.player.position() or 0.0)

    def _check_distance(self, party, now):
        playback = party['playback']
        if (playback['state'] != 'playing' or playback['at'] > now or not self._on_party_item(party)
                or self.player.paused() or self.echo or self.skip_until >= now or self.scheduled):
            return
        position = self.player.position()
        if position is None:
            return
        distance = position - self._expected(party, now)
        threshold = self.settings['catchup_threshold_s']
        if distance < -threshold:
            wanted = 'behind'
        elif distance > threshold:
            wanted = 'ahead'
        elif abs(distance) < threshold / 2.0:
            wanted = None
        else:
            wanted = self.offer
        if wanted == self.offer:
            return
        self.offer = wanted
        if wanted == 'behind':
            self.screen.offer("You're {} seconds behind {}. Press pause to catch up.".format(
                int(-distance), self._others(party)))
        elif wanted == 'ahead':
            self.screen.offer("You're {} seconds ahead of {}. Press pause to line up with them.".format(
                int(distance), self._others(party)))
        else:
            self.screen.clear_offer()

    def _catch_up(self, party):
        self._clear_offer()
        self._jump_and_play(self._expected(party, self.clock()) + JUMP_LEAD_S)
        self._tell('You are back in step with {}.'.format(self._others(party)), extra=True)

    def _clear_offer(self):
        if self.offer:
            self.offer = None
            self.screen.clear_offer()

    # What the server reports -----------------------------------------------

    def on_state(self, view):
        previous, self.view = self.view, view
        self.settings.update({k: v for k, v in (view.get('settings') or {}).items() if k in DEFAULT_SETTINGS})
        self._invitations(view)
        minimum = (view.get('addon') or {}).get('minimum')
        if minimum and not self.update_told and _older(self.version, minimum):
            self.update_told = True
            self._tell('Watch Party needs an update. Update it under Add-ons so it keeps working.')
        party, before = view.get('party'), (previous or {}).get('party')
        if before and not party:
            self._party_gone()
        elif party and (not before or before['id'] != party['id']):
            self._joined(party)
        elif party:
            self._membership(before, party)
        if party:
            self._follow(party)

    def _invitations(self, view):
        current = {i['party'] for i in view.get('invitations', [])}
        if self.pending_invitation and self.pending_invitation['party'] not in current:
            self.pending_invitation = None
        for invitation in view.get('invitations', []):
            if invitation['party'] in self.seen_invitations:
                continue
            self.seen_invitations.add(invitation['party'])
            if self.dnd:
                continue
            if invitation.get('from_me'):
                text = 'Your {} invited this device to a watch party.'.format(invitation.get('from_device') or 'other device')
            else:
                text = '{} invited you to a watch party.'.format(invitation.get('from') or 'Someone')
            if self.player.video() and not self.player.paused():
                if view.get('party'):
                    self._tell(text + ' Open Watch Party to answer.')
                else:
                    self.pending_invitation = invitation
                    self._tell(text + ' Press pause to answer.')
            else:
                self.screen.ask(invitation)

    def _party_gone(self):
        self.scheduled = None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        self._tell('The watch party has ended.')

    def _joined(self, party):
        if party.get('i_am_host') and len(party.get('members', [])) == 1:
            self._tell('Watch party started. Invitations are on their way.')
        else:
            self._tell("You're in {}'s watch party.".format(party.get('host_name') or 'a'))
        if self.item and not self.starting:
            self._join_playback(party)

    def _membership(self, before, party):
        def key(member):
            return (member.get('person'), member.get('device_name'))
        old = {key(m) for m in before.get('members', [])}
        new = {key(m) for m in party.get('members', [])}
        was_online = {key(m): m.get('online') for m in before.get('members', [])}
        for member in party.get('members', []):
            if member.get('me'):
                continue
            name = self._label(member).capitalize()
            if key(member) not in old:
                self._tell('{} joined the watch party.'.format(name))
            elif was_online.get(key(member)) and not member.get('online'):
                self._tell("{}'s connection dropped.".format(name))
            elif was_online.get(key(member)) is False and member.get('online'):
                self._tell('{} is back.'.format(name), extra=True)
        for member in before.get('members', []):
            if key(member) not in new and not member.get('me'):
                self._tell('{} left the watch party.'.format(self._label(member).capitalize()))

    def _follow(self, party):
        playback = party['playback']
        item_key = (party.get('item') or {}).get('key')
        if party.get('cannot_watch') and item_key and self.cannot_told != item_key and self._on_party_item(party):
            self.cannot_told = item_key
            self._tell("{} can't watch this title: no access to its library.".format(names(party['cannot_watch'])))
        # A state is applied once per title this device plays, so opening the party's title
        # after a change still brings this player to where the party is.
        key = (party['id'], playback['seq'], (self.item or {}).get('key'))
        if key != self.applied:
            self.applied = key
            self._apply(party, playback)
        elif playback['state'] == 'waiting' and self._on_party_item(party):
            self.screen.hold(self._waiting_text(party))

    def _paused_text(self, party, who, by_person):
        others = [self._label(m) for m in party.get('members', []) if not m.get('me')]
        return who + (' \u00b7 with ' + names(others) if others else '')

    def _starting_text(self, party, by):
        item = party['item']
        if party.get('can_watch') is False:
            return "{} is watching something you don't have access to. You'll be back in step when the watch party moves on.".format(by)
        last = self.last_item or {}
        if last.get('show') and last.get('show') == item.get('show') and last.get('key') != item.get('key'):
            return '{} moved on to {}. Open it in Plex to keep watching together.'.format(
                by, 'S{} E{}'.format(item.get('season'), item.get('episode')) if item.get('episode') is not None
                else describe(item))
        return '{} is starting {}. Open it in Plex to watch together.'.format(by, describe(item))

    def _waiting_text(self, party):
        missing = [self._label(m) for m in party.get('members', []) if not m.get('me') and not m.get('ready')]
        if not missing:
            return 'Starting together in a moment.'
        return 'Waiting for {} to open it. Press play to start without them.'.format(names(missing))

    def _apply(self, party, playback):
        now = self.clock()
        by, kind = playback.get('by_name') or 'Someone', playback.get('kind')
        if not self._on_party_item(party) or self.starting:
            if (kind == 'start' and not playback.get('by_me') and playback['state'] in ('waiting', 'playing')
                    and not self.starting and party.get('item')):
                self._tell(self._starting_text(party, by), person=playback.get('by_person'))
            return
        if playback.get('by_me') and kind in ('pause', 'seek', 'stopped'):
            return
        state = playback['state']
        if state == 'paused':
            self.scheduled = None
            self.screen.clear_countdown()
            self.screen.clear_hold()
            self._pause()
            if not playback.get('by_me'):
                if kind == 'stopped':
                    self.screen.hold('{} stopped watching. Press play to carry on without them.'.format(by))
                elif kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'])),
                               person=playback.get('by_person'))
                else:
                    self.screen.hold(self._paused_text(party, '{} paused'.format(by), playback.get('by_person')))
        elif state == 'playing':
            self.screen.clear_hold()
            if playback['at'] > now + 100:
                self._pause()
                self.scheduled = (playback['at'], playback['position'])
                if kind == 'start':
                    self.screen.countdown(playback['at'])
                elif not playback.get('by_me'):
                    self._tell('{} pressed play.'.format(by), extra=True)
                return
            self.scheduled = None
            self.screen.clear_countdown()
            self._jump_and_play(self._expected(party, now) + JUMP_LEAD_S)
            if not playback.get('by_me'):
                if kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'])),
                               person=playback.get('by_person'))
                elif kind == 'resume':
                    self._tell('{} pressed play.'.format(by), extra=True)
        elif state == 'waiting':
            self._pause()
            self.screen.hold(self._waiting_text(party))
