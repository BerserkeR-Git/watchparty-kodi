"""What the engine asks of a player, and what the player must report back. No Kodi in here.

Adapters: kodi_player.PlayerAdapter (Kodi's player, with kodi_player.Observer reporting its events), and in the
tests fakes.FakePlayer and fakes.SimulatedPlayer. addon/tests/test_player_contract.py holds every adapter to this.

Reads, which change nothing:
- video(): a video is playing (or paused).
- item(): the Plex title playing in direct play, {'key', 'title', ... 'duration'}, or None (no video, or a stream
  Plex converts on the fly: that cannot be synced).
- position(): seconds into the video, or None without a video.
- paused(): paused.
- pm4k_busy(): PM4K is in the middle of its own skip or of opening a video.

Commands:
- pause(), play(): paused or playing afterwards (doing nothing if already so).
- jump(seconds): an exact jump, returning once the player has landed or JUMP_WAIT_S has passed.

Reports, as events (name, data) the engine is handed in order, each with the position at the time:
- every command comes back: pause as 'paused', play as 'resumed', jump as 'seek' with 'target' (the time asked
  for, to the millisecond) and 'position' (where it landed, a keyframe on some players); Kodi may report a seek
  seconds late, and one jump more than once (the WAN test: up to 16 s late, the TV twice, 7 s apart);
- what the viewer does: 'started' (a video opened), 'stopped', 'ended', 'paused', 'resumed', 'seek', and 'speed'
  with the speed when fast-forwarding; PM4K's own skip is flagged with 'seeking' on its pause and its seek.
"""

# A jump waits this long at most for Kodi's report that it has landed (measured on local files: 0.1 to 0.2 s;
# streaming from Plex every jump of the WAN test waited it out).
JUMP_WAIT_S = 1.5
# While a jump waits for Kodi's report, the player's time is read this often, for diagnostics: whether the wait can
# go depends on what the time says meanwhile.
JUMP_TRACE_S = 0.1
# A reading this close to a jump's aim has moved there.
JUMP_NEAR_S = 3.0

READS = ('video', 'item', 'position', 'paused', 'pm4k_busy')
COMMANDS = ('pause', 'play', 'jump')
