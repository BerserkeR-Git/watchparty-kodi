"""The key or button that opens Watch Party, written into Kodi's keymaps the way Kodi reads them.

Facts from Kodi 21's source (input/keymaps):
- Under <keyboard> a key can be given by number (<key id="61516">); a "mod" attribute (ctrl, alt, longpress)
  works there only.
- Under <remote> buttons are given by name (<red>, <info>) and "mod" is ignored, so a long press of a remote
  button cannot be told apart from a short one. A remote on CoreELEC (CEC) reports these remote buttons. (All
  devices' codes share one table per window, so a remote code given as a keyboard number also matches; the
  name is the documented form and what the Keymap Editor's users would expect to read.)
- A window's own mapping wins over the global one, so a key Kodi uses during video (L switches subtitles there)
  has to be mapped in the video windows as well, or it never opens Watch Party during a film.
- A key press runs through the keymap before a window sees it: an add-on window waiting for a key cannot stop
  the key's own job (the red button still opened TV channels, over the next question). While a key is being
  chosen, a keymap file loaded last switches every global job off (moving around and Back stay).
- The Keymap Editor (script.keymap) rewrites its file as keyboard key numbers only and renames other keymap
  files on save, unless its multiple-files option is on. It lists this add-on as "Launch Watch Party". Since all
  devices' codes share one table per window (CButtonTranslator::MapWindowActions), a remote button kept there
  as its number works too.
"""
import os
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcaddon
import xbmcvfs

# The action the Keymap Editor lists as "Launch Watch Party", so a shortcut set here shows up there by name.
OPEN_ACTION = 'RunAddon(service.watchparty)'
OUR_ACTIONS = ('runaddon(service.watchparty)', 'runscript(service.watchparty)')
KEYMAP = 'special://profile/keymaps/watchparty.xml'
KEYMAP_FOLDER = 'special://profile/keymaps'
KODI_KEYMAPS = 'special://xbmc/system/keymaps'
KEYMAP_EDITOR = 'script.keymap'
# Only there while a key is being chosen; loaded after every other keymap file (Kodi sorts them by name).
LISTENING = 'special://profile/keymaps/zz-watchparty-listening.xml'
# Jobs that keep working while a key is being chosen, so Back still cancels and nobody is stuck.
KEEP_WHILE_LISTENING = {'back', 'previousmenu', 'up', 'down', 'left', 'right', 'select', 'enter'}
# Where the shortcut is mapped: everywhere, and in the windows used while watching, whose own mappings win.
CONTEXTS = ('global', 'fullscreenvideo', 'videoosd', 'videomenu')

# Kodi's remote button codes (XINPUT_IR_REMOTE_*) by name, from Kodi 21's IRTranslator.cpp and IRRemote.h.
REMOTE_NAMES = {
    6: 'mypictures', 7: 'myvideo', 9: 'mymusic', 11: 'select', 22: 'enter', 24: 'livetv', 37: 'start', 40: 'star',
    41: 'hash', 44: 'subtitle', 45: 'language', 49: 'mytv', 50: 'guide', 101: 'recordedtv', 166: 'up', 167: 'down',
    168: 'right', 169: 'left', 192: 'mute', 195: 'info', 196: 'power', 198: 'nine', 199: 'eight', 200: 'seven',
    201: 'six', 202: 'five', 203: 'four', 204: 'three', 205: 'two', 206: 'one', 207: 'zero', 208: 'volumeplus',
    209: 'volumeminus', 210: 'channelplus', 211: 'channelminus', 213: 'display', 216: 'back', 221: 'skipminus',
    223: 'skipplus', 224: 'stop', 226: 'reverse', 227: 'forward', 229: 'title', 230: 'pause', 232: 'record',
    234: 'play', 235: 'eject', 236: 'contentsmenu', 237: 'rootmenu', 238: 'topmenu', 239: 'dvdmenu', 240: 'print',
    246: 'epgsearch', 247: 'menu', 248: 'liveradio', 249: 'clear', 250: 'teletext', 251: 'red', 252: 'green',
    253: 'yellow', 254: 'blue', 255: 'playlist',
}
# Remote buttons nobody should lose: moving around, OK, back, the player's own buttons, volume, numbers.
ESSENTIAL_REMOTE = {'select', 'enter', 'up', 'down', 'left', 'right', 'back', 'menu', 'contentsmenu', 'play', 'pause',
                    'stop', 'forward', 'reverse', 'skipplus', 'skipminus', 'volumeplus', 'volumeminus', 'mute',
                    'power', 'title', 'display', 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven',
                    'eight', 'nine'}
KEY_VKEY, KEY_ASCII, KEY_UNICODE = 0xF000, 0xF100, 0xF200
MODIFIERS = ((0x10000, 'ctrl'), (0x20000, 'shift'), (0x40000, 'alt'), (0x80000, 'altgr'), (0x100000, 'super'),
             (0x1000000, 'longpress'))
ALT_P = KEY_VKEY + ord('P') + 0x40000
# Shift, Ctrl, Alt, the Windows keys and Caps Lock on their own (Kodi's virtual key numbers): pressed first in a
# combination such as Ctrl+K, so the listener waits for the key that goes with them.
MODIFIER_KEYS = {0x10, 0x11, 0x12, 0x14, 0x5B, 0x5C, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}
# Remote buttons whose keymap name is not how people say it.
REMOTE_WORDS = {
    'mypictures': 'Pictures', 'myvideo': 'Videos', 'mymusic': 'Music', 'livetv': 'Live TV', 'mytv': 'TV',
    'recordedtv': 'Recordings', 'epgsearch': 'EPG search', 'liveradio': 'Radio', 'channelplus': 'Channel up',
    'channelminus': 'Channel down', 'contentsmenu': 'Contents menu', 'rootmenu': 'Root menu', 'topmenu': 'Top menu',
    'dvdmenu': 'DVD menu', 'volumeplus': 'Volume up', 'volumeminus': 'Volume down', 'skipplus': 'Next',
    'skipminus': 'Previous', 'hash': '#', 'star': '*',
}
# Kodi's own words for what a key does, said plainly (others are shown by their action name).
ACTIONS = {
    'nextsubtitle': 'switches to the next subtitle', 'showsubtitles': 'turns subtitles on or off',
    'activatewindow(tvchannels)': 'opens TV channels', 'activatewindow(videos)': 'opens Videos',
    'activatewindow(music)': 'opens Music', 'activatewindow(pictures)': 'opens Pictures', 'play': 'plays',
    'pause': 'pauses', 'playpause': 'plays or pauses', 'info': 'shows information', 'osd': 'shows the controls',
    'codecinfo': 'shows codec details', 'lockpreset': 'locks the visualisation preset',
}
CONTEXT_WORDS = {'global': 'everywhere', 'fullscreenvideo': 'during video', 'videoosd': 'in the video controls',
                 'videomenu': 'in the video menu'}


class KeymapUnreadable(Exception):
    pass


def from_code(code):
    """The shortcut a key or button press gives, or None if it cannot open anything (a game pad, a mouse)."""
    if not code:
        return None
    base = code & 0xFFFF
    if KEY_VKEY <= base < KEY_UNICODE + 0x100:
        return {'kind': 'keyboard', 'code': int(code)}
    if code in REMOTE_NAMES:
        return {'kind': 'remote', 'name': REMOTE_NAMES[code]}
    return None


def modifier_only(code):
    """A press of Shift, Ctrl, Alt or the Windows key on its own (the start of a combination)."""
    base = code & 0xFFFF
    return base & 0xFF00 == KEY_VKEY and base & 0xFF in MODIFIER_KEYS


def _letter(base):
    """The letter or digit a key types, if any. Kodi's virtual key numbers are Windows': 0x30-0x39 and 0x41-0x5A are
    0 to 9 and A to Z, but 0x60-0x7B, lower-case letters as text, are the number pad and F1 to F12 (F5 was named
    "T")."""
    low = base & 0xFF
    if base & 0xFF00 == KEY_VKEY:
        return chr(low) if 0x30 <= low <= 0x39 or 0x41 <= low <= 0x5A else None
    if base & 0xFF00 == KEY_ASCII and chr(low).isalnum():
        return chr(low)
    return None


def describe(shortcut):
    """How people call it inside a sentence: "L", "Alt+P", "the red button", "the Live TV button"."""
    if shortcut['kind'] == 'remote':
        name = shortcut['name']
        return 'the {} button'.format(REMOTE_WORDS.get(name, name))
    code = shortcut['code']
    base, words = code & 0xFFFF, [name.capitalize() for bit, name in MODIFIERS if code & bit and name != 'longpress']
    key = (_letter(base) or '').upper() or None
    text = '+'.join(words + [key]) if key else ('that key' if not words else '+'.join(words) + ' and that key')
    return ('a long press on ' + text) if code & 0x1000000 else text


def title(shortcut):
    """Its name on its own, as a label: "Alt+P", "Red button"."""
    text = describe(shortcut)
    text = text[4:] if text.startswith('the ') else text
    return text[:1].upper() + text[1:]


def essential(shortcut):
    return shortcut['kind'] == 'remote' and shortcut['name'] in ESSENTIAL_REMOTE


def _matches(element, shortcut, device):
    if shortcut['kind'] == 'remote':
        return device == 'remote' and element.tag.lower() == shortcut['name']
    if device != 'keyboard':
        return False
    code = shortcut['code']
    if element.get('id'):
        try:
            return int(element.get('id')) == code
        except ValueError:
            return False
    base = code & 0xFFFF
    letter = _letter(base) if base & 0xFF00 == KEY_VKEY else None
    letter = letter.lower() if letter else None
    if element.tag.lower() != letter:
        return False
    wanted = {name for bit, name in MODIFIERS if code & bit}
    mods = {m.strip() for m in (element.get('mod') or '').lower().split(',') if m.strip()}
    return mods == wanted


def uses(shortcut, keymap_files):
    """Where Kodi (or another keymap file) already uses this shortcut in the windows Watch Party maps it in."""
    found = []
    for path in keymap_files:
        try:
            root = ElementTree.parse(path).getroot()
        except (OSError, ElementTree.ParseError):
            continue
        for context in root:
            if context.tag.lower() not in CONTEXTS:
                continue
            for device in context:
                for element in device:
                    action = (element.text or '').strip()
                    if action and action.lower() not in OUR_ACTIONS and _matches(element, shortcut, device.tag.lower()):
                        found.append((context.tag.lower(), action))
    return found


def explain(shortcut, found):
    """'L switches to the next subtitle during video.'"""
    parts = []
    for context, action in found:
        part = '{} {}'.format(ACTIONS.get(action.lower(), 'runs "{}"'.format(action)), CONTEXT_WORDS[context])
        if part not in parts:
            parts.append(part)
    name = describe(shortcut)
    return '{} already {}.'.format(name[0].upper() + name[1:], ' and '.join(parts))


def code_of(shortcut):
    """The button code: what the Keymap Editor keeps, for a remote button as much as for a key."""
    if shortcut['kind'] == 'keyboard':
        return int(shortcut['code'])
    return next(code for code, name in REMOTE_NAMES.items() if name == shortcut['name'])


def editor_installed():
    return bool(xbmc.getCondVisibility('System.HasAddon({})'.format(KEYMAP_EDITOR)))


def _entry(shortcut, as_number=False):
    if as_number:
        element = ElementTree.Element('key', {'id': str(code_of(shortcut))})
    elif shortcut['kind'] == 'remote':
        element = ElementTree.Element(shortcut['name'])
    else:
        element = ElementTree.Element('key', {'id': str(int(shortcut['code']))})
    element.text = OPEN_ACTION
    return element


def own_file_xml(shortcut):
    root = ElementTree.Element('keymap')
    for context in CONTEXTS:
        device = ElementTree.SubElement(ElementTree.SubElement(root, context), shortcut['kind'])
        device.append(_entry(shortcut))
    return ElementTree.tostring(root, encoding='unicode')


def _is_ours(element):
    return (element.text or '').strip().lower() in OUR_ACTIONS


def editor_file():
    """The Keymap Editor's own file when it is installed and renames other keymap files, else None."""
    if not xbmc.getCondVisibility('System.HasAddon({})'.format(KEYMAP_EDITOR)):
        return None
    try:
        editor = xbmcaddon.Addon(KEYMAP_EDITOR)
        if editor.getSetting('enable_multifile') == 'true':
            return None
        name = editor.getSetting('keymap_editor_filename') or 'gen'
    except RuntimeError:
        name = 'gen'
    return os.path.join(xbmcvfs.translatePath(KEYMAP_FOLDER), ''.join(c for c in name if c.isalnum() or c in '-_')
                        + '.xml')


def _edit_editor_file(path, shortcut):
    """Take Watch Party's lines out of the Keymap Editor's file and, with a keyboard shortcut, put them back in.

    A file that is there but cannot be read is never replaced: it holds the person's own shortcuts.
    """
    try:
        root = ElementTree.parse(path).getroot()
    except FileNotFoundError:
        root = ElementTree.Element('keymap')
    except (OSError, ElementTree.ParseError):
        raise KeymapUnreadable() from None
    for context in root:
        for device in context:
            for mapping in [m for m in device if _is_ours(m)]:
                device.remove(mapping)
    if shortcut is not None:
        for name in CONTEXTS:
            context = root.find(name)
            if context is None:
                context = ElementTree.SubElement(root, name)
            keyboard = context.find('keyboard')
            if keyboard is None:
                keyboard = ElementTree.SubElement(context, 'keyboard')
            keyboard.append(_entry(shortcut, as_number=True))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + '.watchparty-new'
    ElementTree.ElementTree(root).write(temporary, encoding='utf-8')
    os.replace(temporary, path)


def save(shortcut):
    """Write the shortcut (None removes it). Returns where it went: 'editor', 'own' or None when removed.

    Raises KeymapUnreadable, changing nothing, when the Keymap Editor's file exists but cannot be read.
    """
    own = xbmcvfs.translatePath(KEYMAP)
    editor = editor_file()
    if editor:
        _edit_editor_file(editor, shortcut)
    try:
        os.remove(own)
    except OSError:
        pass
    where = None
    if shortcut is not None and not editor:
        os.makedirs(os.path.dirname(own), exist_ok=True)
        with open(own, 'w', encoding='utf-8') as handle:
            handle.write(own_file_xml(shortcut) + '\n')
        where = 'own'
    elif shortcut is not None:
        where = 'editor'
    xbmc.executebuiltin('Action(reloadkeymaps)')
    return where


def present():
    paths = [xbmcvfs.translatePath(KEYMAP)]
    editor = editor_file()
    if editor:
        paths.append(editor)
    for path in paths:
        try:
            if any(_is_ours(m) for m in ElementTree.parse(path).getroot().iter()):
                return True
        except (OSError, ElementTree.ParseError):
            continue
    return False


def keymap_files(include_own=False):
    """Kodi's own keymaps and the person's other keymap files, in the order Kodi loads them (not Watch Party's,
    unless asked; never the file used while listening)."""
    files = []
    skip = {os.path.basename(LISTENING)} | (set() if include_own else {os.path.basename(KEYMAP)})
    for folder in (xbmcvfs.translatePath(KODI_KEYMAPS), xbmcvfs.translatePath(KEYMAP_FOLDER)):
        try:
            names = sorted(n for n in os.listdir(folder) if n.endswith('.xml') and n not in skip)
        except OSError:
            continue
        files.extend(os.path.join(folder, n) for n in names)
    return files


def _mapping_key(element):
    mods = ','.join(sorted(m.strip() for m in (element.get('mod') or '').lower().split(',') if m.strip()))
    return element.tag.lower(), element.get('id') or '', mods


def listening_xml(files):
    """A keymap that switches off every global job a key or button has (all but moving around and Back)."""
    effective = {}
    for path in files:
        try:
            root = ElementTree.parse(path).getroot()
        except (OSError, ElementTree.ParseError):
            continue
        for context in root:
            if context.tag.lower() != 'global':
                continue
            for device in context:
                if device.tag.lower() not in ('keyboard', 'remote'):
                    continue
                for element in device:
                    # A later file overrides an earlier one, as in Kodi.
                    effective[(device.tag.lower(),) + _mapping_key(element)] = (element, (element.text or '').strip())
    root = ElementTree.Element('keymap')
    context = ElementTree.SubElement(root, 'global')
    devices = {}
    for (device, _, _, _), (element, action) in sorted(effective.items(), key=lambda kv: kv[0]):
        if not action or action.lower() in KEEP_WHILE_LISTENING:
            continue
        if device not in devices:
            devices[device] = ElementTree.SubElement(context, device)
        quiet = ElementTree.SubElement(devices[device], element.tag, dict(element.attrib))
        quiet.text = 'noop'
    return ElementTree.tostring(root, encoding='unicode')


def start_listening():
    path = xbmcvfs.translatePath(LISTENING)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write(listening_xml(keymap_files(include_own=True)) + '\n')
    xbmc.executebuiltin('Action(reloadkeymaps)', True)


def stop_listening():
    """Every key back to its job. Also run when the service starts, should Kodi have closed while listening."""
    try:
        os.remove(xbmcvfs.translatePath(LISTENING))
    except FileNotFoundError:
        return
    except OSError:
        return
    xbmc.executebuiltin('Action(reloadkeymaps)', True)


def migrate(preferences):
    """Shortcuts chosen before 0.2.8. Returns a message for the person, or None.

    The long-press presets were written for remotes, where Kodi ignores "long press": they took over the
    normal press of Info or Red. Info is given back; Red stays, written the way Kodi reads it.
    """
    chosen = preferences.get('remote_button')
    if preferences.get('shortcut') or chosen not in ('info', 'red', 'altp', 'own', 'ctrlw'):
        return None
    if chosen == 'info':
        save(None)
        preferences.pop('remote_button', None)
        return ('The Info button has its usual function again. Choose a new shortcut in the Watch Party menu.')
    if chosen == 'red':
        preferences['shortcut'] = {'kind': 'remote', 'name': 'red'}
        save(preferences['shortcut'])
        return None
    if chosen == 'altp':
        preferences['shortcut'] = {'kind': 'keyboard', 'code': ALT_P}
        save(preferences['shortcut'])
        return None
    # A key or button of the person's own choosing was saved as a keyboard key number, a remote button
    # included (so a CoreELEC remote button never worked). The number is still there: write it as Kodi reads it.
    shortcut = _saved_code()
    if shortcut is None:
        return None
    preferences['shortcut'] = shortcut
    save(shortcut)
    preferences['remote_button'] = 'own'
    return None


def _saved_code():
    paths = [xbmcvfs.translatePath(KEYMAP)]
    editor = editor_file()
    if editor:
        paths.append(editor)
    for path in paths:
        try:
            root = ElementTree.parse(path).getroot()
        except (OSError, ElementTree.ParseError):
            continue
        for element in root.iter('key'):
            if _is_ours(element):
                try:
                    return from_code(int(element.get('id')))
                except (TypeError, ValueError):
                    continue
    return None
