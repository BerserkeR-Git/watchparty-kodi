"""Whose move it was: the add-on's own pause, play or jump coming back from Kodi, or the viewer's.

Kodi reports every change of the player as an event, the add-on's own moves included, sometimes seconds late and
out of order (streaming from Plex a seek is reported only once it has completed). The engine tells Movement what it
does (expect, jumped) and what it sees (read, seek_reported), and asks it whether an event is the echo of a move of
its own, whether the player's time jumped with no report yet, and when it last moved or was seen moving.

No Kodi and no party in here: times are the engine's clock in ms, positions are seconds into the title.
"""

# Our own pause, jump or play comes back as a player event within this time.
ECHO_MS = 3000
# Kodi's events can wait this long before they are handled (a request to the server holding up the loop, at most
# 6 s); an expected echo is kept until then, as events are matched by when they happened, not when handled.
LATE_EVENT_MS = 15_000
# A seek event this close to where we jumped is that jump reporting back, not the viewer.
SEEK_ECHO_S = 5.0
# Once a jump's first seek has come back, a further seek is that jump's only this soon after it. The owner's devices
# (diagnostics, 119 jumps of ours, 2026-10-10): one seek each mostly, a second in 7, always within 130 ms of the
# first; the first within 0.3 s (the TV's 95th percentile 266 ms). Later ones near the target came after a second
# jump of ours. Before, any seek near the target for the whole ECHO_MS was taken for ours: a viewer's own Kodi skip
# 1 to 3 s after one of our jumps was never said.
SEEK_ECHO_FOLLOW_MS = 1000
# A seek Kodi reports with the very target of one of our jumps (to the millisecond) is that jump's, however late it
# comes, within this long of the jump. The first WAN test (2026-10-11): Kodi reported a jump's seek 1.7 s late,
# together with the next jump's; taken for the viewer skipping back, it went out to everyone, whose own late reports
# came back the same way, and the party skipped between old spots until the viewers backed out. A viewer's own skip
# never lands on our target to the millisecond. Kodi's reports came up to 16 s late in that test (behind other
# jumps); 10 s let one through as the viewer's skip in the simulation with Plex's timings (round 35).
OWN_JUMP_MS = 20_000
OWN_JUMP_S = 0.005
# No resync is offered this soon after the player's time jumped (a skip, ours or the viewer's): Kodi moves at once but
# may report the seek up to a second later, and meanwhile the player read hundreds of seconds from the party (the WAN
# test's false out-of-sync notices). Falling behind (a stall) builds up; a jump is never that.
OFFER_QUIET_MS = 5000
# How late Kodi's report of a skip is taken to be at most (1.7 s seen over the internet; 4.3 s in the internet
# simulation, a request holding the loop up meanwhile). Played on from its report's spot by more, or moved by a jump
# of the add-on's own since, the player is somewhere else for another reason (the add-on's jump to 1607 said as the
# viewer's skip to 349: F28).
REPORT_LATE_MAX_S = 10.0
# The player's time jumped and Kodi has not reported a seek yet: until it does (or for this long at most) nothing is
# offered, and the add-on does not pull its own viewer back to an earlier skip of theirs. With a request held up the
# report waited 6 s (the service loop with it) and the resync was offered meanwhile (the internet simulation, U2).
UNREPORTED_MAX_MS = 20_000
# Two readings this far apart (allowing for the time between them) mean the player's time jumped.
TIME_JUMP_S = 2.0
# How far from its aim the add-on's own jump may land: up to a keyframe away (2 to 4 s on a TV box) and its lead
# behind (JUMP_LEAD_RANGE_S). Further, read just after the jump, the viewer skipped while the jump waited for Kodi
# (1.5 s streaming from Plex); Kodi's and PM4K's skips move 10 s or more.
JUMP_LANDS_WITHIN_S = 8.0
# Read later than this after the jump, the reading is not compared with the jump's aim.
JUMP_READ_MS = 3000


class Movement:
    def __init__(self, clock):
        self.clock = clock
        self.echo = {}  # event name -> until when a command of ours may still come back as it
        self.first_seek_echo = None  # when the current jump's first seek came back (see SEEK_ECHO_FOLLOW_MS)
        self.jumped_to = None
        self.own_jumps = []  # (target, when) of our recent jumps, to know their seeks however late (OWN_JUMP_MS)
        self.moved_at = 0  # when the player's time last jumped (see OFFER_QUIET_MS)
        self.last_reading = None  # (position, when) last read, to see the time jump
        self.jump_aim = None  # (aim, when) of our own jump while playing, for the next reading
        self.time_jumped = None  # (position, when) the player was first read somewhere new
        self.unreported = None  # when the player's time jumped with no seek reported since (see UNREPORTED_MAX_MS)

    # What the add-on does ------------------------------------------------------------------------------------

    def expect(self, name):
        """A pause, play or jump of ours is on its way: its event coming back is ours, not the viewer's."""
        self.echo[name] = self.clock() + ECHO_MS
        if name == 'seek':
            self.first_seek_echo = None  # a new jump: its first seek has not come back yet

    def jumped(self, target, playing):
        """Our jump to `target` (seconds, not below 0) has been made; `playing` whether the player was playing."""
        now = self.clock()
        self.jumped_to = target
        recent = [(t, at) for t, at in self.own_jumps if now - at <= OWN_JUMP_MS]
        self.own_jumps = recent[-7:] + [(round(target, 3), now)]
        self.moved_at = now
        self.last_reading = None  # our own jump: the next reading starts afresh (not a skip of the viewer's)
        # ...but is compared with where the jump aimed: a skip of the viewer's while the jump waited for Kodi was
        # taken for the jump's landing, and its own earlier skip then pulled the viewer back (the simulation with
        # Plex's timings, round 35).
        self.jump_aim = (target, now) if playing else None

    # What it sees ---------------------------------------------------------------------------------------------

    def read(self, position, now):
        """A reading of the player's time (None while paused): read every moment, to see the time jump. Kodi moves
        at once but may report a skip a second or more later."""
        last, self.last_reading = self.last_reading, (position, now) if position is not None else None
        if position is None:
            return
        aim, self.jump_aim = self.jump_aim, None
        within = TIME_JUMP_S
        if last is None and aim is not None and now - aim[1] <= JUMP_READ_MS:
            last, within = aim, JUMP_LANDS_WITHIN_S
        if last is None or abs(position - (last[0] + (now - last[1]) / 1000.0)) > within:
            self.moved_at = max(self.moved_at, now)  # its time jumped (or was not read just before): a skip
            if last is not None:
                self.time_jumped = (position, now)
                self.unreported = now

    def seek_reported(self, target, now, reading):
        """Kodi reported a seek to `target` (None if it gave none); `reading()` says where the player plays now (None
        while paused), read only if needed. Called for every seek report, ours or not, before asking is_echo."""
        self.moved_at = now
        # A report explains only a jump read near where it went: not the late report of an older skip, nor that
        # of our own jump (two reports came together after the viewer had skipped a third time, and the second
        # skip's state pulled it back: the simulation, round 35).
        explains = (self.unreported is None or self.time_jumped is None or target is None
                    or abs(target - self.time_jumped[0]) <= SEEK_ECHO_S)
        if not explains:
            return
        # Explained: read afresh from here (a report that came before the reading of the jump, as PM4K's do, left
        # the jump read after it for a skip not reported yet: the simulation, round 35). Read now, not at the next
        # reading: a request holding the loop up meanwhile hid a skip made during it.
        self.unreported = None
        here = reading()
        self.last_reading = (here, now) if here is not None else None
        if (here is not None and target is not None
                and not target - SEEK_ECHO_S <= here <= target + SEEK_ECHO_S + REPORT_LATE_MAX_S
                and not self.where_it_was_put(here, now)):
            # Nowhere near where this report says it went, nor where we last put it: the viewer has skipped again
            # since, before any reading saw it (the simulation, round 35). (Where we put it after the skip, the
            # party's state of the skip moves it to where the viewer went.)
            self.time_jumped = (here, now)
            self.unreported = now

    def is_echo(self, name, when, position=None):
        """Whether an event that happened at `when` is a move of ours coming back (for a seek, `position` is the
        target Kodi reported, else where it landed). Takes the echo it matches."""
        if name == 'seek' and position is not None:
            self.own_jumps = [(target, at) for target, at in self.own_jumps if when - at <= OWN_JUMP_MS]
            # Ours, unless its time was read jumping there after our jump: the viewer went there since (a skip back
            # to 0:00, 11 s after we had put the box at 0:00 for a start, was taken for that jump's report: the
            # simulation with the TV's timings, round 35). The TV does report one jump twice, 7 s apart (the WAN
            # test); its time did not jump between the two.
            if any(abs(position - target) <= OWN_JUMP_S and not self._went_there_since(target, at)
                   for target, at in self.own_jumps):
                if (self.jumped_to is not None and abs(position - self.jumped_to) <= OWN_JUMP_S
                        and self.first_seek_echo is None):
                    self.first_seek_echo = when  # the latest jump has told us (see SEEK_ECHO_FOLLOW_MS)
                return True
        deadline = self.echo.get(name)
        if deadline is None or deadline < when:
            return False
        if name == 'seek':
            # One jump can report more than one seek (a long one especially): every seek that lands near where
            # we jumped is ours; one somewhere else is the viewer skipping.
            if position is not None and self.jumped_to is not None and abs(position - self.jumped_to) > SEEK_ECHO_S:
                return False
            if self.first_seek_echo is None:
                self.first_seek_echo = when
            elif when - self.first_seek_echo > SEEK_ECHO_FOLLOW_MS:
                return False  # the jump has told us already: this one is the viewer's
            return True
        del self.echo[name]
        return True

    def new_video(self):
        """A new video started: its time starting elsewhere is no skip (taken for one, the TV was not moved to the
        party it had come back to: the simulation, round 34)."""
        self.last_reading = self.time_jumped = self.unreported = self.jump_aim = None

    def expire(self, now):
        """Echoes expected so long ago that their events can no longer come."""
        for name in [n for n, deadline in self.echo.items() if deadline < now - LATE_EVENT_MS]:
            del self.echo[name]

    # Questions -----------------------------------------------------------------------------------------------

    def not_reported(self, now):
        """The player's time jumped and Kodi has not reported a seek for it yet (for UNREPORTED_MAX_MS at most)."""
        return self.unreported is not None and now - self.unreported < UNREPORTED_MAX_MS

    def quiet(self, now):
        """Too soon after the time jumped, or a jump not reported yet: the distance to the party means nothing."""
        return now - self.moved_at < OFFER_QUIET_MS or self.not_reported(now)

    def expecting_more_than_a_seek(self):
        """A pause or play of ours is still on its way back."""
        return any(name != 'seek' for name in self.echo)

    def moved_since(self, at):
        """Whether we jumped at or after `at`."""
        return any(when >= at for _, when in self.own_jumps)

    def last_jump_at(self):
        """When we last jumped (0 if not lately)."""
        return max([at for _, at in self.own_jumps] or [0])

    def jumped_since(self, at):
        """Whether the player's time was read jumping (not by a jump of ours) after `at`."""
        return bool(self.time_jumped and self.time_jumped[1] > at)

    def seen_near(self, spot):
        """When the player's time was last read jumping to near `spot` (within TIME_JUMP_S), or None."""
        if self.time_jumped and abs(self.time_jumped[0] - spot) <= TIME_JUMP_S:
            return self.time_jumped[1]
        return None

    def where_it_was_put(self, here, now):
        """Whether the player plays on from our last jump (within REPORT_LATE_MAX_S of it)."""
        if not self.own_jumps:
            return False
        aim, at = self.own_jumps[-1]
        return now - at <= REPORT_LATE_MAX_S * 1000 and abs(here - (aim + (now - at) / 1000.0)) <= JUMP_LANDS_WITHIN_S

    def _went_there_since(self, target, at):
        return bool(self.time_jumped and self.time_jumped[1] > at and abs(self.time_jumped[0] - target) <= SEEK_ECHO_S)
