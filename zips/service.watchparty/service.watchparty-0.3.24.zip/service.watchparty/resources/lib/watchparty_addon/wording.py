"""What the viewer reads: every sentence Watch Party puts together from names, titles, devices and times.

Pure: a party or playback from the server's view in, a sentence out. `me` is this device's person, so its own other
devices read as "your laptop", never by the viewer's own name. Fixed sentences with nothing to fill in stay where
they are said.
"""

# Played this long when this device hears about a title, it is "watching", not "starting".
STARTED_A_WHILE_AGO_MS = 30_000


# Parts ----------------------------------------------------------------------------------------------------

def describe(item):
    """A title the way people say it: "Example Show · S2 E3" or the film's title."""
    if not item:
        return ''
    if item.get('show'):
        if item.get('season') is not None and item.get('episode') is not None:
            return '{} · S{} E{}'.format(item['show'], item['season'], item['episode'])
        return item['show']
    return item.get('title') or ''


def clock_label(seconds):
    """Minutes and seconds (hours when there are any); callers add 0.5 to round to the nearest second."""
    seconds = int(max(0, seconds or 0))
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return '{}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{}:{:02d}'.format(minutes, seconds)


def device_label(name):
    """A device's name inside a sentence: "laptop", "living room TV", but "PC" and "iPad" stay as they are."""
    name = name or 'other device'
    if len(name) > 1 and name[0].isupper() and name[1].islower():
        return name[0].lower() + name[1:]
    return name


def sentence(text):
    """Text at the start of a sentence: only the first letter raised ("Your PC", not "Your pc")."""
    return text[:1].upper() + text[1:]


def names(items):
    """"Sam", "Sam and Kim", "Sam, Kim and Alex"; past three, "Sam, Kim and 2 others" (big parties). Each once: someone
    else's devices all go by their name ("waiting for Sam and Sam to open it", the WAN test)."""
    items = [i for i in dict.fromkeys(items) if i]
    if len(items) <= 1:
        return ''.join(items)
    if len(items) > 3:
        return '{}, {} and {} others'.format(items[0], items[1], len(items) - 2)
    return ', '.join(items[:-1]) + ' and ' + items[-1]


# Who --------------------------------------------------------------------------------------------------------

def label(member, me):
    """A member inside a sentence: "your laptop" for one of the viewer's own devices, else the person's name."""
    if member.get('person') == me:
        return 'your ' + device_label(member.get('device_name'))
    return member.get('name') or 'Someone'


def actor(playback, me):
    """Who made a change, at the start of a sentence: "You", "Your laptop" or the person's name."""
    if playback.get('by_me'):
        return 'You'
    if own_device(playback, me) and playback.get('by_device'):
        return 'Your ' + device_label(playback['by_device'])
    return playback.get('by_name') or 'Someone'


def own_device(playback, me):
    """Whether one of the viewer's own devices made the change."""
    return bool(playback.get('by_person') and playback.get('by_person') == me)


def others(party, me):
    """Everyone else in the watch party: "Sam and your laptop", or "the others"."""
    return names([label(m, me) for m in party.get('members', []) if not m.get('me')]) or 'the others'


def host_words(party, me):
    """Whose watch party this is: "Alex's watch party", "the watch party on your laptop", or "your watch party"
    on the host itself (the TV hosting it was told it was in "the watch party on your tv": the simulation)."""
    host = next((m for m in party.get('members', []) if m.get('host')), None)
    if host and host.get('me'):
        return 'your watch party'
    if host and host.get('person') == me:
        return 'the watch party on your ' + device_label(host.get('device_name'))
    name = (host or {}).get('name') or party.get('host_name')
    return "{}'s watch party".format(name) if name else 'the watch party'


# Changes ------------------------------------------------------------------------------------------------

def skipped(who, position):
    return '{} skipped to {}.'.format(who, clock_label(position + 0.5))


def resumed(who):
    return '{} resumed playback.'.format(who)


def returned(who):
    return '{} returned to the video.'.format(who)


def paused(who):
    return '{} paused'.format(who)


def stopped_watching(who, may_control=False, own=False):
    """Someone closed the video; with control, how to go on without them (or without one's own other device)."""
    text = '{} stopped watching.'.format(who)
    if may_control:
        text += ' Press play to continue without {}.'.format('it' if own else 'them')
    return text


def stopped_watching_members(members, me):
    """Several closed the video while the party plays on."""
    return '{} stopped watching.'.format(sentence(names([label(m, me) for m in members])))


def member_news(members, me, words):
    """Who joined, left, lost or regained the connection, said together: "Sam and your laptop joined ..."."""
    return '{} {}.'.format(sentence(names([label(m, me) for m in members])), words)


def cannot_watch(people):
    # Counted as said, like the offline sentence: "Sam and Kim do not have access" (it read "does").
    return '{} {} not have access to this title.'.format(names(people), 'does' if len(set(people)) == 1 else 'do')


def ended_by(name):
    return '{} ended the watch party.'.format(name)


def in_party(party, me, still=False):
    """Joining, or (just started and still in it) being in, a watch party."""
    return ('You are in {}.' if still else 'You joined {}.').format(host_words(party, me))


# Starting, waiting and calling ---------------------------------------------------------------------------------

def starting(party, by, last_item, now):
    """What this device is told about a title the watch party starts, moves on to, or has been watching a while."""
    item = party['item']
    if party.get('can_watch') is False:
        return '{} started a title you do not have access to. You will rejoin when the watch party moves on.'.format(by)
    last = last_item or {}
    if last.get('show') and last.get('show') == item.get('show') and last.get('key') != item.get('key'):
        if item.get('episode') is None:
            episode = describe(item)
        elif item.get('season') is None:
            episode = 'episode {}'.format(item['episode'])  # it read "SNone E2"
        else:
            episode = 'S{} E{}'.format(item['season'], item['episode'])
        return '{} moved on to {}. Open it in Plex to continue watching together.'.format(by, episode)
    playback = party.get('playback') or {}
    if playback.get('state') == 'playing' and now - (playback.get('at') or 0) > STARTED_A_WHILE_AGO_MS:
        return '{} is watching {}. Open it in Plex to join.'.format(by, describe(item))
    return '{} is starting {}. Open it in Plex to watch together.'.format(by, describe(item))


def call(party, by):
    """Calling the viewer to the watch party's title."""
    if party['playback']['state'] == 'waiting':
        return '{} is waiting for you to start {}. Open it in Plex to watch together.'.format(by, describe(party['item']))
    return 'The watch party is watching {}. Open it in Plex to join.'.format(describe(party['item']))


def waiting(party, me, may_control):
    """Held while the watch party waits: for whom, who is offline, and (with control) how to start without them."""
    missing = [m for m in party.get('members', []) if not m.get('me') and not m.get('ready')]
    if not missing:
        return 'Everyone is ready. Starting shortly.'
    here = [label(m, me) for m in missing if m.get('online')]
    away = [label(m, me) for m in missing if not m.get('online')]
    parts = []
    if here:
        parts.append('Waiting for {} to open it.'.format(names(here)))
    if away:
        # Not waited for by the server; said, so nobody waits on someone whose device is off.
        # Counted as said: two of Sam's devices are "Sam is offline", not "Sam are offline".
        parts.append(sentence('{} {} offline.'.format(names(away), 'is' if len(set(away)) == 1 else 'are')))
    text = ' '.join(parts)
    mine = len(missing) == 1 and missing[0].get('person') == me
    return text + ' Press play to start without {}.'.format('it' if mine else 'them') if may_control else text


# Distance ---------------------------------------------------------------------------------------------------

def offer(distance, party, me):
    """The resync offer: `distance` seconds from the watch party (negative: behind)."""
    if distance < 0:
        return 'You are {} seconds behind {}. Press pause to resync.'.format(int(-distance), others(party, me))
    return 'You are {} seconds ahead of {}. Press pause to resync.'.format(int(distance), others(party, me))


def back_in_sync(party, me):
    return 'Back in sync with {}.'.format(others(party, me))


# Invitations and refusals ---------------------------------------------------------------------------------------

def invited(invitation, with_others=False):
    """Who invited this device: "Sam invited you to a watch party." or "Your laptop invited this device ...", and
    with whom else when asked ("... with Kim and Lee.")."""
    if invitation.get('from_me'):
        return 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
    text = '{} invited you to a watch party'.format(invitation.get('from') or 'Someone')
    others = [p for p in invitation.get('people', []) if p and p != invitation.get('from')] if with_others else []
    return text + (' with {}.'.format(names(others)) if others else '.')


def invitation_question(invitation):
    """The question that asks to join: who invited, with whom, and what they are watching, on two lines."""
    text = invited(invitation, with_others=True)
    item = invitation.get('item')
    if item and invitation.get('can_watch') is False:
        text += '[CR]They are watching a title you do not have access to.'
    elif item:
        text += '[CR]They are watching {}.'.format(item.get('show') or item.get('title') or '')
    return text


def refused_during_playback(code, party):
    """A pause, play or skip the server refused: why, or None when there is nothing to say."""
    if code == 'no_invitation':
        return 'That invitation is no longer open. Ask for a new one.'
    if code == 'host_only' and party:
        return 'Only {} can control playback in this watch party.'.format(party.get('host_name') or 'the host')
    if code in ('party_busy', 'other_item') and party and party.get('item'):
        if party['playback']['state'] == 'waiting':
            return 'The watch party is waiting for you on {}. You are watching this video on your own.'.format(
                describe(party['item']))
        return 'The watch party is playing {}. You are watching this video on your own.'.format(describe(party['item']))
    return None
