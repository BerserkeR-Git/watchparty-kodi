"""What Watch Party shows on screen.

During a video, cards are drawn straight onto the player window. Measured on the
CoreELEC box, that leaves the remote with PM4K; a dialog would take it. Outside a
video, Kodi's own notifications are used. Questions (invitations) are dialogs and
are only asked when nothing is playing or the viewer has paused.
"""
import math
import os
import tempfile
import threading
import time

import xbmcgui

from . import card_art
from .engine import device_label

HEADING = 'Watch Party'
PLAYER_WINDOW = 12005
CARD_TINT = 'E6101418'
TITLE_COLOUR = 'FFFFFFFF'
BODY_COLOUR = 'CCFFFFFF'
REPEAT_QUIET_S = 30

# Positions on a 1920 x 1080 window; scaled to the window's real size. Cards sit in the top right corner:
# a lasting card (paused, waiting, an offer) first, a notice below it while both show.
EDGE = {'top': 32, 'right': 32, 'gap': 10}
COUNTDOWN = {'size': 180}
# Kodi's label alignment: left, centred vertically.
ALIGN_LEFT_MIDDLE = 0x00000004


class Card:
    """A set of controls drawn onto the player window, removable as one."""

    def __init__(self, window, controls):
        self.window = window
        self.controls = controls

    def remove(self):
        try:
            self.window.removeControls(self.controls)
        except Exception:  # noqa: BLE001 - the window may already be gone
            pass


class Screen:
    def __init__(self, addon_path, clock, notice_seconds, on_answer, avatar=None, card_folder=None):
        media = os.path.join(addon_path, 'resources', 'media')
        self.card_folder = card_folder or os.path.join(tempfile.gettempdir(), 'watchparty-cards')
        self.square_image = os.path.join(media, 'countdown.png')
        self.mark_image = os.path.join(media, 'mark.png')
        self.mask_image = os.path.join(media, 'avatar-mask.png')
        self.avatar = avatar or (lambda person: None)
        self.icon = os.path.join(addon_path, 'resources', 'icon.png')
        self.clock = clock
        self.notice_seconds = notice_seconds
        self.on_answer = on_answer
        self.lock = threading.RLock()
        self.cards = {}
        self.timers = {}
        self.heights = {}
        self.texts = {}
        self.ends = {}
        self.countdown_at = None
        self.last_notice = ('', 0.0)
        self.last_hold = ('', 0.0)

    # Drawing -------------------------------------------------------------

    @staticmethod
    def _player_window():
        if xbmcgui.getCurrentWindowId() != PLAYER_WINDOW:
            return None
        return xbmcgui.Window(PLAYER_WINDOW)

    def _top(self, slot):
        """Where a card goes: the lasting card at the top, a notice below it while both show."""
        if slot == 'notice' and 'steady' in self.cards:
            return EDGE['top'] + self.heights['steady'] + EDGE['gap']
        return EDGE['top']

    def _draw_card(self, slot, text, person=None):
        window = self._player_window()
        if window is None:
            return None
        scale = window.getHeight() / 1080.0
        shape = card_art.layout(text)
        try:
            image = card_art.card_image(self.card_folder, shape['width'], shape['height'])
        except OSError:
            return None
        width, height = int(shape['width'] * scale), int(shape['height'] * scale)
        x = int(window.getWidth() - (shape['width'] + EDGE['right']) * scale)
        y = int(self._top(slot) * scale)
        icon_x, icon_y, icon = (int(v * scale) for v in shape['icon'])
        text_x, text_y, text_w = (int(v * scale) for v in shape['text'])
        line_h = int(card_art.LINE_H * scale)
        picture = self.avatar(person) if person else None
        controls = [xbmcgui.ControlImage(x, y, width, height, image, colorDiffuse=CARD_TINT)]
        if picture:
            # Kodi cannot crop to a circle; card-coloured corners on top make the picture read as round.
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, picture, aspectRatio=1))
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mask_image))
        else:
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mark_image))
        for number, line in enumerate(shape['lines']):
            controls.append(xbmcgui.ControlLabel(x + text_x, y + text_y + number * line_h, text_w, line_h, line,
                                                 font='font12', textColor=TITLE_COLOUR,
                                                 alignment=ALIGN_LEFT_MIDDLE))
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001 - the player closed in between
            return None
        self.heights[slot] = shape['height']
        return Card(window, controls)

    def _replace(self, slot, text, seconds=None, person=None):
        with self.lock:
            self._remove(slot, relayout=False)
            card = self._draw_card(slot, text, person)
            if card is None:
                return False
            self.cards[slot] = card
            self.texts[slot] = (text, person)
            self.ends[slot] = time.monotonic() + seconds if seconds else None
            if seconds:
                timer = threading.Timer(seconds, self._expire, args=(slot, card))
                timer.daemon = True
                self.timers[slot] = timer
                timer.start()
            if slot == 'steady':
                self._move_notice()
            return True

    def _move_notice(self):
        """Keep a notice that is still showing just below the lasting card, or at the top once that goes."""
        if 'notice' not in self.cards:
            return
        left = (self.ends.get('notice') or 0) - time.monotonic()
        text, person = self.texts['notice']
        self._remove('notice')
        if left > 0.3:
            self._replace('notice', text, left, person)

    def _expire(self, slot, card):
        with self.lock:
            if self.cards.get(slot) is card:
                self._remove(slot)

    def _remove(self, slot, relayout=True):
        timer = self.timers.pop(slot, None)
        if timer:
            timer.cancel()
        card = self.cards.pop(slot, None)
        if card:
            card.remove()
            if slot == 'steady' and relayout:
                self._move_notice()

    # What the engine calls -------------------------------------------------

    def notice(self, text, person=None):
        now = time.monotonic()
        if text == self.last_notice[0] and now - self.last_notice[1] < REPEAT_QUIET_S:
            return
        self.last_notice = (text, now)
        seconds = self.notice_seconds()
        if not self._replace('notice', text, seconds, person):
            xbmcgui.Dialog().notification(HEADING, text, self.icon, int(seconds * 1000), False)

    def _lasting_seconds(self):
        return max(8, 2 * self.notice_seconds())

    def offer(self, text):
        # Shown once for a while, not left on screen: pressing pause still catches up afterwards.
        seconds = self._lasting_seconds()
        if not self._replace('steady', text, seconds):
            xbmcgui.Dialog().notification(HEADING, text, self.icon, int(seconds * 1000), False)

    def clear_offer(self):
        with self.lock:
            self._remove('steady')

    def hold(self, text):
        """Why playback is paused or waiting. Shown for a while, then out of the way; not repeated unchanged."""
        now = time.monotonic()
        seconds = self._lasting_seconds()
        with self.lock:
            if text == self.last_hold[0] and now - self.last_hold[1] < seconds + REPEAT_QUIET_S:
                return
            self.last_hold = (text, now)
        if not self._replace('steady', text, seconds):
            xbmcgui.Dialog().notification(HEADING, text, self.icon, int(seconds * 1000), False)

    def clear_hold(self):
        with self.lock:
            self.last_hold = ('', 0.0)
        self.clear_offer()

    def countdown(self, at, caption='Starting together'):
        with self.lock:
            self.countdown_at = at
        threading.Thread(target=self._run_countdown, args=(at, caption), name='watchparty-countdown',
                         daemon=True).start()

    def clear_countdown(self):
        with self.lock:
            self.countdown_at = None

    def _run_countdown(self, at, caption_text):
        window = self._player_window()
        if window is None:
            return
        scale = window.getHeight() / 1080.0
        size = int(COUNTDOWN['size'] * scale)
        x, y = (window.getWidth() - size) // 2, (window.getHeight() - size) // 2
        number = xbmcgui.ControlLabel(x, y + int(26 * scale), size, int(96 * scale), '', font='font_clock',
                                      textColor=TITLE_COLOUR, alignment=0x00000002)
        caption = xbmcgui.ControlLabel(x, y + int(124 * scale), size, int(34 * scale), caption_text,
                                       font='font10', textColor=BODY_COLOUR, alignment=0x00000002)
        controls = [xbmcgui.ControlImage(x, y, size, size, self.square_image, colorDiffuse=CARD_TINT), number, caption]
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001
            return
        card = Card(window, controls)
        try:
            while True:
                with self.lock:
                    if self.countdown_at != at:
                        break
                left = (at - self.clock()) / 1000.0
                if left <= 0:
                    break
                number.setLabel(str(int(math.ceil(left))))
                time.sleep(0.1)
        finally:
            card.remove()

    def ask(self, invitation):
        threading.Thread(target=self._ask, args=(invitation,), name='watchparty-question', daemon=True).start()

    def _ask(self, invitation):
        if invitation.get('from_me'):
            text = 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
        else:
            others = [p for p in invitation.get('people', []) if p and p != invitation.get('from')]
            text = '{} invited you to a watch party'.format(invitation.get('from') or 'Someone')
            text += ' with {}.'.format(', '.join(others)) if others else '.'
        item = invitation.get('item')
        if item and invitation.get('can_watch') is False:
            text += '[CR]They are watching a title you do not have access to.'
        elif item:
            text += '[CR]They are watching {}.'.format(item.get('show') or item.get('title') or '')
        answer = xbmcgui.Dialog().yesno(HEADING, text, nolabel='Not now', yeslabel='Join')
        self.on_answer(invitation['party'], bool(answer))
