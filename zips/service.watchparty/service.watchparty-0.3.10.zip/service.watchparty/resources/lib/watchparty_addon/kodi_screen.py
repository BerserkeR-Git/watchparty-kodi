"""What Watch Party shows on screen.

During a video, cards are drawn straight onto the player window. Measured on the
CoreELEC box, that leaves the remote with PM4K; a dialog would take it. Outside a
video, Kodi's own notifications are used. Questions (invitations) are dialogs and
are only asked when nothing is playing or the viewer has paused.
"""
import math
import os
import tempfile
import threading
import time

import xbmc
import xbmcgui

from . import card_art
from .engine import device_label

HEADING = 'Watch Party'
PLAYER_WINDOW = 12005
CARD_TINT = 'E6101418'
TITLE_COLOUR = 'FFFFFFFF'
BODY_COLOUR = 'CCFFFFFF'
REPEAT_QUIET_S = 30
# Kodi's own notification beside an invitation question, long enough to see who asks. Joining replaces it with
# the next message; otherwise it runs out.
INVITATION_TOAST_MS = 15_000
# A card that stays until the engine takes it down (an hour at most, should that never happen).
UNTIL_CLEARED_S = 3600
# Kodi's notification is never closed by the add-on (see _toast), so it is kept short: it may run on into a video.
TOAST_MAX_S = 12
# A message stays at least as long as it takes to read (the owner: "too fast to read").
READ_CHARS_PER_S = 15
# Kodi shows a notification only once the one before was drawn in full; one closed early never is, and from then
# on none appears (Kodi's own neither) until Kodi restarts (see _toast). Watched for: a notification asked for and
# Kodi's notification window not seen within TOAST_SEEN_S, STUCK_AFTER times in a row while Kodi draws (no
# screensaver, screen on), and it is noted on the home window for the menu to say (gone again once one shows).
TOAST_SEEN_S = 6
STUCK_AFTER = 2
STUCK_PROPERTY = 'watchparty.notifications_stuck'
# An unanswered question closes when the invitation would have expired anyway (the server keeps one 10 minutes),
# rather than waiting on screen for hours. The invitation stays in the menu until then.
INVITATION_QUESTION_MS = 600_000

# Positions on a 1920 x 1080 window; scaled to the window's real size. One card at a time, top right.
EDGE = {'top': 32, 'right': 32}
COUNTDOWN = {'size': 180}
# Kodi's label alignment: left, centred vertically.
ALIGN_LEFT_MIDDLE = 0x00000004


class Card:
    """A set of controls drawn onto the player window, removable as one."""

    def __init__(self, window, controls):
        self.window = window
        self.controls = controls

    def remove(self):
        try:
            self.window.removeControls(self.controls)
        except Exception:  # noqa: BLE001 - the window may already be gone
            pass


class Screen:
    """One card at a time in the top right corner.

    A lasting card says why playback is held (paused, waiting, an offer to catch up) and leaves after a while.
    A notice takes the corner for a few seconds; a lasting card that still applies comes back after it.
    """

    def __init__(self, addon_path, clock, notice_seconds, on_answer, avatar=None, card_folder=None, log=None,
                 on_stuck=None):
        self.toast_check = None  # when Kodi's notification window should have been seen by (see _watch_toast)
        self.toast_misses = 0
        self.on_stuck = on_stuck
        media = os.path.join(addon_path, 'resources', 'media')
        self.card_folder = card_folder or os.path.join(tempfile.gettempdir(), 'watchparty-cards')
        self.square_image = os.path.join(media, 'countdown.png')
        self.mark_image = os.path.join(media, 'mark.png')
        self.mask_image = os.path.join(media, 'avatar-mask.png')
        self.avatar = avatar or (lambda person: None)
        self.icon = os.path.join(addon_path, 'resources', 'icon.png')
        self.clock = clock
        self.notice_seconds = notice_seconds
        self.on_answer = on_answer
        self.log = log or (lambda text: None)
        self.lock = threading.RLock()
        self.shown = None
        self.steady = None
        self.countdown_at = None
        self.last_notice = ('', 0.0)
        self.last_hold = ('', 0.0)
        # Kodi's own notification, used outside video: what it says and until when (it would stay on into a
        # video that starts meanwhile, at the skin's spot, which looks wrong over a film).
        self.toast = None

    # Drawing -------------------------------------------------------------

    @staticmethod
    def _player_window():
        if xbmcgui.getCurrentWindowId() != PLAYER_WINDOW:
            return None
        return xbmcgui.Window(PLAYER_WINDOW)

    def _draw_card(self, text, person=None):
        window = self._player_window()
        if window is None:
            return None
        scale = window.getHeight() / 1080.0
        shape = card_art.layout(text)
        try:
            image = card_art.card_image(self.card_folder, shape['width'], shape['height'])
        except OSError:
            return None
        width, height = int(shape['width'] * scale), int(shape['height'] * scale)
        x = int(window.getWidth() - (shape['width'] + EDGE['right']) * scale)
        y = int(EDGE['top'] * scale)
        icon_x, icon_y, icon = (int(v * scale) for v in shape['icon'])
        text_x, text_y, text_w = (int(v * scale) for v in shape['text'])
        line_h = int(card_art.LINE_H * scale)
        pictures = self._pictures(person) if person else []
        controls = [xbmcgui.ControlImage(x, y, width, height, image, colorDiffuse=CARD_TINT)]
        if len(pictures) > 1:
            # Two people (or more): two smaller pictures, overlapping corner to corner in the picture's place.
            small = int(icon * 0.68)
            for picture, (dx, dy) in zip(pictures, ((0, 0), (icon - small, icon - small))):
                controls.append(xbmcgui.ControlImage(x + icon_x + dx, y + icon_y + dy, small, small, picture,
                                                     aspectRatio=1))
                controls.append(xbmcgui.ControlImage(x + icon_x + dx, y + icon_y + dy, small, small, self.mask_image))
        elif pictures:
            # Kodi cannot crop to a circle; card-coloured corners on top make the picture read as round.
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, pictures[0], aspectRatio=1))
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mask_image))
        else:
            controls.append(xbmcgui.ControlImage(x + icon_x, y + icon_y, icon, icon, self.mark_image))
        for number, line in enumerate(shape['lines']):
            controls.append(xbmcgui.ControlLabel(x + text_x, y + text_y + number * line_h, text_w, line_h, line,
                                                 font='font12', textColor=TITLE_COLOUR,
                                                 alignment=ALIGN_LEFT_MIDDLE))
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001 - the player closed in between
            return None
        # Something drawn over the player window (PM4K's own controls are a dialog) would hide the card.
        self.log('card drawn, dialog on top: {}'.format(xbmcgui.getCurrentWindowDialogId()))
        return Card(window, controls)

    def _show(self, kind, text, person, seconds):
        self._take_down()
        card = self._draw_card(text, person)
        if card is None:
            return False
        timer = threading.Timer(seconds, self._expire, args=(card,))
        timer.daemon = True
        self.shown = {'kind': kind, 'card': card, 'timer': timer}
        timer.start()
        return True

    def _take_down(self):
        if self.shown:
            self.shown['timer'].cancel()
            self.shown['card'].remove()
            self.shown = None

    def _expire(self, card):
        with self.lock:
            if not self.shown or self.shown['card'] is not card:
                return
            kind = self.shown['kind']
            self._take_down()
            if kind == 'notice':
                self._bring_back_steady()
            else:
                self.steady = None

    def _bring_back_steady(self):
        if not self.steady:
            return
        left = self.steady['end'] - time.monotonic()
        if left > 0.5:
            self._show('steady', self.steady['text'], None, left)
        else:
            self.steady = None

    # What the engine calls -------------------------------------------------

    def notice(self, text, person=None, seconds=None):
        """Returns how it was shown: 'card', 'kodi' (Kodi's notification) or 'repeat' (not shown again)."""
        now = time.monotonic()
        with self.lock:
            if text == self.last_notice[0] and now - self.last_notice[1] < REPEAT_QUIET_S:
                return 'repeat'
            self.last_notice = (text, now)
            seconds = max(seconds or self.notice_seconds(), min(TOAST_MAX_S, len(text) / READ_CHARS_PER_S))
            if self._show('notice', text, person, seconds):
                return 'card'
            self._toast('notice', text, person, seconds)
            self.log('notification: ' + text[:60])
            return 'kodi'

    def _pictures(self, person):
        """Pictures for one person or several (the first two that have one)."""
        people = [person] if isinstance(person, str) else list(person or [])
        found = []
        for someone in people:
            picture = self.avatar(someone) if someone else None
            if picture and picture not in found:
                found.append(picture)
            if len(found) == 2:
                break
        return found

    def _watch_toast(self):
        """Run often: was Kodi's notification window seen since one was asked for?"""
        if self.toast_check is None:
            return
        if xbmc.getCondVisibility('Window.IsVisible(notification)'):
            self.toast_check, self.toast_misses = None, 0
            if xbmcgui.Window(10000).getProperty(STUCK_PROPERTY):
                xbmcgui.Window(10000).clearProperty(STUCK_PROPERTY)
                self.log('Kodi shows notifications again')
            return
        if xbmc.getCondVisibility('System.ScreenSaverActive') or xbmc.getCondVisibility('System.DPMSActive'):
            self.toast_check = time.monotonic() + TOAST_SEEN_S  # not drawing: nothing to judge yet
            return
        if time.monotonic() < self.toast_check:
            return
        self.toast_check = None
        self.toast_misses += 1
        if self.toast_misses >= STUCK_AFTER and not xbmcgui.Window(10000).getProperty(STUCK_PROPERTY):
            xbmcgui.Window(10000).setProperty(STUCK_PROPERTY, '1')
            self.log('Kodi did not show its notifications: they stay hidden until Kodi restarts')
            if self.on_stuck:
                self.on_stuck()

    def _toast(self, kind, text, person, seconds):
        # Never closed early (no Dialog.Close): Kodi shows the next notification only once the current one has been
        # drawn in full, and one closed while its text still scrolled never is, so every notification after it,
        # Kodi's own too, waited unseen until Kodi restarted (the owner's CoreELEC box, whose skin scrolls longer
        # lines). A newer notification still replaces it, once it has been read.
        seconds = min(seconds, TOAST_MAX_S)
        self.toast = {'kind': kind, 'text': text, 'person': person, 'end': time.monotonic() + seconds}
        if self.toast_check is None:
            self.toast_check = time.monotonic() + TOAST_SEEN_S
        pictures = self._pictures(person) if person else []
        # The person's picture where Kodi shows the icon: whom it is about, at a glance.
        xbmcgui.Dialog().notification(HEADING, text, pictures[0] if pictures else self.icon, int(seconds * 1000),
                                      False)

    def clear_notice(self):
        """Take a notice down before its time (what it said no longer applies)."""
        with self.lock:
            # Kodi's own notification is left to run out (see _toast); marked, so a video starting meanwhile
            # does not bring it back as a card.
            if self.toast and self.toast['kind'] == 'notice':
                self.toast['stale'] = True
            if self.shown and self.shown['kind'] == 'notice':
                self._take_down()
                self._bring_back_steady()

    def tick(self):
        """Run often: forget Kodi's notification once it has run out. One still up when a video starts stays
        (never closed early, see _toast) and is not repeated as a card."""
        with self.lock:
            if self.toast and (self.toast['end'] <= time.monotonic() or self._player_window() is not None):
                self.toast = None
            self._watch_toast()

    def _lasting_seconds(self):
        return max(8, 2 * self.notice_seconds())

    def _lasting(self, text, seconds=None):
        seconds = seconds or self._lasting_seconds()
        with self.lock:
            self.steady = {'text': text, 'end': time.monotonic() + seconds}
            if self.shown and self.shown['kind'] == 'notice':
                return  # it comes up once the notice has had its time
            if self._show('steady', text, None, seconds):
                return
            # Kodi's notification is not meant to stay up: a lasting reason gets half a minute there.
            self._toast('steady', text, None, min(seconds, TOAST_MAX_S))

    def offer(self, text):
        # Shown once for a while, not left on screen: pressing pause still catches up afterwards.
        self._lasting(text)

    def clear_offer(self):
        with self.lock:
            self.steady = None
            if self.shown and self.shown['kind'] == 'steady':
                self._take_down()
            if self.toast and self.toast['kind'] == 'steady':
                self.toast['stale'] = True  # left to run out (see clear_notice)

    def hold(self, text, until_cleared=False):
        """Why playback is paused or waiting. Shown for a while, then out of the way; not repeated unchanged.

        until_cleared: stays until the engine clears it (waiting for someone: the reason lasts as long as the wait).
        """
        now = time.monotonic()
        seconds = UNTIL_CLEARED_S if until_cleared else self._lasting_seconds()
        with self.lock:
            if text == self.last_hold[0] and now - self.last_hold[1] < seconds + REPEAT_QUIET_S:
                return
            self.last_hold = (text, now)
        self._lasting(text, seconds)

    def clear_hold(self):
        with self.lock:
            self.last_hold = ('', 0.0)
        self.clear_offer()

    def close(self):
        """Take everything off the screen and forget it (the connection ended)."""
        with self.lock:
            self.steady = None
            self._take_down()
            self.countdown_at = None

    def countdown(self, at, caption='Starting'):
        with self.lock:
            if self.countdown_at == at:
                return  # already counting down to this moment (a skip during it moves the spot, not the moment)
            self.countdown_at = at
        threading.Thread(target=self._run_countdown, args=(at, caption), name='watchparty-countdown',
                         daemon=True).start()

    def clear_countdown(self):
        with self.lock:
            self.countdown_at = None

    def _run_countdown(self, at, caption_text):
        window = self._player_window()
        if window is None:
            return
        scale = window.getHeight() / 1080.0
        size = int(COUNTDOWN['size'] * scale)
        x, y = (window.getWidth() - size) // 2, (window.getHeight() - size) // 2
        number = xbmcgui.ControlLabel(x, y + int(26 * scale), size, int(96 * scale), '', font='font_clock',
                                      textColor=TITLE_COLOUR, alignment=0x00000002)
        caption = xbmcgui.ControlLabel(x, y + int(124 * scale), size, int(34 * scale), caption_text,
                                       font='font10', textColor=BODY_COLOUR, alignment=0x00000002)
        controls = [xbmcgui.ControlImage(x, y, size, size, self.square_image, colorDiffuse=CARD_TINT), number, caption]
        try:
            window.addControls(controls)
        except Exception:  # noqa: BLE001
            return
        card = Card(window, controls)
        try:
            while True:
                with self.lock:
                    if self.countdown_at != at:
                        break
                left = (at - self.clock()) / 1000.0
                if left <= 0:
                    break
                number.setLabel(str(int(math.ceil(left))))
                time.sleep(0.1)
        finally:
            card.remove()

    def ask(self, invitation):
        threading.Thread(target=self._ask, args=(invitation,), name='watchparty-question', daemon=True).start()

    def _ask(self, invitation):
        if invitation.get('from_me'):
            text = 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
        else:
            others = [p for p in invitation.get('people', []) if p and p != invitation.get('from')]
            text = '{} invited you to a watch party'.format(invitation.get('from') or 'Someone')
            text += ' with {}.'.format(', '.join(others)) if others else '.'
        item = invitation.get('item')
        if item and invitation.get('can_watch') is False:
            text += '[CR]They are watching a title you do not have access to.'
        elif item:
            text += '[CR]They are watching {}.'.format(item.get('show') or item.get('title') or '')
        # Kodi's own notification as well: it shows above every add-on window, should PM4K's screens hide the
        # question (the owner saw nothing on the CoreELEC box at times). Not closed on the answer (see _toast).
        xbmcgui.Dialog().notification(HEADING, text.split('[CR]')[0], self.icon, INVITATION_TOAST_MS, True)
        self.log('invitation question shown, dialog on top: {}'.format(xbmcgui.getCurrentWindowDialogId()))
        answer = xbmcgui.Dialog().yesno(HEADING, text, nolabel='Not now', yeslabel='Join',
                                        autoclose=INVITATION_QUESTION_MS)
        self.log('invitation answered: {}'.format('join' if answer else 'not now'))
        self.on_answer(invitation['party'], bool(answer))
