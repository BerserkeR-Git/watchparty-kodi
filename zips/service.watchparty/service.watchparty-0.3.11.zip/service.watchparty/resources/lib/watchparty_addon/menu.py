"""The Watch Party menu, opened from Add-ons: Watch Party's own wide window (the status at the top, the rows with their
value on the right, the focused row's explanation at the bottom), and Kodi's own dialogs for questions and typing."""
import json
import os
import threading
import time
import traceback
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import shortcut, updates
from .avatars import Avatars
from .client import AddressProblem, Client
from .engine import SendError, describe, device_label, names

HEADING = 'Watch Party'
RELOAD_PROPERTY = 'watchparty.reload'
# Set when an update is started here; the service says whether it arrived (Service._check_update_request).
UPDATE_PROPERTY = 'watchparty.update'
# Set once anything is done here: a watch party joined or started from the menu is not "from before Kodi started".
ACTED_PROPERTY = 'watchparty.acted'
# Set by the service when Kodi stopped showing notifications (kodi_screen.STUCK_PROPERTY).
STUCK_PROPERTY = 'watchparty.notifications_stuck'
# Ready-made shortcuts: (kind, name, where, shortcut). Kodi cannot tell a long press of a remote button from a
# short one, so none of these is a long press. Red opens TV channels by default, which PM4K viewers do not use.
PRESETS = (
    ('altp', 'Alt+P', 'Keyboard', {'kind': 'keyboard', 'code': shortcut.ALT_P}),
    ('red', 'Red button', 'Remote control', {'kind': 'remote', 'name': 'red'}),
)
# Keys nobody should lose (Kodi action numbers): moving around (1-6), OK (7), back (9, 10, 92), pause (12),
# stop (13), next and previous (14, 15), fast forward and rewind (16, 17, 77, 78), the menu (18), jumps (20-23),
# the player controls (24), play (79), play/pause (229), volume (88, 89, 91) and the context menu (117).
PROTECTED_ACTIONS = {1, 2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 77, 78, 79, 88, 89,
                     91, 92, 117, 229}
CANCEL_ACTIONS = {10, 92}
LISTEN_S = 15
# How long Kodi gets to look at its repositories before its list of updates is opened.
UPDATE_WAIT_S = 6
# The menu window (resources/skins/default/1080i/watchparty-menu.xml) and its controls.
WINDOW = 'watchparty-menu.xml'
TITLE, LIST = 10, 100
STATUS = ((21, 22), (23, 24))


class KeyListener(xbmcgui.WindowXMLDialog):
    """Waits for one key, key combination or button, on Watch Party's own small screen (the same on every skin).

    Meanwhile every key's own job is switched off (shortcut.start_listening), so the key pressed does nothing
    else: before, the red button also opened TV channels, over the question that followed.
    """

    def __new__(cls, addon_path=''):
        return super().__new__(cls, 'watchparty-shortcut.xml', addon_path, 'default', '1080i')

    def __init__(self, addon_path=''):
        self.code = None
        self.action = None
        self.cancelled = False
        self.done = threading.Event()

    def _label(self, control, text):
        try:
            self.getControl(control).setLabel(text)
        except (RuntimeError, AttributeError, TypeError):
            pass

    def onInit(self):
        self._label(2, 'Press a key, key combination or remote button')
        threading.Thread(target=self._count_down, name='watchparty-listen', daemon=True).start()

    def _count_down(self):
        deadline = time.monotonic() + LISTEN_S
        while not self.done.is_set():
            left = deadline - time.monotonic()
            if left <= 0:
                self.close()
                return
            self._label(3, 'Press Back to cancel. Closes in {} seconds.'.format(int(left + 0.999)))
            self.done.wait(0.25)

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True
        else:
            code = action.getButtonCode()
            if not code or shortcut.modifier_only(code):
                return  # Ctrl, Alt or Shift on its own: wait for the key that goes with it
            self.code, self.action = code, action.getId()
        self.close()

    @classmethod
    def listen(cls, addon_path=''):
        shortcut.start_listening()
        try:
            dialog = cls(addon_path)
            dialog.doModal()
            dialog.done.set()
            return dialog.code, dialog.action, dialog.cancelled
        finally:
            shortcut.stop_listening()

PROBLEMS = {
    'offline': 'Watch Party cannot be reached right now. Check the internet connection and try again.',
    # One refusal is not a disconnection: a mistake on the server refuses for a while too. The service gives up only
    # after 10 refusals over 10 minutes, and then the menu offers to connect again.
    'disconnected': ('Watch Party did not accept this device just now. Try again in a few minutes. If it keeps '
                     'happening, ask for a new connection code.'),
    'wrong_code': 'That code was not accepted. A code can be used once and expires after a few minutes; ask for a new one.',
    'party_full': 'The watch party is full.',
    'nobody_to_invite': 'Everyone you chose is already in the watch party, or has no other device connected.',
    'no_invitation': 'That invitation is no longer open. Ask for a new one.',
    'host_only': 'Only the host can do that.',
    'not_in_party': 'You are not in a watch party.',
}


def tell(text):
    xbmcgui.Dialog().ok(HEADING, text)


def problem(error):
    tell(PROBLEMS.get(error.code, 'Something went wrong. Try again in a moment.'))


def reload_service():
    xbmcgui.Window(10000).setProperty(RELOAD_PROPERTY, str(time.time()))


def item(label, label2='', icon=None):
    entry = xbmcgui.ListItem(label, label2)
    if icon:
        entry.setArt({'icon': icon, 'thumb': icon})
    return entry


class Row:
    """One line of a menu window: its label, its value on the right, the explanation shown while it is focused, and
    what a press does. An action closes the window and runs; a switch changes the value in place (returning the new
    value) and the window stays open; a row with neither only informs."""

    def __init__(self, label, value='', help_text='', action=None, switch=None, icon=None, key=None):
        self.label, self.value, self.help = label, value, help_text
        self.action, self.switch, self.icon, self.key = action, switch, icon, key


class MenuWindow(xbmcgui.WindowXMLDialog):
    """Watch Party's own menu window, the same on every skin and wide enough for names and titles. The list is filled
    once; a switch changes only its own row, so the highlight and the explanation stay where they are."""

    def __new__(cls, title, rows, status=(), addon_path=''):
        return super().__new__(cls, WINDOW, addon_path, 'default', '1080i')

    def __init__(self, title, rows, status=(), addon_path=''):
        self.title, self.rows, self.status = title, rows, list(status)[:len(STATUS)]
        self.items = []
        self.chosen = None

    def onInit(self):
        self.getControl(TITLE).setLabel(self.title)
        for index, (label_id, value_id) in enumerate(STATUS):
            label, value = self.status[index] if index < len(self.status) else ('', '')
            self.getControl(label_id).setLabel(label)
            self.getControl(value_id).setLabel(value)
        listing = self.getControl(LIST)
        for row in self.rows:
            entry = item(row.label, row.value, row.icon)
            entry.setProperty('help', row.help)
            self.items.append(entry)
            listing.addItem(entry)
        self.setFocusId(LIST)

    def onClick(self, control_id):
        if control_id != LIST:
            return
        position = self.getControl(LIST).getSelectedPosition()
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        if row.switch:
            row.value = row.switch()
            self.items[position].setLabel2(row.value)
        elif row.action:
            self.chosen = row
            self.close()

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.close()


def choose(title, rows, status=()):
    """Shows a menu window; the row whose action was chosen, or None (Back)."""
    window = MenuWindow(title, rows, status, xbmcaddon.Addon().getAddonInfo('path'))
    window.doModal()
    chosen = window.chosen
    del window
    return chosen


class Menu:
    def __init__(self, storage, addon_icon, version='0.0.0'):
        self.storage = storage
        self.addon_icon = addon_icon
        self.version = version
        self.opener = urllib.request.urlopen

    # Connecting ------------------------------------------------------------

    def connect(self):
        previous = self.storage.preferences().get('last_address', '')
        address = xbmcgui.Dialog().input('Watch Party address, for example sync.example.com', defaultt=previous)
        if not address:
            return
        try:
            client = Client(address, version=self.version)
        except AddressProblem as error:
            tell(str(error))
            return
        code = xbmcgui.Dialog().input('Connection code, for example K7QM-3XPD')
        if not code:
            return
        try:
            paired = client.pair(code)
        except SendError as error:
            problem(error)
            return
        self.storage.save_device({'address': client.address, 'device': paired['device'], 'secret': paired['secret'],
                                  'generation': paired.get('generation', 0),
                                  'name': paired.get('name', ''), 'device_name': paired.get('device_name', '')})
        preferences = self.storage.preferences()
        preferences['last_address'] = client.address.split('://', 1)[1]
        self.storage.save_preferences(preferences)
        self.storage.mark_used()  # connected just now: online for the admin's window
        reload_service()
        tell('Connected as {} for {}. You can now start or join watch parties.'.format(
            paired.get('device_name') or 'this device', paired.get('name') or 'you'))

    def disconnect(self):
        if xbmcgui.Dialog().yesno(HEADING, 'Disconnect this device from Watch Party? To use it again, you need a new '
                                           'connection code from your Watch Party administrator.',
                                  nolabel='Cancel', yeslabel='Disconnect'):
            self.storage.forget_device()
            reload_service()

    # The main menu -----------------------------------------------------------

    def run(self):
        """The menu. An unexpected problem is said plainly (not Kodi's script error), its details logged."""
        try:
            self._run()
        except Exception:  # noqa: BLE001 - whatever it was, the viewer gets a plain message
            xbmc.log('[Watch Party] menu failed:\n' + traceback.format_exc(), xbmc.LOGERROR)
            tell("Watch Party ran into a problem. The details are in Kodi's log.")

    def _run(self):
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            if device and device.get('unreadable'):
                text = ("This device's connection was made on another machine and cannot be used here. "
                        'Connect it with a new code.')
            else:
                text = ('This device was disconnected. ' if device else '') + 'Connect it with the code you were given.'
            if xbmcgui.Dialog().yesno(HEADING, text, nolabel='Cancel', yeslabel='Connect'):
                self.connect()
            return
        # Opened: this device is online for the admin's window from now (the service notices and connects).
        self.storage.mark_used()
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        self.avatars = Avatars(self.storage.avatar_folder, client)
        try:
            state = client.state(0)
        except SendError as error:
            problem(error)
            return
        self.main(client, state)

    def main(self, client, state):
        party = state.get('party')
        rows = []
        if xbmcgui.Window(10000).getProperty(STUCK_PROPERTY):
            # Kodi keeps notifications hidden from then on (its own as well); only a restart brings them back.
            rows.append(Row('Notifications are not showing', 'Restart Kodi',
                            'Kodi has stopped showing notifications, its own as well. Restarting Kodi brings them back.',
                            action=lambda: tell('Kodi has stopped showing notifications, its own as well. Restart '
                                                'Kodi to bring them back.')))
        if party:
            rows.append(Row('Invite people', '', 'Add people to this watch party. They start together with everyone.',
                            action=lambda: self.invite(client, state)))
            rows.append(Row('Leave watch party', '', 'The others continue without you.', action=lambda: self.leave(client)))
            if party.get('i_am_host'):
                rows.append(Row('End watch party', '', 'Ends the watch party for everyone.',
                                action=lambda: self.end(client)))
        else:
            rows.append(Row('Start a watch party', '', 'Choose who to invite. Playback starts, pauses and skips for '
                                                       'everyone at the same time.',
                            action=lambda: self.invite(client, state)))
        for joinable in state.get('joinable', []):
            rows.append(Row('Join the watch party on your {}'.format(device_label(joinable.get('device_name'))),
                            describe(joinable.get('item')) or 'No invitation needed',
                            'Your own devices can join each other\'s watch party without an invitation.',
                            action=lambda j=joinable: self.act(
                                client, {'type': 'respond', 'party': j['party'], 'accept': True})))
        for invitation in state.get('invitations', []):
            if invitation.get('from_this_device'):
                label = 'Return to your watch party'  # started here, then left
            elif invitation.get('from_me'):
                label = 'Join the watch party from your {}'.format(device_label(invitation.get('from_device')))
            else:
                label = 'Join {}\'s watch party'.format(invitation['from'])
            help_text = 'Joins this watch party.'
            if invitation.get('can_watch') is False:
                help_text += ' It is watching a title you do not have access to.'
            # The service says "You joined ..." once the server confirms; saying it here too showed it twice.
            rows.append(Row(label, ', '.join(invitation.get('people', [])), help_text, action=lambda i=invitation: self.act(
                client, {'type': 'respond', 'party': i['party'], 'accept': True})))
        preferences = self.storage.preferences()
        rows.append(Row('Do not disturb', 'On' if preferences.get('do_not_disturb') else 'Off',
                        'While it is on, invitations are not shown on screen. They still wait here in the menu.',
                        switch=self.toggle_dnd))
        rows.append(Row('People', self.online_summary(state), 'Who is online, and what they are watching.',
                        action=lambda: self.people(client, state)))
        rows.append(Row('Shortcut', self.shortcut_label(preferences),
                        'A key or remote button that opens Watch Party from anywhere, also during a video.',
                        action=lambda: self.remote_button(self.storage.preferences())))
        rows.append(Row('Disconnect this device', '', 'To use it again, you need a new connection code from your Watch '
                                                      'Party administrator.', action=self.disconnect))
        rows.append(Row('Check for updates', self.update_label(preferences),
                        'Looks for a newer version of Watch Party and installs it.',
                        action=lambda: self.check_updates(self.storage.preferences())))
        me = state.get('me', {})
        status = [('Connected as', '{} for {}'.format(self.storage.device().get('device_name') or 'This device',
                                                      me.get('name', '')))]
        if party:
            others = [m['name'] if m['person'] != state['me']['person'] else 'your ' + device_label(m['device_name'])
                      for m in party['members'] if not m['me']]
            watching = describe(party.get('item')) or 'No title selected yet'
            status.append(('In a watch party', ('With ' + names(others) + ' \u00b7 ' if others else '') + watching))
        else:
            status.append(('Watch party', 'Not in a watch party'))
        chosen = choose('{} {}'.format(HEADING, self.version), rows, status)
        if chosen:
            chosen.action()

    # Updates -------------------------------------------------------------------

    def update_label(self, preferences):
        known = preferences.get('latest_version')
        if known and updates.newer(known, self.version):
            return 'Version {} is available. This device has {}.'.format(known, self.version)
        return 'Version {} installed'.format(self.version)

    @staticmethod
    def _repository_xml():
        try:
            path = xbmcaddon.Addon(updates.REPOSITORY_ID).getAddonInfo('path')
            with open(os.path.join(xbmcvfs.translatePath(path), 'addon.xml'), encoding='utf-8') as handle:
                return handle.read()
        except (RuntimeError, OSError):
            return None

    @staticmethod
    def _auto_update_mode():
        """Kodi's own setting: 0 installs updates by itself, 1 only tells, 2 never looks."""
        try:
            answer = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                'params': {'setting': 'general.addonupdates'}})))
            return int(answer['result']['value'])
        except (ValueError, KeyError, TypeError):
            return None

    def check_updates(self, preferences):
        repository = self._repository_xml()
        if repository is None:
            tell('Updates come through the Watch Party Repository, which is not installed on this device. '
                 'Install it the same way you installed Watch Party.')
            return
        try:
            available = updates.latest(repository, opener=self.opener)
        except updates.UpdateProblem as error:
            tell(str(error))
            return
        self._save(preferences, {'latest_version': available})
        if not updates.newer(available, self.version):
            tell('Watch Party is up to date (version {}).'.format(self.version))
            return
        if not xbmcgui.Dialog().yesno(HEADING, 'Watch Party {} is available. This device has {}. Update now?'.format(
                available, self.version), nolabel='Later', yeslabel='Update'):
            return
        mode = self._auto_update_mode()
        if mode == 0:
            # Noted only here: in Kodi's own list the person decides, and may well choose not to (or later).
            xbmcgui.Window(10000).setProperty(UPDATE_PROPERTY, json.dumps({'version': available, 'at': time.time()}))
            # With automatic updates Kodi installs it and restarts Watch Party by itself. Kodi waits for this menu
            # to close before it replaces Watch Party, so nothing here may wait for an answer: an OK dialog froze
            # the laptop until the update was done, and stayed behind on the TV.
            xbmcgui.Dialog().notification(HEADING, 'Updating to version {}. Watch Party restarts by itself.'.format(
                available), self.addon_icon, 8000, False)
            xbmc.executebuiltin('UpdateAddonRepos')
            return
        # Kodi looks at repositories only once a day; this makes it look now.
        xbmc.executebuiltin('UpdateAddonRepos')
        progress = xbmcgui.DialogProgress()
        progress.create(HEADING, 'Kodi is looking for the update.')
        monitor = xbmc.Monitor()
        for step in range(UPDATE_WAIT_S):
            progress.update(int(100 * (step + 1) / UPDATE_WAIT_S))
            if progress.iscanceled() or monitor.waitForAbort(1):
                break
        progress.close()
        tell('Kodi now shows its list of available updates. Choose Watch Party there, then Update.')
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/,return)')

    # Actions -------------------------------------------------------------------

    def act(self, client, payload, success=None):
        try:
            client.act(payload)
        except SendError as error:
            problem(error)
            return False
        xbmcgui.Window(10000).setProperty(ACTED_PROPERTY, '1')
        if success:
            xbmcgui.Dialog().notification(HEADING, success, self.addon_icon, 4000, False)
        return True

    def leave(self, client):
        if xbmcgui.Dialog().yesno(HEADING, 'Leave the watch party? The others continue without you.',
                                  nolabel='Cancel', yeslabel='Leave'):
            self.act(client, {'type': 'leave'})

    def end(self, client):
        if xbmcgui.Dialog().yesno(HEADING, 'End the watch party for everyone?', nolabel='Cancel', yeslabel='End it'):
            self.act(client, {'type': 'end'})

    def _save(self, preferences, changes=None, remove=()):
        """Change only these keys, on what is on disk now: the menu may have been open for minutes, and the
        service saves what it learns (jump, skip and play leads) meanwhile."""
        changes = changes or {}
        preferences.update(changes)
        for key in remove:
            preferences.pop(key, None)
        current = self.storage.preferences()
        current.update(changes)
        for key in remove:
            current.pop(key, None)
        self.storage.save_preferences(current)

    def toggle_dnd(self):
        """Do not disturb on or off; returns the new value as the menu shows it."""
        wanted = not self.storage.preferences().get('do_not_disturb')
        self._save(self.storage.preferences(), {'do_not_disturb': wanted})
        return 'On' if wanted else 'Off'


    def invite(self, client, state):
        people = [p for p in state.get('people', []) if not p.get('in_my_party') or p.get('me')]
        if not people:
            tell('There is nobody to invite yet. Ask your Watch Party administrator to add people.')
            return
        entries = [item('Your other devices' if p.get('me') else p['name'], self.status_line(p),
                        self.avatar(client, p)) for p in people]
        chosen = xbmcgui.Dialog().multiselect('Who do you want to watch with?', entries, useDetails=True)
        if not chosen:
            return
        chosen_names = [people[i]['name'] if not people[i].get('me') else 'your other devices' for i in chosen]
        sent = 'Invitation sent to {}.'.format(names(chosen_names))
        # A device not used lately is quiet and shows offline; the invitation waits for them in the menu.
        away = [people[i]['name'] for i in chosen if not people[i].get('me') and not people[i].get('online')]
        if away:
            sent += ' {} {} not online and will see it in the Watch Party menu.'.format(
                names(away), 'is' if len(away) == 1 else 'are')
        self.act(client, {'type': 'invite', 'people': [people[i]['id'] for i in chosen]},
                 sent if state.get('party') else 'Watch party started. ' + sent)

    def people(self, client, state):
        rows = [Row(p['name'] + (' (you)' if p.get('me') else ''), self.status_line(p), icon=self.avatar(client, p))
                for p in state.get('people', [])]
        online = sum(1 for p in state.get('people', []) if p.get('online') and not p.get('me'))
        choose('People', rows, [('Online now', '{} of {}'.format(online, max(0, len(rows) - 1)))])

    @staticmethod
    def status_line(person):
        if not person.get('online'):
            return 'Not online'
        if person.get('watching'):
            return 'Watching ' + describe(person['watching'])
        return 'Online' + (' · in your watch party' if person.get('in_my_party') and not person.get('me') else '')

    @staticmethod
    def online_summary(state):
        online = [p['name'] for p in state.get('people', []) if p.get('online') and not p.get('me')]
        return 'Online now: ' + ', '.join(online) if online else 'Nobody else is online'

    def avatar(self, client, person):
        """A cached picture for the person (fetched now if missing, since a list is about to show it)."""
        if not person.get('avatar'):
            return self.addon_icon
        return self.avatars.get(person['id'], wait=True) or self.addon_icon

    def shortcut_label(self, preferences):
        chosen, kind = preferences.get('shortcut'), preferences.get('remote_button')
        if kind and not shortcut.present():
            return 'Missing. Set it again'
        if chosen:
            return '{} opens Watch Party'.format(shortcut.title(chosen))
        if kind == 'ctrlw':
            return 'Ctrl+W conflicts with other programs. Choose another key'
        if kind == 'own':
            return 'Set'
        return 'Not set'

    def remote_button(self, preferences):
        in_editor = shortcut.editor_installed()
        options = [Row('Record a key', '', 'Press a key, key combination or remote button within {} seconds.'.format(
            LISTEN_S), action=True, key='record')]
        options += [Row(name, where, 'Opens Watch Party with {}.'.format(name), action=True, key=kind)
                    for kind, name, where, _ in PRESETS]
        options.append(Row('Keymap Editor', 'Assign it in Kodi\'s Keymap Editor' if in_editor
                           else 'Not installed. Install it first',
                           'For a key Kodi already uses elsewhere, or any other device Kodi can read.',
                           action=True, key='editor'))
        if preferences.get('remote_button') or preferences.get('shortcut'):
            options.append(Row('Remove shortcut', '', 'The key or button gets its usual job back.', action=True,
                               key='remove'))
        picked = choose('Shortcut', options, [('Now', self.shortcut_label(preferences))])
        if picked is None:
            return
        choice = picked.key
        if choice == 'editor':
            self.keymap_editor(in_editor)
            return
        if choice == 'record':
            code, action, cancelled = KeyListener.listen(xbmcaddon.Addon().getAddonInfo('path'))
            if cancelled:
                return
            if not code:
                tell('No key or button was pressed. Choose Record a key again and press it within '
                     '{} seconds.'.format(LISTEN_S))
                return
            chosen, kind = shortcut.from_code(code), 'own'
            if chosen is None:
                tell('That button cannot be used as a shortcut. Choose another key or button.')
                return
            if action in PROTECTED_ACTIONS or shortcut.essential(chosen):
                tell('That key or button is needed for navigation or playback. Choose another one.')
                return
        elif choice == 'remove':
            chosen, kind = None, None
        else:
            kind, chosen = choice, next(preset for k, _, _, preset in PRESETS if k == choice)
        if chosen is not None:
            found = shortcut.uses(chosen, shortcut.keymap_files())
            if found and not xbmcgui.Dialog().yesno(
                    HEADING, shortcut.explain(chosen, found) + ' Use it for Watch Party instead?',
                    nolabel='Cancel', yeslabel='Use it'):
                return
        try:
            where = shortcut.save(chosen)
        except shortcut.KeymapUnreadable:
            tell('Watch Party could not read the Keymap Editor\'s file, so nothing was changed. Your own '
                 'shortcuts there are untouched.')
            return
        if chosen is None:
            self._save(preferences, remove=('remote_button', 'shortcut'))
            done = 'The shortcut was removed.'
        else:
            self._save(preferences, {'remote_button': kind, 'shortcut': chosen})
            done = '{} now opens Watch Party, also during playback.'.format(shortcut.title(chosen))
            if where == 'editor':
                done += ' It is listed in the Keymap Editor as Launch Watch Party.'
        tell(done)

    def keymap_editor(self, installed):
        """Kodi's Keymap Editor shows what every key does, window by window, and lists Watch Party."""
        if not installed:
            # Kodi asks whether to install it, and installs it before this returns.
            xbmc.executebuiltin('InstallAddon({})'.format(shortcut.KEYMAP_EDITOR), True)
            if not shortcut.editor_installed():
                tell('The Keymap Editor was not installed. It is in the Kodi Add-on repository, under '
                     'Program add-ons.')
                return
        tell('In the Keymap Editor, choose Edit, then Global, then Add-ons, then Launch Watch Party, and press '
             'the key or button to use. Save when you leave it.')
        xbmc.executebuiltin('RunAddon({})'.format(shortcut.KEYMAP_EDITOR))
