"""What this device does when someone in a watch party pauses, plays, skips or starts.

There is no Kodi code in here. The engine works through three small adapters:
a player (what is playing, and pause/play/jump), a screen (cards and questions)
and send (one request to the Watch Party server). The same logic runs in the
tests and in Kodi.

Rules measured on a real device (PLAN.md, phase 0):
- Never hold a pause after a jump: jump, then play straight away.
- PM4K wraps its own skips in pause, jump, play and raises a flag meanwhile.
- PM4K's start-up (resume point) also pauses, jumps and plays. None of that is the viewer.
"""

# One jump-and-play took 0.3 to 0.5 s on the CoreELEC box; start that much ahead.
JUMP_LEAD_S = 0.4
# Our own pause, jump or play comes back as a player event within this time.
ECHO_MS = 3000
# PM4K's own skip, from its pause to its play.
SKIP_MS = 5000
# PM4K has finished opening a video once it has played normally for this long.
STEADY_MS = 500
# Stopping this close to the end is finishing, which does not pause the others.
FINISH_WINDOW_S = 60
# A party moves on to a different title only in its last minutes (same as the server).
NEXT_ITEM_WINDOW_S = 300
IDLE_STATUS_MS = 60_000
# At the shared moment, a player this close to the spot starts a bit earlier or later instead of jumping.
NO_JUMP_WINDOW_S = 1.0
# A held player further than this from the party's spot lines up while held: it jumps a little before the
# spot, plays (playing straight after a jump is what looks right on the P3i box), and pauses on the spot.
ALIGN_S = 0.5
ALIGN_RUNUP_S = 1.0
# Lining up gives up after this long (a stalled stream); the jump at the shared moment still applies.
ALIGN_GIVE_UP_MS = 6000
# How often the engine wants to run while it is lining up or about to start.
FINE_TICK_MS = 20
# A while after every start (start, resume, rejoin, skip) the device reports exactly where it is, so the
# server can log how well the start was shared.
SYNC_CHECK_MS = 2000
# A seek event this close to where we jumped is that jump reporting back, not the viewer.
SEEK_ECHO_S = 5.0
# Starting more than this late (the message arrived late) jumps to the right spot instead of starting behind.
LATE_START_MS = 250
# A countdown is only shown when there is time to read it.
COUNTDOWN_MIN_MS = 1500
# Several quick skips (scrubbing) are sent as one, once the viewer has settled.
SEEK_SETTLE_MS = 600

DEFAULT_SETTINGS = {'catchup_threshold_s': 15, 'status_interval_s': 5, 'countdown_s': 5, 'notice_s': 4,
                    'notices': 'essential', 'control': 'everyone'}


class SendError(Exception):
    """The server refused a request, or could not be reached. `code` says which."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def describe(item):
    """A title the way people say it: "Example Show · S2 E3" or the film's title."""
    if not item:
        return ''
    if item.get('show'):
        if item.get('season') is not None and item.get('episode') is not None:
            return '{} · S{} E{}'.format(item['show'], item['season'], item['episode'])
        return item['show']
    return item.get('title') or ''


def clock_label(seconds):
    seconds = int(max(0, seconds or 0))
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return '{}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{}:{:02d}'.format(minutes, seconds)


def _older(version, other):
    def parts(text):
        try:
            return tuple(int(p) for p in str(text).split('.')[:3])
        except ValueError:
            return None
    mine, theirs = parts(version), parts(other)
    return bool(mine and theirs and mine < theirs)


def device_label(name):
    """A device's name inside a sentence: "laptop", "living room TV", but "PC" and "iPad" stay as they are."""
    name = name or 'other device'
    if len(name) > 1 and name[0].isupper() and name[1].islower():
        return name[0].lower() + name[1:]
    return name


def names(items):
    items = [i for i in items if i]
    if len(items) <= 1:
        return ''.join(items)
    return ', '.join(items[:-1]) + ' and ' + items[-1]


class Engine:
    def __init__(self, player, screen, send, clock, version='0.0.0', log=None):
        self.version = version
        self.log = log or (lambda text: None)
        self.update_told = False
        self.cannot_told = None
        self.last_item = None
        self.player = player
        self.screen = screen
        self.send = send
        self.clock = clock
        self.view = None
        self.settings = dict(DEFAULT_SETTINGS)
        self.applied = None
        self.echo = {}
        self.skip_until = 0
        self.starting = False
        self.steady_since = None
        self.item = None
        self.scheduled = None
        self.offer = None
        self.fast = False
        self.pending_invitation = None
        self.seen_invitations = set()
        self.last_status = 0
        self.dnd = False
        self.online = True
        self.jumped_to = None
        self.pending_seek = None
        self.align = None
        self.sync_check = None

    # Reading the party -----------------------------------------------------

    def party(self):
        return (self.view or {}).get('party')

    def _on_party_item(self, party):
        return bool(self.item and party and party.get('item') and party['item']['key'] == self.item['key'])

    def _expected(self, party, now):
        playback = party['playback']
        if playback['state'] == 'playing':
            return playback['position'] + max(0, now - playback['at']) / 1000.0
        return playback['position']

    def _near_end(self, party, now):
        duration = (party.get('item') or {}).get('duration')
        return bool(duration) and self._expected(party, now) >= duration - NEXT_ITEM_WINDOW_S

    def _may_control(self, party):
        return self.settings.get('control') != 'host' or party.get('i_am_host')

    def _my_person(self):
        return ((self.view or {}).get('me') or {}).get('person')

    def _label(self, member):
        if member.get('person') == self._my_person():
            return 'your ' + device_label(member.get('device_name'))
        return member.get('name') or 'Someone'

    def _actor(self, playback):
        """Who did it, at the start of a sentence: "You", "Your laptop" or the person's name."""
        if playback.get('by_me'):
            return 'You'
        if playback.get('by_person') and playback.get('by_person') == self._my_person() and playback.get('by_device'):
            return 'Your ' + device_label(playback['by_device'])
        return playback.get('by_name') or 'Someone'

    def _own_device(self, playback):
        return bool(playback.get('by_person') and playback.get('by_person') == self._my_person())

    def _others(self, party):
        return names([self._label(m) for m in party.get('members', []) if not m.get('me')]) or 'the others'

    # Player commands, remembered so their echo is not taken for the viewer ---

    def _expect(self, name):
        self.echo[name] = self.clock() + ECHO_MS

    def _consume(self, name, now, position=None):
        deadline = self.echo.get(name)
        if deadline is None or deadline < now:
            return False
        if name == 'seek':
            # One jump can report more than one seek (a long one especially): every seek that lands near where
            # we jumped is ours; one somewhere else is the viewer skipping.
            if position is not None and self.jumped_to is not None and abs(position - self.jumped_to) > SEEK_ECHO_S:
                return False
            return True
        del self.echo[name]
        return True

    def _pause(self):
        if not self.player.paused():
            self._expect('paused')
            self.player.pause()
            self.log('pause at {}'.format(self.player.position()))

    def _play(self):
        if self.player.paused():
            self._expect('resumed')
            self.player.play()
            self.log('play at {}'.format(self.player.position()))

    def _jump_and_play(self, seconds):
        self._pause()
        self._expect('seek')
        self.jumped_to = max(0.0, seconds)
        self.player.jump(max(0.0, seconds))
        self._expect('resumed')
        self.player.play()
        self.log('jump to {:.3f} and play'.format(seconds))

    # Lining up while held -----------------------------------------------------

    def _hold_at(self, position):
        """Held (paused, waiting, counting down): line up on `position` if this player is not there."""
        self.align = {'target': position, 'phase': 'check', 'since': self.clock()}

    def wake_in_ms(self):
        """When the engine next needs to run, if sooner than its usual pace (for precise starts)."""
        if self.align:
            return FINE_TICK_MS
        if self.scheduled:
            left = self.scheduled[0] - JUMP_LEAD_S * 1000 - self.clock()
            return max(FINE_TICK_MS, min(left, 250)) if left > 250 else FINE_TICK_MS
        return None

    def _run_align(self, now):
        align = self.align
        target = align['target']
        mine = self.player.position()
        if mine is None or not self.item:
            self.align = None
            return
        if align['phase'] == 'check':
            if not self.player.paused():
                # Kodi may report the pause a moment after it was asked for.
                if now - align['since'] > 1000:
                    self.align = None
                return
            if abs(mine - target) <= ALIGN_S:
                self.align = None
                return
            # Never held paused after a jump: jump a little before the spot and play up to it.
            align.update(phase='run', since=now)
            self._expect('seek')
            self.jumped_to = max(0.0, target - ALIGN_RUNUP_S)
            self.player.jump(self.jumped_to)
            self._expect('resumed')
            self.player.play()
            self.log('line up: {:.3f} to {:.3f}'.format(mine, target))
            return
        if mine >= target - FINE_TICK_MS / 1000.0 or now - align['since'] > ALIGN_GIVE_UP_MS:
            self.align = None
            self._pause()
            self.log('lined up at {:.3f} for {:.3f}'.format(self.player.position() or 0.0, target))

    # Talking to the server -------------------------------------------------

    def _send(self, payload):
        if not self.online:
            # Nothing is queued while the server is away: on return, this device follows the party.
            return None
        try:
            result = self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)
            else:
                self._refused(error.code)
            return None
        return result

    def _tell(self, text, extra=False, person=None):
        """A notice. Extra ones (pressed play, back in sync, reachable again) only show if the admin chose All."""
        if extra and self.settings.get('notices') != 'all':
            return
        self.screen.notice(text, person=person)

    def set_online(self, online):
        """Told by the connection (or found out by a failed send). Only a party member hears about it."""
        if online == self.online:
            return
        self.online = online
        if not self.party():
            return
        if online:
            self._tell('Connection restored. Back in sync with the watch party.', extra=True)
            self.applied = None
        else:
            self._tell('Connection to Watch Party lost. Playback continues on this device.')

    def _refused(self, code):
        party = self.party()
        if code == 'host_only' and party:
            self._tell('Only {} can control playback in this watch party.'.format(party.get('host_name') or 'the host'))
        elif code in ('party_busy', 'other_item') and party and party.get('item'):
            if party['playback']['state'] == 'waiting':
                self._tell('The watch party is waiting for you on {}. This video is not synchronised.'.format(
                    describe(party['item'])))
            else:
                self._tell('The watch party is playing {}. This video is not synchronised.'.format(
                    describe(party['item'])))

    def _send_playback(self, kind, position, item=None):
        result = self._send({'type': 'playback', 'kind': kind, 'item': item or self.item,
                             'position': round(max(0.0, position or 0.0), 3)})
        if result is not None:
            self._clear_offer()
        return result

    def _started(self):
        """Playback just started for the party: report how well in a moment."""
        party = self.party()
        if party:
            self.sync_check = (party['playback']['seq'], self.clock() + SYNC_CHECK_MS)

    def _send_status(self, state=None, check=None):
        now = self.clock()
        self.last_status = now
        if state is None:
            state = 'idle' if not self.item else ('paused' if self.player.paused() else 'playing')
        payload = {'type': 'status', 'state': state}
        if state != 'idle':
            payload.update(item=self.item, position=round(self.player.position() or 0.0, 3))
            if check is not None:
                payload.update(sampled_at=now, check=check)
        if not self.online:
            return
        try:
            self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)

    def respond(self, party_id, accept):
        """The viewer answered an invitation."""
        self._send({'type': 'respond', 'party': party_id, 'accept': bool(accept)})

    def set_do_not_disturb(self, value):
        self.dnd = bool(value)

    # What the player reports -----------------------------------------------

    def on_local(self, name, position=None, target=None, seeking=False, speed=None):
        now = self.clock()
        self.log('event {} at {}{}{}'.format(name, position, ' target {}'.format(target) if target is not None else '',
                                            ' (PM4K skip)' if seeking else ''))
        if name == 'started':
            self.starting, self.steady_since, self.item, self.fast = True, None, None, False
            self.skip_until = 0
            self._clear_offer()
            return
        if name in ('stopped', 'ended'):
            self._stopped(name == 'ended', position)
            return
        if self.starting:
            return
        if name == 'speed':
            if speed == 1:
                if self.fast:
                    self.fast = False
                    self._user_seek(position)
            else:
                self.fast = True
            return
        if name == 'paused' and seeking:
            # PM4K's own skip (its flag is up): never our echo, even if one of ours is expected.
            self.skip_until = now + SKIP_MS
            return
        if self._consume(name, now, target if target is not None else position):
            return
        self.log('taken as the viewer: {}'.format(name))
        if self.align and name in ('paused', 'resumed'):
            # The viewer pressed while this player was lining up: stop there and treat it as a press while held.
            target = self.align['target']
            self.align = None
            self._pause()
            if self.scheduled:
                self._cancel_countdown()
            elif name == 'resumed':
                self._user_resume(target)
            return
        if name == 'resumed' and self.scheduled:
            # A press during a countdown (Kodi's pause is a toggle, so play and pause look the same) stops it.
            self._pause()
            self._cancel_countdown()
            return
        if name == 'paused':
            self._user_pause(position)
        elif name == 'resumed':
            if self.skip_until >= now:
                self.skip_until = 0
                return
            self._user_resume(position)
        elif name == 'seek' and not self.fast:
            self._user_seek(target if target is not None else position)

    def _cancel_countdown(self):
        at, position = self.scheduled
        self.scheduled = None
        self.screen.clear_countdown()
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._refused('host_only')
            return
        if self._send_playback('pause', position) is not None:
            self.screen.hold(self._paused_text(party, 'You paused'))

    def _user_pause(self, position):
        party = self.party()
        if not party and self.pending_invitation:
            invitation, self.pending_invitation = self.pending_invitation, None
            self.screen.ask(invitation)
            return
        if not self._on_party_item(party):
            return
        if self.offer:
            self._catch_up(party)
            return
        if not self._may_control(party):
            self._play()
            self._refused('host_only')
            return
        if self._send_playback('pause', position) is not None:
            self.screen.hold(self._paused_text(party, 'You paused'))

    def _user_resume(self, position):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._pause()
            self._refused('host_only')
            return
        self.screen.clear_hold()
        # Everyone starts together a moment from now, this player included, so hold it until then.
        self._pause()
        if self._send_playback('resume', position) is None:
            self._play()

    def _user_seek(self, target):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            if party['playback']['state'] == 'playing':
                self._jump_and_play(self._expected(party, self.clock()) + JUMP_LEAD_S)
            self._refused('host_only')
            return
        # Sent once the viewer stops skipping, so the others jump once to where they ended up.
        self.pending_seek = (target, self.clock())

    def _send_settled_seek(self, now):
        target, at = self.pending_seek
        if now - at < SEEK_SETTLE_MS:
            return
        self.pending_seek = None
        if self._on_party_item(self.party()):
            # Where this player is now, not where the skip landed: it has been playing while the skip settled.
            here = self.player.position()
            self._send_playback('seek', here if here is not None and not self.player.paused() else target)

    def _stopped(self, ended, position):
        was, self.item = self.item, None
        self.last_item = was or self.last_item
        self.starting, self.scheduled, self.pending_seek, self.align, self.sync_check = False, None, None, None, None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        party = self.party()
        if party and was and party.get('item') and party['item']['key'] == was['key']:
            duration = was.get('duration') or 0
            finished = ended or (duration and (position or 0) >= duration - FINISH_WINDOW_S)
            if not finished:
                self._send_playback('stop', position, item=was)
        self._send_status('idle')

    # Housekeeping, about four times a second ---------------------------------

    def tick(self):
        now = self.clock()
        for name in [n for n, deadline in self.echo.items() if deadline < now]:
            del self.echo[name]
        if self.starting:
            self._check_steady(now)
        if self.align:
            self._run_align(now)
        if self.scheduled:
            lining_up = self.align and self.align['phase'] == 'run'
            if lining_up and now >= self.scheduled[0] - JUMP_LEAD_S * 1000 - FINE_TICK_MS:
                # The moment has come before lining up finished: the start never waits for it.
                self.align = None
                lining_up = False
            if not lining_up:
                self._run_scheduled(now)
        if self.pending_seek:
            self._send_settled_seek(now)
        if self.sync_check and now >= self.sync_check[1]:
            seq, self.sync_check = self.sync_check[0], None
            if self.item and not self.player.paused():
                self._send_status(check=seq)
        interval = self.settings['status_interval_s'] * 1000 if self.item else IDLE_STATUS_MS
        if now - self.last_status >= interval:
            self._send_status()
        party = self.party()
        if party and self.item and not self.starting:
            self._check_distance(party, now)

    def _run_scheduled(self, now):
        at, position = self.scheduled
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and abs(mine - position) <= NO_JUMP_WINDOW_S:
            # Already (nearly) there: start a little earlier or later instead of jumping.
            start = at + (mine - position) * 1000
            if now < start:
                return
            self.scheduled = None
            if not self.item:
                return
            self.log('start: {} ms after the moment, {:.3f} from the spot'.format(now - at, mine - position))
            if now - start > LATE_START_MS:
                self._jump_and_play(position + (now - at) / 1000.0 + JUMP_LEAD_S)
            else:
                self._play()
            self._started()
            return
        if now < at - JUMP_LEAD_S * 1000:
            return
        self.scheduled = None
        self.align = None
        if self.item:
            self.log('start by jumping: {} ms to the moment'.format(at - now))
            self._started()
            # Playback resumes about JUMP_LEAD_S after the jump starts, at at + (now - at) + lead. Jumping early
            # makes (now - at) negative and cancels the lead, so the picture moves on from `position` right at `at`.
            self._jump_and_play(position + (now - at) / 1000.0 + JUMP_LEAD_S)

    def _check_steady(self, now):
        if not self.player.video() or self.player.pm4k_busy() or self.player.paused():
            self.steady_since = None
            return
        if self.steady_since is None:
            self.steady_since = now
            return
        if now - self.steady_since >= STEADY_MS:
            self.starting = False
            self.item = self.player.item()
            self._ready()

    def _ready(self):
        self._send_status()
        party = self.party()
        if not party:
            return
        if not self.item:
            self._tell('This video cannot be synchronised: it is not playing directly from Plex.')
            return
        if self._on_party_item(party):
            # Opened what the party is on: follow wherever it is now (paused, waiting or counting down holds this
            # player at once, before the server has even heard of it).
            self._follow(party)
        self._join_playback(party)

    def _join_playback(self, party):
        """Tell the server this device is on its title. The next update says what to do."""
        playback = party['playback']
        if (not self._on_party_item(party) and playback['state'] == 'playing'
                and not self._near_end(party, self.clock())):
            self._refused('party_busy')
            return
        self._send_playback('start', self.player.position() or 0.0)

    def _check_distance(self, party, now):
        playback = party['playback']
        if (playback['state'] != 'playing' or playback['at'] > now or not self._on_party_item(party)
                or self.player.paused() or any(k != 'seek' for k in self.echo) or self.skip_until >= now
                or self.scheduled
                or self.pending_seek or self.align):
            return
        position = self.player.position()
        if position is None:
            return
        distance = position - self._expected(party, now)
        threshold = self.settings['catchup_threshold_s']
        if distance < -threshold:
            wanted = 'behind'
        elif distance > threshold:
            wanted = 'ahead'
        elif abs(distance) < threshold / 2.0:
            wanted = None
        else:
            wanted = self.offer
        if wanted == self.offer:
            return
        self.offer = wanted
        if wanted == 'behind':
            self.screen.offer('You are {} seconds behind {}. Press pause to resync.'.format(
                int(-distance), self._others(party)))
        elif wanted == 'ahead':
            self.screen.offer('You are {} seconds ahead of {}. Press pause to resync.'.format(
                int(distance), self._others(party)))
        else:
            self.screen.clear_offer()

    def _catch_up(self, party):
        self._clear_offer()
        self._jump_and_play(self._expected(party, self.clock()) + JUMP_LEAD_S)
        self._tell('Back in sync with {}.'.format(self._others(party)), extra=True)

    def _clear_offer(self):
        if self.offer:
            self.offer = None
            self.screen.clear_offer()

    # What the server reports -----------------------------------------------

    def on_state(self, view):
        previous, self.view = self.view, view
        self.settings.update({k: v for k, v in (view.get('settings') or {}).items() if k in DEFAULT_SETTINGS})
        self._invitations(view)
        minimum = (view.get('addon') or {}).get('minimum')
        if minimum and not self.update_told and _older(self.version, minimum):
            self.update_told = True
            self._tell('A Watch Party update is required. Open Watch Party and choose Check for updates.')
        party, before = view.get('party'), (previous or {}).get('party')
        if before and not party:
            self._party_gone()
        elif party and (not before or before['id'] != party['id']):
            self._joined(party)
        elif party:
            self._membership(before, party)
        if party:
            self._follow(party)

    def _invitations(self, view):
        current = {i['party'] for i in view.get('invitations', [])}
        if self.pending_invitation and self.pending_invitation['party'] not in current:
            self.pending_invitation = None
        for invitation in view.get('invitations', []):
            if invitation['party'] in self.seen_invitations:
                continue
            self.seen_invitations.add(invitation['party'])
            if self.dnd:
                continue
            if invitation.get('from_me'):
                text = 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
            else:
                text = '{} invited you to a watch party.'.format(invitation.get('from') or 'Someone')
            if self.player.video() and not self.player.paused():
                if view.get('party'):
                    self._tell(text + ' Open Watch Party to answer.')
                else:
                    self.pending_invitation = invitation
                    self._tell(text + ' Press pause to answer.')
            else:
                self.screen.ask(invitation)

    def _party_gone(self):
        self.scheduled = None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        self._tell('The watch party has ended.')

    def _joined(self, party):
        if party.get('i_am_host') and len(party.get('members', [])) == 1:
            self._tell('Watch party started. Invitations sent.')
        else:
            host = party.get('host_name')
            self._tell("You joined {}'s watch party.".format(host) if host else 'You joined the watch party.')
        if self.item and not self.starting:
            self._join_playback(party)

    def _membership(self, before, party):
        def key(member):
            return (member.get('person'), member.get('device_name'))
        old = {key(m) for m in before.get('members', [])}
        new = {key(m) for m in party.get('members', [])}
        was_online = {key(m): m.get('online') for m in before.get('members', [])}
        for member in party.get('members', []):
            if member.get('me'):
                continue
            name = self._label(member).capitalize()
            if key(member) not in old:
                self._tell('{} joined the watch party.'.format(name))
            elif was_online.get(key(member)) and not member.get('online'):
                self._tell('{} lost connection.'.format(name))
            elif was_online.get(key(member)) is False and member.get('online'):
                self._tell('{} reconnected.'.format(name), extra=True)
        for member in before.get('members', []):
            if key(member) not in new and not member.get('me'):
                self._tell('{} left the watch party.'.format(self._label(member).capitalize()))

    def _follow(self, party):
        playback = party['playback']
        item_key = (party.get('item') or {}).get('key')
        if party.get('cannot_watch') and item_key and self.cannot_told != item_key and self._on_party_item(party):
            self.cannot_told = item_key
            self._tell('{} does not have access to this title.'.format(names(party['cannot_watch'])))
        # A state is applied once per title this device plays, so opening the party's title
        # after a change still brings this player to where the party is.
        key = (party['id'], playback['seq'], (self.item or {}).get('key'))
        if key != self.applied:
            self.applied = key
            self._apply(party, playback)
        elif playback['state'] == 'waiting' and self._on_party_item(party):
            self.screen.hold(self._waiting_text(party))

    def _paused_text(self, party, who, playback=None):
        """'Sam paused · with Kim': the others in the party, leaving out whoever paused."""
        playback = playback or {}

        def is_actor(member):
            return (member.get('person') == playback.get('by_person')
                    and (not playback.get('by_device') or member.get('device_name') == playback.get('by_device')))
        others = [self._label(m) for m in party.get('members', []) if not m.get('me') and not is_actor(m)]
        return who + (' \u00b7 with ' + names(others) if others else '')

    def _starting_text(self, party, by):
        item = party['item']
        if party.get('can_watch') is False:
            return '{} started a title you do not have access to. You will rejoin when the watch party moves on.'.format(by)
        last = self.last_item or {}
        if last.get('show') and last.get('show') == item.get('show') and last.get('key') != item.get('key'):
            return '{} moved on to {}. Open it in Plex to continue watching together.'.format(
                by, 'S{} E{}'.format(item.get('season'), item.get('episode')) if item.get('episode') is not None
                else describe(item))
        return '{} is starting {}. Open it in Plex to watch together.'.format(by, describe(item))

    def _waiting_text(self, party):
        missing = [self._label(m) for m in party.get('members', []) if not m.get('me') and not m.get('ready')]
        if not missing:
            return 'Everyone is ready. Starting shortly.'
        return 'Waiting for {} to open it. Press play to start without them.'.format(names(missing))

    def _me_ready(self, party):
        return any(m.get('ready') for m in party.get('members', []) if m.get('me'))

    def _apply(self, party, playback):
        now = self.clock()
        by, kind = self._actor(playback), playback.get('kind')
        self.log('party {} #{} {} at {} ({} ms){}'.format(playback['state'], playback['seq'], kind, playback['position'],
                                                        (playback.get('at') or now) - now,
                                                        ' by me' if playback.get('by_me') else ''))
        if not self._on_party_item(party) or self.starting:
            if (kind == 'start' and not playback.get('by_me') and playback['state'] in ('waiting', 'playing')
                    and not self.starting and party.get('item')):
                self._tell(self._starting_text(party, by), person=playback.get('by_person'))
            return
        if playback.get('by_me') and kind in ('pause', 'seek'):
            return
        state = playback['state']
        if state == 'paused':
            self.scheduled = None
            self.screen.clear_countdown()
            self.screen.clear_hold()
            self._pause()
            self._hold_at(playback['position'])
            if playback.get('by_me'):
                # Back on the title after closing it, while someone else is still away.
                self.screen.hold(self._waiting_text(party))
            else:
                if kind == 'stopped':
                    self.screen.hold('{} closed the video. Press play to continue without {}.'.format(
                        by, 'it' if self._own_device(playback) else 'them'))
                elif kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'])),
                               person=playback.get('by_person'))
                else:
                    self.screen.hold(self._paused_text(party, '{} paused'.format(by), playback))
        elif state == 'playing':
            self.screen.clear_hold()
            if playback['at'] > now + 100:
                self._pause()
                self.scheduled = (playback['at'], playback['position'])
                self._hold_at(playback['position'])
                if playback['at'] - now >= COUNTDOWN_MIN_MS:
                    self.screen.countdown(playback['at'], 'Starting' if kind == 'start' else 'Resuming')
                if kind == 'rejoin' and not playback.get('by_me'):
                    self._tell('{} returned to the video.'.format(by), person=playback.get('by_person'))
                elif kind == 'resume' and not playback.get('by_me'):
                    self._tell('{} resumed playback.'.format(by), extra=True)
                return
            self.scheduled = None
            self.align = None
            self.screen.clear_countdown()
            self._jump_and_play(self._expected(party, now) + JUMP_LEAD_S)
            self._started()
            if not playback.get('by_me'):
                if kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'])),
                               person=playback.get('by_person'))
                elif kind == 'resume':
                    self._tell('{} resumed playback.'.format(by), extra=True)
        elif state == 'waiting':
            self._pause()
            self._hold_at(playback['position'])
            self.screen.hold(self._waiting_text(party))
            if not self._me_ready(party):
                # On the party's title but not counted as ready (the party moved titles meanwhile): say so again.
                self._send_playback('start', self.player.position() or 0.0)
