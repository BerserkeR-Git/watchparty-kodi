"""This device's connection to Watch Party and its preferences, in the add-on's own data folder.

The device key is sealed with a key derived from this machine's own ID, so a copy of the
add-on's data folder (a backup, another computer) cannot be used elsewhere. Someone already
on this machine can still unseal it; Kodi has no way to prevent that. The sealing uses
HMAC-SHA256 as a keystream and as a tag, because Kodi's Python has no AES.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import tempfile
import uuid

DEFAULT_PREFERENCES = {'do_not_disturb': False}
MACHINE_ID_FILES = ('/etc/machine-id', '/var/lib/dbus/machine-id', '/storage/.cache/systemd-machine-id')


def machine_id():
    """Something stable and specific to this machine."""
    try:
        import winreg  # noqa: PLC0415 - Windows only
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography') as key:
            return 'windows:' + winreg.QueryValueEx(key, 'MachineGuid')[0]
    except Exception:  # noqa: BLE001 - not Windows, or not readable
        pass
    for path in MACHINE_ID_FILES:
        try:
            with open(path, encoding='ascii') as handle:
                value = handle.read().strip()
            if value:
                return 'linux:' + value
        except (OSError, UnicodeDecodeError):
            continue
    return 'node:%012x' % uuid.getnode()


def _keys(identity):
    root = hashlib.sha256(('watchparty-device-key:' + identity).encode('utf-8')).digest()
    return (hmac.new(root, b'seal', hashlib.sha256).digest(), hmac.new(root, b'tag', hashlib.sha256).digest())


def _stream(key, nonce, length):
    blocks, counter = [], 0
    while sum(len(b) for b in blocks) < length:
        blocks.append(hmac.new(key, nonce + counter.to_bytes(4, 'big'), hashlib.sha256).digest())
        counter += 1
    return b''.join(blocks)[:length]


def seal(secret, identity):
    seal_key, tag_key = _keys(identity)
    nonce = secrets.token_bytes(16)
    plain = secret.encode('utf-8')
    cipher = bytes(a ^ b for a, b in zip(plain, _stream(seal_key, nonce, len(plain))))
    tag = hmac.new(tag_key, nonce + cipher, hashlib.sha256).digest()
    return {'n': base64.b64encode(nonce).decode(), 'c': base64.b64encode(cipher).decode(),
            't': base64.b64encode(tag).decode()}


def unseal(box, identity):
    """The secret, or None if this is not the machine it was sealed on (or the box was changed)."""
    try:
        nonce, cipher, tag = (base64.b64decode(box[k]) for k in ('n', 'c', 't'))
    except (KeyError, TypeError, ValueError):
        return None
    seal_key, tag_key = _keys(identity)
    if not hmac.compare_digest(tag, hmac.new(tag_key, nonce + cipher, hashlib.sha256).digest()):
        return None
    return bytes(a ^ b for a, b in zip(cipher, _stream(seal_key, nonce, len(cipher)))).decode('utf-8')


class Storage:
    def __init__(self, folder, identity=None):
        self.folder = folder
        self.identity = identity or machine_id()
        self.device_path = os.path.join(folder, 'device.json')
        self.preferences_path = os.path.join(folder, 'preferences.json')
        self.avatar_folder = os.path.join(folder, 'avatars')
        self.card_folder = os.path.join(folder, 'cards')

    def _read(self, path):
        try:
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return None
        return data if isinstance(data, dict) else None

    def _write(self, path, data):
        os.makedirs(self.folder, exist_ok=True)
        handle, temporary = tempfile.mkstemp(dir=self.folder, prefix='.', suffix='.tmp')
        with os.fdopen(handle, 'w', encoding='utf-8') as stream:
            json.dump(data, stream)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)

    def device(self):
        """{address, device, secret, generation, name, device_name, disconnected}, or None before connecting.

        `unreadable` is set when the key was sealed on another machine: the device must connect again.
        """
        data = self._read(self.device_path)
        if not data or not data.get('address') or not data.get('device'):
            return None
        if data.get('secret'):
            # Connected before keys were sealed: seal it now, keep nothing in the clear.
            self.save_device(data)
            data = self._read(self.device_path) or data
        secret = unseal(data.get('sealed') or {}, self.identity)
        result = {k: v for k, v in data.items() if k != 'sealed'}
        if secret is None:
            result['unreadable'] = True
            return result
        result['secret'] = secret
        result.setdefault('generation', 0)
        return result

    def save_device(self, data):
        stored = {k: v for k, v in data.items() if k not in ('secret', 'unreadable')}
        if data.get('secret'):
            stored['sealed'] = seal(data['secret'], self.identity)
        self._write(self.device_path, stored)

    # The key the client signs with; read fresh before every request, so every process agrees.
    def load_key(self):
        device = self.device()
        if not device or device.get('unreadable'):
            return None, 0
        return device['secret'], device.get('generation', 0)

    def save_key(self, secret, generation):
        device = self.device()
        if device and not device.get('unreadable'):
            device.update(secret=secret, generation=generation)
            self.save_device(device)

    def mark_disconnected(self):
        data = self._read(self.device_path)
        if data:
            data['disconnected'] = True
            self._write(self.device_path, data)

    def forget_device(self):
        try:
            os.remove(self.device_path)
        except OSError:
            pass

    def preferences(self):
        values = dict(DEFAULT_PREFERENCES)
        values.update(self._read(self.preferences_path) or {})
        return values

    def save_preferences(self, values):
        self._write(self.preferences_path, values)

    def stamp(self):
        """Changes whenever either file changes, so the service notices the menu's edits."""
        stamps = []
        for path in (self.device_path, self.preferences_path):
            try:
                info = os.stat(path)
                stamps.append((info.st_mtime_ns, info.st_size))
            except OSError:
                stamps.append(None)
        return tuple(stamps)
