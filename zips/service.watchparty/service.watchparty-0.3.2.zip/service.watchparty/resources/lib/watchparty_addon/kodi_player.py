"""Kodi's player, as the engine sees it: what is playing, what happened, and pause, play and jump."""
import json
import re
import threading

import xbmc

# Direct play from Plex: http(s)://server:32400/library/parts/<part id>/...
PART = re.compile(r'/library/parts/(\d+)/')
JUMP_WAIT_S = 1.5


def rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except ValueError:
        return {}


def pm4k_flag(name):
    return xbmc.getInfoLabel('Window(10000).Property(script.plex.{})'.format(name)) == '1'


def _number(label):
    try:
        return int(xbmc.getInfoLabel(label))
    except ValueError:
        return None


class Observer(xbmc.Player):
    """Kodi calls these as playback changes. Each becomes one event for the engine.

    PM4K's flags are read here, at the moment of the event, because they are cleared
    again within a fraction of a second.
    """

    def __init__(self, deliver):
        super().__init__()
        self.deliver = deliver
        self.jumped = threading.Event()
        self.video_active = False
        self.last_position = 0.0

    def _position(self):
        try:
            if self.isPlayingVideo():
                self.last_position = round(self.getTime(), 3)
        except RuntimeError:
            pass
        return self.last_position

    def _emit(self, name, **data):
        data.setdefault('position', self._position())
        self.deliver(name, data)

    def _is_video(self):
        try:
            return self.isPlayingVideo()
        except RuntimeError:
            return False

    def onAVStarted(self):
        if self._is_video():
            self.video_active = True
            self._emit('started')

    def onPlayBackPaused(self):
        if self.video_active:
            self._emit('paused', seeking=pm4k_flag('playback_seeking'))

    def onPlayBackResumed(self):
        if self.video_active:
            self._emit('resumed')

    def onPlayBackSeek(self, time_ms, offset_ms):
        self.jumped.set()
        if self.video_active:
            self._emit('seek', target=round(time_ms / 1000.0, 3), seeking=pm4k_flag('playback_seeking'))

    def onPlayBackSpeedChanged(self, speed):
        if self.video_active:
            self._emit('speed', speed=speed)

    def _finished(self, name):
        if self.video_active:
            self.video_active = False
            self.deliver(name, {'position': self.last_position})

    def onPlayBackStopped(self):
        self._finished('stopped')

    def onPlayBackEnded(self):
        self._finished('ended')

    def onPlayBackError(self):
        self._finished('stopped')


class PlayerAdapter:
    """What the engine asks of the player."""

    def __init__(self, observer):
        self.observer = observer

    def _player_id(self):
        for player in rpc('Player.GetActivePlayers').get('result') or []:
            if player.get('type') == 'video':
                return player.get('playerid')
        return None

    def video(self):
        return self.observer.video_active and self.observer._is_video()

    def paused(self):
        return bool(xbmc.getCondVisibility('Player.Paused'))

    def position(self):
        return self.observer._position() if self.video() else None

    def pm4k_busy(self):
        return pm4k_flag('playback_seeking') or pm4k_flag('playback_initializing')

    def item(self):
        """The Plex item playing, or None if it is not direct play (then it cannot be synced)."""
        try:
            url = self.observer.getPlayingFile()
            duration = self.observer.getTotalTime()
        except RuntimeError:
            return None
        part = PART.search(url.partition('|')[0])
        if not part:
            return None
        return {
            'key': part.group(1),
            'title': xbmc.getInfoLabel('VideoPlayer.Title'),
            'show': xbmc.getInfoLabel('VideoPlayer.TVShowTitle'),
            'season': _number('VideoPlayer.Season'),
            'episode': _number('VideoPlayer.Episode'),
            'duration': round(duration, 3) if duration else None,
        }

    def pause(self):
        rpc('Player.PlayPause', {'playerid': self._player_id(), 'play': False})

    def play(self):
        rpc('Player.PlayPause', {'playerid': self._player_id(), 'play': True})

    def jump(self, seconds):
        """An exact jump, waiting until it has landed (measured: about 0.1 to 0.2 s)."""
        total_ms = int(max(0.0, seconds) * 1000)
        value = {'time': {'hours': total_ms // 3_600_000, 'minutes': total_ms // 60_000 % 60,
                          'seconds': total_ms // 1000 % 60, 'milliseconds': total_ms % 1000}}
        self.observer.jumped.clear()
        rpc('Player.Seek', {'playerid': self._player_id(), 'value': value})
        self.observer.jumped.wait(JUMP_WAIT_S)
