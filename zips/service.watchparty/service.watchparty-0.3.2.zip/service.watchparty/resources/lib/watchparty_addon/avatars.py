"""People's pictures, cached in the add-on's data folder and fetched in the background."""
import os
import threading
import time

from .engine import SendError

TYPES = ((b'\xff\xd8\xff', '.jpg'), (b'\x89PNG', '.png'), (b'GIF8', '.gif'))
FRESH_S = 86400


class Avatars:
    def __init__(self, folder, client):
        self.folder = folder
        self.client = client
        self.fetching = set()
        self.lock = threading.Lock()

    def cached(self, person):
        for _, extension in TYPES:
            path = os.path.join(self.folder, person + extension)
            if os.path.exists(path):
                return path
        return None

    def get(self, person, wait=False):
        """The picture's path if there is one; fetches it (in the background unless wait) when missing or old."""
        if not person or not all(c in '0123456789abcdef' for c in person):
            return None
        path = self.cached(person)
        if path and time.time() - os.path.getmtime(path) < FRESH_S:
            return path
        if wait:
            return self._fetch(person) or path
        with self.lock:
            if person not in self.fetching:
                self.fetching.add(person)
                threading.Thread(target=self._fetch, args=(person,), name='watchparty-avatar', daemon=True).start()
        return path

    def _fetch(self, person):
        try:
            data = self.client.avatar(person)
        except SendError:
            data = None
        finally:
            with self.lock:
                self.fetching.discard(person)
        extension = next((ext for magic, ext in TYPES if data and data.startswith(magic)), None)
        if not extension:
            return None
        os.makedirs(self.folder, exist_ok=True)
        for _, other in TYPES:
            try:
                os.remove(os.path.join(self.folder, person + other))
            except OSError:
                pass
        path = os.path.join(self.folder, person + extension)
        with open(path, 'wb') as handle:
            handle.write(data)
        return path
