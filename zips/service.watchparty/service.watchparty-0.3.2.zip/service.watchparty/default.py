"""Opened from Add-ons: the Watch Party menu."""
import os
import sys

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(PATH, 'resources', 'lib'))

from watchparty_addon.menu import Menu  # noqa: E402
from watchparty_addon.storage import Storage  # noqa: E402

if __name__ == '__main__':
    Menu(Storage(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))), os.path.join(PATH, 'resources', 'icon.png'),
         ADDON.getAddonInfo('version')).run()
