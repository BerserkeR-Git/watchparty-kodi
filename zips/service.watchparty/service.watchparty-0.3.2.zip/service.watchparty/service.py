"""Started by Kodi in the background: keeps this device in the watch party."""
import os
import sys

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(PATH, 'resources', 'lib'))

from watchparty_addon.service_loop import Service  # noqa: E402
from watchparty_addon.storage import Storage  # noqa: E402

if __name__ == '__main__':
    Service(PATH, Storage(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))), ADDON.getAddonInfo('version')).run()
