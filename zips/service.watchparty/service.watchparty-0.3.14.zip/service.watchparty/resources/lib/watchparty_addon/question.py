"""Watch Party's own questions and messages, in the style of its menu window and the same on every skin: the mark and
the heading at the top, the text, and the buttons at the bottom right. Back answers no. The same window, without
buttons and with a bar along the bottom, shows something that takes a few seconds.

The window is as tall as its text and centred. Kodi cannot measure text from an add-on and cannot size a window to
it, so the lines are broken here (card_art's letter widths) and everything is placed for that many lines."""
import threading

import xbmcaddon
import xbmcgui

from . import card_art
from .guard import logged

HEADING = 'Watch Party'
WINDOW = 'watchparty-question.xml'
TITLE, TEXT, YES, NO, BAR = 10, 20, 31, 32, 41
PANEL, MARK, RULE_TOP, RULE_BOTTOM, TRACK = 2, 3, 4, 5, 40
BAR_WIDTH = 1100
CANCEL_ACTIONS = {10, 92}
# The text: 1060 px wide in the skin's font13 (Estuary: 28.4 px per em, lines 41 px apart), measured in card_art's
# units with 8% to spare, so a skin with a slightly wider font13 does not break the lines again.
TEXT_LIMIT = int(1060 * card_art.PX_PER_UNIT * 1000 / (28.4 * 1.08))
LINE_H = 41
TEXT_TOP = 166
BUTTON_H = 64
SCREEN_H = 1080


def lines(text):
    return card_art.wrap(text, TEXT_LIMIT)


def layout(count):
    """The window's height and top for a text of `count` lines, and the top of each control below the heading
    (relative to the window's top)."""
    text_height = max(1, count) * LINE_H + 6
    rule = TEXT_TOP + text_height + 20
    buttons = rule + 28
    height = buttons + BUTTON_H + 32
    return height, (SCREEN_H - height) // 2, {TEXT: TEXT_TOP, RULE_BOTTOM: rule, YES: buttons, NO: buttons,
                                              TRACK: buttons + 28, BAR: buttons + 28}, text_height


def _path(addon_path):
    return xbmcaddon.Addon().getAddonInfo('path') if addon_path is None else addon_path


class QuestionWindow(xbmcgui.WindowXMLDialog):
    """One question or message. answer is True when the first button was pressed, False for the second or Back, and
    None when nobody answered: it closed by itself or was withdrawn."""

    def __new__(cls, text, yes, no=None, autoclose_ms=0, careful=False, addon_path=''):
        return super().__new__(cls, WINDOW, addon_path, 'default', '1080i')

    def __init__(self, text, yes, no=None, autoclose_ms=0, careful=False, addon_path=''):
        self.text, self.yes, self.no = text, yes, no
        self.autoclose_ms, self.careful = autoclose_ms, careful
        self.answer = None
        self.withdrawn = False
        self.done = threading.Event()

    def place(self):
        """The heading, the text broken into lines, and everything placed for that many lines."""
        broken = lines(self.text)
        height, top, below, text_height = layout(len(broken))
        self.getControl(PANEL).setHeight(height)
        for control, x, y in ((PANEL, 0, 0), (MARK, 50, 40), (TITLE, 150, 40), (RULE_TOP, 50, 140)):
            self.getControl(control).setPosition(x, top + y)
        for control, x in ((TEXT, 70), (RULE_BOTTOM, 50), (NO, 610), (YES, 890), (TRACK, 50), (BAR, 50)):
            self.getControl(control).setPosition(x, top + below[control])
        self.getControl(TEXT).setHeight(text_height)
        self.getControl(TITLE).setLabel(HEADING)
        self.getControl(TEXT).setText('[CR]'.join(broken))

    def onInit(self):
        if self.withdrawn:  # withdrawn before Kodi drew it
            self.close()
            return
        self.place()
        self.getControl(YES).setLabel(self.yes)
        if self.no:
            self.getControl(NO).setLabel(self.no)
        else:
            self.getControl(NO).setVisible(False)
        self.getControl(BAR).setVisible(False)
        # A question whose yes cannot be undone starts on no, so a press of OK out of habit changes nothing.
        self.setFocusId(NO if self.no and self.careful else YES)
        if self.autoclose_ms:
            threading.Thread(target=self._close_later, name='watchparty-question-timer', daemon=True).start()

    @logged('closing a question by itself')
    def _close_later(self):
        if not self.done.wait(self.autoclose_ms / 1000.0):
            self.close()

    def onClick(self, control_id):
        if control_id in (YES, NO):
            self.answer = control_id == YES
            self.close()

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.answer = False
            self.close()

    def withdraw(self):
        """Closes the question unanswered (what it asked about is gone)."""
        self.withdrawn = True
        self.close()


def ask(text, yes, no, autoclose_ms=0, careful=False, addon_path=None, opened=None):
    """Asks; True for yes, False for no or Back, None when it closed by itself or was withdrawn. `opened` is given
    the window before it shows, to withdraw it."""
    window = QuestionWindow(text, yes, no, autoclose_ms, careful, _path(addon_path))
    try:
        if opened:
            opened(window)
        window.doModal()
    finally:
        window.done.set()  # also when showing it failed: its timer would otherwise wait out the full time
    answer = window.answer
    del window
    return answer


def tell(text, addon_path=None):
    """Says something that needs nothing more than OK (or Back)."""
    ask(text, 'OK', None, addon_path=addon_path)


class Waiting(QuestionWindow):
    """The window without buttons, shown while something takes a few seconds; a bar fills along the bottom. Back
    stops the wait (cancelled)."""

    def __new__(cls, text, addon_path=''):
        return super().__new__(cls, text, '', addon_path=addon_path)

    def __init__(self, text, addon_path=''):
        super().__init__(text, '', addon_path=addon_path)
        self.cancelled = False

    def onInit(self):
        self.fill()

    def fill(self):
        """Also called straight after show(): Kodi calls onInit only once the script lets it (a waitForAbort), so
        the window stood empty, buttons and all, until then."""
        self.place()
        for button in (YES, NO):
            self.getControl(button).setVisible(False)

    def update(self, percent):
        bar = self.getControl(BAR)
        bar.setWidth(max(1, int(BAR_WIDTH * min(100, max(0, percent)) / 100)))
        bar.setVisible(True)

    def onClick(self, control_id):
        pass

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True


def waiting(text, addon_path=None):
    """Opens the waiting window (closed by its close())."""
    window = Waiting(text, _path(addon_path))
    window.show()
    window.fill()
    window.update(0)
    return window
