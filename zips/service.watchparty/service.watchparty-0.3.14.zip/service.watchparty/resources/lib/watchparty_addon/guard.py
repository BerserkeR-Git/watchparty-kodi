"""An exception that leaves a thread of an add-on is a script error in Kodi, and that thread's work stops unseen.
Every thread Watch Party starts runs inside logged(): the error and its details go to Kodi's log instead."""
import functools
import traceback

import xbmc


def logged(what):
    def decorate(function):
        @functools.wraps(function)
        def guarded(*args, **kwargs):
            try:
                return function(*args, **kwargs)
            except Exception:  # noqa: BLE001 - whatever it was: logged, never raised into Kodi
                try:
                    xbmc.log('[Watch Party] {} failed:\n{}'.format(what, traceback.format_exc()), xbmc.LOGERROR)
                except Exception:  # noqa: BLE001 - not even the log: nothing left to do
                    pass
                return None
        return guarded
    return decorate
