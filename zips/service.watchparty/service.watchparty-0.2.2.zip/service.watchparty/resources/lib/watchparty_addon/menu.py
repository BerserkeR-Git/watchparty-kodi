"""The Watch Party menu, opened from Add-ons. Uses Kodi's own dialogs so it matches the skin."""
import os
import threading
import time
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .avatars import Avatars
from .client import AddressProblem, Client
from .engine import SendError, describe

HEADING = 'Watch Party'
RELOAD_PROPERTY = 'watchparty.reload'
KEYMAP = 'special://profile/keymaps/watchparty.xml'
KEYMAP_FOLDER = 'special://profile/keymaps'
KEYMAP_EDITOR = 'script.keymap'
# Kodi's key numbers for the ready-made keyboard shortcuts, for writing them into the Keymap Editor's file:
# key 0xF000 plus the letter, plus 0x40000 for Alt or 0x1000000 for a long press.
ALT_P_CODE = 0xF050 | 0x40000
LONG_I_CODE = 0xF049 | 0x1000000
# Ready-made shortcuts. Long presses keep a button's usual job on a short press.
BUTTONS = {
    # Alt+P: unused in Kodi's own keymap, and it closes nothing in other programs (Ctrl+W would).
    'altp': ('Alt+P on a keyboard', '<keyboard><p mod="alt">{a}</p></keyboard>'),
    'info': ('Long-press the Info button on a remote', '<keyboard><i mod="longpress">{a}</i></keyboard>'
                                                       '<remote><info mod="longpress">{a}</info></remote>'),
    'red': ('Long-press the red button on a remote', '<keyboard><f1 mod="longpress">{a}</f1></keyboard>'
                                                     '<remote><red mod="longpress">{a}</red></remote>'),
}
OPEN_ACTION = 'RunScript(service.watchparty)'
# Keys nobody should lose (Kodi action numbers): moving around (1-6), OK (7), back (9, 10, 92), pause (12),
# stop (13), next and previous (14, 15), fast forward and rewind (16, 17, 77, 78), the menu (18), jumps (20-23),
# the player controls (24), play (79), play/pause (229), volume (88, 89, 91) and the context menu (117).
PROTECTED_ACTIONS = {1, 2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 77, 78, 79, 88, 89,
                     91, 92, 117, 229}
CANCEL_ACTIONS = {10, 92}
LISTEN_S = 5


class KeymapUnreadable(Exception):
    pass


class KeyListener(xbmcgui.WindowXMLDialog):
    """Waits a few seconds for one key or button, shown in the skin's own notification window."""

    def __new__(cls, *args, **kwargs):
        return super().__new__(cls, 'DialogNotification.xml', '')

    def __init__(self, *args, **kwargs):
        self.code = None
        self.action = None
        self.cancelled = False

    def onInit(self):
        for control, text in ((401, 'Press the key or button for Watch Party'),
                              (402, 'Listening for {} seconds. Press Back to cancel.'.format(LISTEN_S))):
            try:
                self.getControl(control).setLabel(text)
            except (RuntimeError, AttributeError, TypeError):
                pass

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True
        else:
            code = action.getButtonCode()
            if code:
                self.code, self.action = code, action.getId()
        self.close()

    @classmethod
    def listen(cls):
        dialog = cls()
        timer = threading.Timer(LISTEN_S, dialog.close)
        timer.start()
        dialog.doModal()
        timer.cancel()
        return dialog.code, dialog.action, dialog.cancelled

PROBLEMS = {
    'offline': "Watch Party can't be reached right now. Check the internet connection and try again.",
    'disconnected': 'This device is no longer connected. Choose Connect this device and enter a new code.',
    'wrong_code': 'That code was not accepted. A code can be used once and expires after a few minutes; ask for a new one.',
    'party_full': 'The watch party is full.',
    'nobody_to_invite': 'Everyone you chose is already in the watch party, or has no other device connected.',
    'no_invitation': 'That invitation has expired.',
    'host_only': 'Only the host can do that.',
    'not_in_party': 'You are not in a watch party.',
}


def tell(text):
    xbmcgui.Dialog().ok(HEADING, text)


def problem(error):
    tell(PROBLEMS.get(error.code, 'That did not work. Try again in a moment.'))


def reload_service():
    xbmcgui.Window(10000).setProperty(RELOAD_PROPERTY, str(time.time()))


def item(label, label2='', icon=None):
    entry = xbmcgui.ListItem(label, label2)
    if icon:
        entry.setArt({'icon': icon, 'thumb': icon})
    return entry


class Menu:
    def __init__(self, storage, addon_icon, version='0.0.0'):
        self.storage = storage
        self.addon_icon = addon_icon
        self.version = version

    # Connecting ------------------------------------------------------------

    def connect(self):
        previous = self.storage.preferences().get('last_address', '')
        address = xbmcgui.Dialog().input('Watch Party address, for example sync.example.com', defaultt=previous)
        if not address:
            return
        try:
            client = Client(address, version=self.version)
        except AddressProblem as error:
            tell(str(error))
            return
        code = xbmcgui.Dialog().input('Connection code (for example K7QM-3XPD)')
        if not code:
            return
        try:
            paired = client.pair(code)
        except SendError as error:
            problem(error)
            return
        self.storage.save_device({'address': client.address, 'device': paired['device'], 'secret': paired['secret'],
                                  'generation': paired.get('generation', 0),
                                  'name': paired.get('name', ''), 'device_name': paired.get('device_name', '')})
        preferences = self.storage.preferences()
        preferences['last_address'] = client.address.split('://', 1)[1]
        self.storage.save_preferences(preferences)
        reload_service()
        tell('Connected as {} for {}. You can now start or join watch parties.'.format(
            paired.get('device_name') or 'this device', paired.get('name') or 'you'))

    def disconnect(self):
        if xbmcgui.Dialog().yesno(HEADING, 'Disconnect this device from Watch Party? To use it again, you need a new '
                                           'connection code from your Watch Party administrator.',
                                  nolabel='Cancel', yeslabel='Disconnect'):
            self.storage.forget_device()
            reload_service()

    # The main menu -----------------------------------------------------------

    def run(self):
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            if device and device.get('unreadable'):
                text = ("This device's connection was made on another machine and cannot be used here. "
                        'Connect it with a new code.')
            else:
                text = ('This device was disconnected. ' if device else '') + 'Connect it with the code you were given.'
            if xbmcgui.Dialog().yesno(HEADING, text, nolabel='Cancel', yeslabel='Connect'):
                self.connect()
            return
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        self.avatars = Avatars(self.storage.avatar_folder, client)
        try:
            state = client.state(0)
        except SendError as error:
            problem(error)
            if error.code == 'disconnected' and xbmcgui.Dialog().yesno(HEADING, 'Connect again now?'):
                self.connect()
            return
        self.main(client, state)

    def main(self, client, state):
        party = state.get('party')
        choices = []
        if party:
            others = [m['name'] if m['person'] != state['me']['person'] else 'your ' + m['device_name']
                      for m in party['members'] if not m['me']]
            watching = describe(party.get('item')) or 'No title selected yet'
            choices.append((item('In a watch party' + (' with ' + ', '.join(others) if others else ''), watching,
                                 self.addon_icon), None))
            choices.append((item('Invite more people', 'Choose who to add'), lambda: self.invite(client, state)))
            choices.append((item('Leave the watch party', 'The others carry on without you'),
                            lambda: self.act(client, {'type': 'leave'})))
            if party.get('i_am_host'):
                choices.append((item('End the watch party for everyone'), lambda: self.end(client)))
        else:
            choices.append((item('Start a watch party', 'Choose who to invite'), lambda: self.invite(client, state)))
        for invitation in state.get('invitations', []):
            label = 'Join {}\'s watch party'.format(invitation['from']) if not invitation.get('from_me') else \
                'Join the watch party from your {}'.format(invitation.get('from_device') or 'other device')
            people = ', '.join(invitation.get('people', []))
            if invitation.get('can_watch') is False:
                people += " \u00b7 watching something you don't have access to"
            choices.append((item(label, people), lambda i=invitation: self.act(
                client, {'type': 'respond', 'party': i['party'], 'accept': True}, 'You joined the watch party.')))
        preferences = self.storage.preferences()
        dnd = preferences.get('do_not_disturb')
        choices.append((item('Do not disturb: ' + ('on' if dnd else 'off'),
                             'No invitations while it is on' if dnd else 'Invitations can appear'),
                        lambda: self.toggle_dnd(preferences)))
        choices.append((item('People', self.online_summary(state)), lambda: self.people(client, state)))
        choices.append((item('Shortcut to open Watch Party', self.shortcut_label(preferences)),
                        lambda: self.remote_button(preferences)))
        me = state.get('me', {})
        choices.append((item('Disconnect this device', '{} for {}'.format(
            self.storage.device().get('device_name') or 'This device', me.get('name', ''))), self.disconnect))
        picked = xbmcgui.Dialog().select('{} {}'.format(HEADING, self.version), [c[0] for c in choices], useDetails=True)
        if picked >= 0 and choices[picked][1]:
            choices[picked][1]()

    # Actions -------------------------------------------------------------------

    def act(self, client, payload, success=None):
        try:
            client.act(payload)
        except SendError as error:
            problem(error)
            return False
        if success:
            xbmcgui.Dialog().notification(HEADING, success, self.addon_icon, 4000, False)
        return True

    def end(self, client):
        if xbmcgui.Dialog().yesno(HEADING, 'End the watch party for everyone?', nolabel='Cancel', yeslabel='End it'):
            self.act(client, {'type': 'end'})

    def toggle_dnd(self, preferences):
        preferences['do_not_disturb'] = not preferences.get('do_not_disturb')
        self.storage.save_preferences(preferences)

    def invite(self, client, state):
        people = [p for p in state.get('people', []) if not p.get('in_my_party') or p.get('me')]
        if not people:
            tell('There is nobody to invite yet. Ask your Watch Party administrator to add people.')
            return
        entries = [item('Your other devices' if p.get('me') else p['name'], self.status_line(p),
                        self.avatar(client, p)) for p in people]
        chosen = xbmcgui.Dialog().multiselect('Who do you want to watch with?', entries, useDetails=True)
        if not chosen:
            return
        names = [people[i]['name'] if not people[i].get('me') else 'your other devices' for i in chosen]
        self.act(client, {'type': 'invite', 'people': [people[i]['id'] for i in chosen]},
                 'Invitation sent to {}.'.format(', '.join(names)))

    def people(self, client, state):
        entries = [item(p['name'] + (' (you)' if p.get('me') else ''), self.status_line(p), self.avatar(client, p))
                   for p in state.get('people', [])]
        xbmcgui.Dialog().select('People', entries, useDetails=True)

    @staticmethod
    def status_line(person):
        if not person.get('online'):
            return 'Not online'
        if person.get('watching'):
            return 'Watching ' + describe(person['watching'])
        return 'Online' + (' · in your watch party' if person.get('in_my_party') and not person.get('me') else '')

    @staticmethod
    def online_summary(state):
        online = [p['name'] for p in state.get('people', []) if p.get('online') and not p.get('me')]
        return 'Online now: ' + ', '.join(online) if online else 'Nobody else is online'

    def avatar(self, client, person):
        """A cached picture for the person (fetched now if missing, since a list is about to show it)."""
        if not person.get('avatar'):
            return self.addon_icon
        return self.avatars.get(person['id'], wait=True) or self.addon_icon

    def shortcut_label(self, preferences):
        chosen = preferences.get('remote_button')
        if chosen and not self.shortcut_present():
            return 'Your shortcut was removed, perhaps by the Keymap Editor. Choose it again'
        if chosen in BUTTONS:
            return BUTTONS[chosen][0] + ' opens it, even during a film'
        if chosen == 'own':
            return 'Your own key or button opens it, even during a film'
        if chosen == 'ctrlw':
            return 'Ctrl+W opens it. Ctrl+W closes windows in many programs, so choose Alt+P instead'
        return 'Open Watch Party with one key or button, even during a film'

    @staticmethod
    def keymap_editor_file():
        """The Keymap Editor's own file when it is installed and renames other keymap files, else None.

        On save it renames every other keymap file to .bak (unless its multiple-files option is on),
        so Watch Party then keeps its shortcut inside that file, where the editor shows and keeps it.
        """
        if not xbmc.getCondVisibility('System.HasAddon({})'.format(KEYMAP_EDITOR)):
            return None
        try:
            editor = xbmcaddon.Addon(KEYMAP_EDITOR)
            if editor.getSetting('enable_multifile') == 'true':
                return None
            name = editor.getSetting('keymap_editor_filename') or 'gen'
        except RuntimeError:
            name = 'gen'
        return os.path.join(xbmcvfs.translatePath(KEYMAP_FOLDER), ''.join(c for c in name if c.isalnum() or c in '-_')
                            + '.xml')

    @staticmethod
    def _is_ours(element):
        return (element.text or '').strip().lower() == OPEN_ACTION.lower()

    def _edit_editor_file(self, path, code):
        """Remove Watch Party's line from the Keymap Editor's file and, with a code, add it back. Nothing else changes.

        A file that is there but cannot be read is never replaced: it holds the person's own shortcuts.
        """
        try:
            root = ElementTree.parse(path).getroot()
        except FileNotFoundError:
            root = ElementTree.Element('keymap')
        except (OSError, ElementTree.ParseError):
            raise KeymapUnreadable() from None
        for context in root:
            for device in context:
                for mapping in [m for m in device if self._is_ours(m)]:
                    device.remove(mapping)
        if code is not None:
            context = root.find('global')
            if context is None:
                context = ElementTree.SubElement(root, 'global')
            keyboard = context.find('keyboard')
            if keyboard is None:
                keyboard = ElementTree.SubElement(context, 'keyboard')
            ElementTree.SubElement(keyboard, 'key', {'id': str(int(code))}).text = OPEN_ACTION.lower()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        temporary = path + '.watchparty-new'
        ElementTree.ElementTree(root).write(temporary, encoding='utf-8')
        os.replace(temporary, path)

    def _write_keymap(self, body, code=None):
        """Save the shortcut: `body` for Watch Party's own file, `code` for the Keymap Editor's file.

        False (after telling the person) when the Keymap Editor's file could not be read; nothing changed then.
        """
        own = xbmcvfs.translatePath(KEYMAP)
        editor = self.keymap_editor_file()
        if editor:
            try:
                self._edit_editor_file(editor, code if body is not None else None)
            except KeymapUnreadable:
                tell('Watch Party could not read the Keymap Editor\'s file, so it changed nothing. Your own '
                     'shortcuts there are untouched.')
                return False
        try:
            os.remove(own)
        except OSError:
            pass
        if not editor and body is not None:
            os.makedirs(os.path.dirname(own), exist_ok=True)
            with open(own, 'w', encoding='utf-8') as handle:
                handle.write('<keymap><global>' + body + '</global></keymap>\n')
        xbmc.executebuiltin('Action(reloadkeymaps)')
        return True

    def shortcut_present(self):
        editor = self.keymap_editor_file()
        if not editor:
            return os.path.exists(xbmcvfs.translatePath(KEYMAP))
        try:
            return any(self._is_ours(m) for m in ElementTree.parse(editor).getroot().iter())
        except (OSError, ElementTree.ParseError):
            return False

    def existing_use(self, code):
        """What another keymap file already does with this key number, if anything."""
        folder = xbmcvfs.translatePath(KEYMAP_FOLDER)
        try:
            names = [n for n in os.listdir(folder) if n.endswith('.xml')]
        except OSError:
            return None
        for name in names:
            try:
                root = ElementTree.parse(os.path.join(folder, name)).getroot()
            except (OSError, ElementTree.ParseError):
                continue
            for mapping in root.iter('key'):
                if mapping.get('id') == str(int(code)) and not self._is_ours(mapping) and (mapping.text or '').strip():
                    return mapping.text.strip()
        return None

    def remote_button(self, preferences):
        editor = self.keymap_editor_file()
        # The Keymap Editor's file holds key numbers only, so named remote buttons are offered without it.
        keys = ['altp', 'info'] if editor else list(BUTTONS)
        labels = ['Press the key or button you want'] + [BUTTONS[k][0] for k in keys] + ['No shortcut']
        picked = xbmcgui.Dialog().select('Which key or button opens Watch Party?', labels)
        if picked < 0:
            return
        if picked == 0:
            code, action, cancelled = KeyListener.listen()
            if cancelled:
                return
            if not code:
                tell('Nothing was pressed. Choose Shortcut again and press the key or button within '
                     '{} seconds.'.format(LISTEN_S))
                return
            if action in PROTECTED_ACTIONS:
                tell('That key or button is needed for moving around or playback, so it cannot open '
                     'Watch Party. Choose another one, or a long press from the list.')
                return
            used = self.existing_use(code)
            if used and not xbmcgui.Dialog().yesno(
                    HEADING, 'Your own keymap already uses that key or button for "{}". Use it for Watch Party '
                             'instead?'.format(used), nolabel='Cancel', yeslabel='Use it'):
                return
            if not used and action and not xbmcgui.Dialog().yesno(
                    HEADING, 'That key or button already does something in Kodi. Use it for Watch Party instead?',
                    nolabel='Cancel', yeslabel='Use it'):
                return
            if not self._write_keymap('<keyboard><key id="{}">{}</key></keyboard>'.format(int(code), OPEN_ACTION),
                                      code):
                return
            preferences['remote_button'] = 'own'
            done = 'That key or button now opens Watch Party.'
        elif picked == len(labels) - 1:
            if not self._write_keymap(None):
                return
            preferences.pop('remote_button', None)
            done = 'No key or button opens Watch Party now.'
        else:
            key = keys[picked - 1]
            code = {'altp': ALT_P_CODE, 'info': LONG_I_CODE}.get(key)
            used = self.existing_use(code) if code else None
            if used and not xbmcgui.Dialog().yesno(
                    HEADING, 'Your own keymap already uses that for "{}". Use it for Watch Party instead?'.format(used),
                    nolabel='Cancel', yeslabel='Use it'):
                return
            if not self._write_keymap(BUTTONS[key][1].format(a=OPEN_ACTION), code):
                return
            preferences['remote_button'] = key
            done = BUTTONS[key][0] + ' now opens Watch Party.'
        self.storage.save_preferences(preferences)
        if editor and picked != len(labels) - 1:
            done += " It is saved in the Keymap Editor's file, so it shows up there too."
        tell(done)
