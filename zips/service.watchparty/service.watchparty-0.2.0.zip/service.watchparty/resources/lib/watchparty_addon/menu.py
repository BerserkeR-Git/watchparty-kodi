"""The Watch Party menu, opened from Add-ons. Uses Kodi's own dialogs so it matches the skin."""
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

from .avatars import Avatars
from .client import AddressProblem, Client
from .engine import SendError, describe

HEADING = 'Watch Party'
RELOAD_PROPERTY = 'watchparty.reload'
KEYMAP = 'special://profile/keymaps/watchparty.xml'
# Long presses, so the buttons keep their usual job on a short press.
BUTTONS = {
    'info': ('Long-press the Info button', '<keyboard><i mod="longpress">{a}</i></keyboard>'
                                            '<remote><info mod="longpress">{a}</info></remote>'),
    'red': ('Long-press the red button', '<keyboard><f1 mod="longpress">{a}</f1></keyboard>'
                                         '<remote><red mod="longpress">{a}</red></remote>'),
}

PROBLEMS = {
    'offline': "Watch Party can't be reached right now. Check the internet connection and try again.",
    'disconnected': 'This device is no longer connected. Choose Connect this device and enter a new code.',
    'wrong_code': 'That code did not work. Codes work once and only for a few minutes: ask for a new one.',
    'party_full': 'The watch party is full.',
    'nobody_to_invite': 'Everyone you chose is already in the watch party, or has no other device connected.',
    'no_invitation': 'That invitation has expired.',
    'host_only': 'Only the host can do that.',
    'not_in_party': 'You are not in a watch party.',
}


def tell(text):
    xbmcgui.Dialog().ok(HEADING, text)


def problem(error):
    tell(PROBLEMS.get(error.code, 'That did not work. Try again in a moment.'))


def reload_service():
    xbmcgui.Window(10000).setProperty(RELOAD_PROPERTY, str(time.time()))


def item(label, label2='', icon=None):
    entry = xbmcgui.ListItem(label, label2)
    if icon:
        entry.setArt({'icon': icon, 'thumb': icon})
    return entry


class Menu:
    def __init__(self, storage, addon_icon, version='0.0.0'):
        self.storage = storage
        self.addon_icon = addon_icon
        self.version = version

    # Connecting ------------------------------------------------------------

    def connect(self):
        previous = self.storage.preferences().get('last_address', '')
        address = xbmcgui.Dialog().input('Watch Party address, for example sync.example.com', defaultt=previous)
        if not address:
            return
        try:
            client = Client(address, version=self.version)
        except AddressProblem as error:
            tell(str(error))
            return
        code = xbmcgui.Dialog().input('Connection code (for example K7QM-3XPD)')
        if not code:
            return
        try:
            paired = client.pair(code)
        except SendError as error:
            problem(error)
            return
        self.storage.save_device({'address': client.address, 'device': paired['device'], 'secret': paired['secret'],
                                  'generation': paired.get('generation', 0),
                                  'name': paired.get('name', ''), 'device_name': paired.get('device_name', '')})
        preferences = self.storage.preferences()
        preferences['last_address'] = client.address.split('://', 1)[1]
        self.storage.save_preferences(preferences)
        reload_service()
        tell('Connected. This is {} for {}. You can start or join watch parties now.'.format(
            paired.get('device_name') or 'this device', paired.get('name') or 'you'))

    def disconnect(self):
        if xbmcgui.Dialog().yesno(HEADING, 'Disconnect this device from Watch Party? To use it again you need a new '
                                           'code from whoever runs your Watch Party.',
                                  nolabel='Cancel', yeslabel='Disconnect'):
            self.storage.forget_device()
            reload_service()

    # The main menu -----------------------------------------------------------

    def run(self):
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            if device and device.get('unreadable'):
                text = ("This device's connection was made on another machine and cannot be used here. "
                        'Connect it with a new code.')
            else:
                text = ('This device was disconnected. ' if device else '') + 'Connect it with the code you were given.'
            if xbmcgui.Dialog().yesno(HEADING, text, nolabel='Cancel', yeslabel='Connect'):
                self.connect()
            return
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        self.avatars = Avatars(self.storage.avatar_folder, client)
        try:
            state = client.state(0)
        except SendError as error:
            problem(error)
            if error.code == 'disconnected' and xbmcgui.Dialog().yesno(HEADING, 'Connect again now?'):
                self.connect()
            return
        self.main(client, state)

    def main(self, client, state):
        party = state.get('party')
        choices = []
        if party:
            others = [m['name'] if m['person'] != state['me']['person'] else 'your ' + m['device_name']
                      for m in party['members'] if not m['me']]
            watching = describe(party.get('item')) or 'Nothing chosen yet'
            choices.append((item('In a watch party' + (' with ' + ', '.join(others) if others else ''), watching,
                                 self.addon_icon), None))
            choices.append((item('Invite more people', 'Choose who to add'), lambda: self.invite(client, state)))
            choices.append((item('Leave the watch party', 'The others carry on without you'),
                            lambda: self.act(client, {'type': 'leave'})))
            if party.get('i_am_host'):
                choices.append((item('End the watch party for everyone'), lambda: self.end(client)))
        else:
            choices.append((item('Start a watch party', 'Choose who to invite'), lambda: self.invite(client, state)))
        for invitation in state.get('invitations', []):
            label = 'Join {}\'s watch party'.format(invitation['from']) if not invitation.get('from_me') else \
                'Join the watch party from your {}'.format(invitation.get('from_device') or 'other device')
            people = ', '.join(invitation.get('people', []))
            if invitation.get('can_watch') is False:
                people += " \u00b7 watching something you don't have access to"
            choices.append((item(label, people), lambda i=invitation: self.act(
                client, {'type': 'respond', 'party': i['party'], 'accept': True}, 'You joined the watch party.')))
        preferences = self.storage.preferences()
        dnd = preferences.get('do_not_disturb')
        choices.append((item('Do not disturb: ' + ('on' if dnd else 'off'),
                             'No invitations while it is on' if dnd else 'Invitations can appear'),
                        lambda: self.toggle_dnd(preferences)))
        choices.append((item('People', self.online_summary(state)), lambda: self.people(client, state)))
        button = preferences.get('remote_button')
        choices.append((item('Remote button', BUTTONS[button][0] + ' opens Watch Party' if button in BUTTONS
                             else 'Open Watch Party with one button, even during a film'),
                        lambda: self.remote_button(preferences)))
        me = state.get('me', {})
        choices.append((item('Disconnect this device', '{} for {}'.format(
            self.storage.device().get('device_name') or 'This device', me.get('name', ''))), self.disconnect))
        picked = xbmcgui.Dialog().select(HEADING, [c[0] for c in choices], useDetails=True)
        if picked >= 0 and choices[picked][1]:
            choices[picked][1]()

    # Actions -------------------------------------------------------------------

    def act(self, client, payload, success=None):
        try:
            client.act(payload)
        except SendError as error:
            problem(error)
            return False
        if success:
            xbmcgui.Dialog().notification(HEADING, success, self.addon_icon, 4000, False)
        return True

    def end(self, client):
        if xbmcgui.Dialog().yesno(HEADING, 'End the watch party for everyone?', nolabel='Cancel', yeslabel='End it'):
            self.act(client, {'type': 'end'})

    def toggle_dnd(self, preferences):
        preferences['do_not_disturb'] = not preferences.get('do_not_disturb')
        self.storage.save_preferences(preferences)

    def invite(self, client, state):
        people = [p for p in state.get('people', []) if not p.get('in_my_party') or p.get('me')]
        if not people:
            tell('There is nobody else to invite yet. Ask whoever runs your Watch Party to add people.')
            return
        entries = [item('Your other devices' if p.get('me') else p['name'], self.status_line(p),
                        self.avatar(client, p)) for p in people]
        chosen = xbmcgui.Dialog().multiselect('Who do you want to watch with?', entries, useDetails=True)
        if not chosen:
            return
        names = [people[i]['name'] if not people[i].get('me') else 'your other devices' for i in chosen]
        self.act(client, {'type': 'invite', 'people': [people[i]['id'] for i in chosen]},
                 'Invitation sent to {}.'.format(', '.join(names)))

    def people(self, client, state):
        entries = [item(p['name'] + (' (you)' if p.get('me') else ''), self.status_line(p), self.avatar(client, p))
                   for p in state.get('people', [])]
        xbmcgui.Dialog().select('People', entries, useDetails=True)

    @staticmethod
    def status_line(person):
        if not person.get('online'):
            return 'Not online'
        if person.get('watching'):
            return 'Watching ' + describe(person['watching'])
        return 'Online' + (' · in your watch party' if person.get('in_my_party') and not person.get('me') else '')

    @staticmethod
    def online_summary(state):
        online = [p['name'] for p in state.get('people', []) if p.get('online') and not p.get('me')]
        return 'Online now: ' + ', '.join(online) if online else 'Nobody else is online'

    def avatar(self, client, person):
        """A cached picture for the person (fetched now if missing, since a list is about to show it)."""
        if not person.get('avatar'):
            return self.addon_icon
        return self.avatars.get(person['id'], wait=True) or self.addon_icon

    def remote_button(self, preferences):
        keys = list(BUTTONS)
        labels = [BUTTONS[k][0] for k in keys] + ['No button']
        picked = xbmcgui.Dialog().select('Which button opens Watch Party?', labels)
        if picked < 0:
            return
        path = xbmcvfs.translatePath(KEYMAP)
        if picked == len(keys):
            try:
                os.remove(path)
            except OSError:
                pass
            preferences.pop('remote_button', None)
        else:
            key = keys[picked]
            body = BUTTONS[key][1].format(a='RunScript(service.watchparty)')
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write('<keymap><global>' + body + '</global></keymap>\n')
            preferences['remote_button'] = key
        self.storage.save_preferences(preferences)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        tell('Done. ' + (labels[picked] + ' now opens Watch Party.' if picked < len(keys)
                         else 'No button opens Watch Party now.'))
