"""Talking to the Watch Party server: pairing, signed requests and the server's clock.

Standard library only, because Kodi ships no extra packages.
"""
import base64
import email.utils
import hashlib
import hmac
import http.client
import json
import secrets
import ssl
import threading
import time
import urllib.parse

from .engine import SendError

HEADER_DEVICE = 'X-Watchparty-Device'
HEADER_TIME = 'X-Watchparty-Time'
HEADER_NONCE = 'X-Watchparty-Nonce'
HEADER_SIGNATURE = 'X-Watchparty-Signature'
HEADER_GENERATION = 'X-Watchparty-Key'

LONG_POLL_TIMEOUT_S = 40
REQUEST_TIMEOUT_S = 15
# Actions are sent while someone is watching, so they give up quickly when the server is away.
ACTION_TIMEOUT_S = 6
# Plain http is refused. Only test code sets this, to talk to a local server; nothing a device stores can.
ALLOW_HTTP_FOR_TESTS = False


class _StaleConnection(Exception):
    """A kept-open connection the server had already closed. Safe to retry on a new one."""


class AddressProblem(ValueError):
    """An address the viewer typed that cannot be used, in plain words."""


def normalise_address(text, allow_http=False):
    text = (text or '').strip()
    if not text:
        raise AddressProblem('Enter the address you were given.')
    if '://' not in text:
        text = 'https://' + text
    text = text.rstrip('/')
    try:
        parts = urllib.parse.urlsplit(text)
        hostname = parts.hostname
    except ValueError:
        raise AddressProblem('That does not look like an address.') from None
    if parts.scheme == 'http' and not allow_http:
        # Typed http:// by habit: Watch Party only speaks https, so use that.
        parts = parts._replace(scheme='https')
    if parts.scheme not in ('https', 'http'):
        raise AddressProblem('The address has to start with https://')
    if not hostname or parts.path not in ('', '/') or parts.query or parts.fragment or parts.username:
        raise AddressProblem('That does not look like an address.')
    return '{}://{}'.format(parts.scheme, parts.netloc)


def canonical(method, path, timestamp, nonce, body):
    digest = hashlib.sha256(body or b'').hexdigest()
    return '\n'.join((method.upper(), path, str(timestamp), nonce, digest)).encode('utf-8')


def sign(secret, method, path, timestamp, nonce, body):
    key = base64.urlsafe_b64decode((secret + '=' * (-len(secret) % 4)).encode('ascii'))
    return hmac.new(key, canonical(method, path, timestamp, nonce, body), hashlib.sha256).hexdigest()


class Client:
    def __init__(self, address, device=None, secret=None, allow_http=False, generation=0, key_store=None,
                 version='0.0.0'):
        self.address = normalise_address(address, allow_http=allow_http or ALLOW_HTTP_FOR_TESTS)
        self.device = device
        self.secret = secret
        self.generation = generation
        # When given, the key is read from (and a new one saved to) the sealed file around every request,
        # so the service and the menu always sign with the same, current key.
        self.key_store = key_store
        self.agent = 'WatchParty-Kodi/' + version
        self.offset_ms = 0
        self.context = ssl.create_default_context()
        parts = urllib.parse.urlsplit(self.address)
        self._host, self._port, self._https = parts.hostname, parts.port, parts.scheme == 'https'
        # One kept-open connection per thread: new encrypted connections are the costly part on small ARM boxes.
        self._local = threading.local()

    # Clock -------------------------------------------------------------------

    def server_now(self):
        return int(time.time() * 1000) + self.offset_ms

    def _note_server_time(self, sent, received, server_ms):
        if isinstance(server_ms, (int, float)) and not isinstance(server_ms, bool):
            self.offset_ms = int(server_ms - (sent + received) / 2)

    def _note_date(self, sent, received, date_header):
        """The Date header (whole seconds) corrects a clock that is far off. Returns True if it moved."""
        try:
            stamp = email.utils.parsedate_to_datetime(date_header).timestamp() * 1000
        except (TypeError, ValueError, IndexError):
            return False
        offset = int(stamp + 500 - (sent + received) / 2)
        if abs(offset - self.offset_ms) > 1500:
            self.offset_ms = offset
            return True
        return False

    # Requests ----------------------------------------------------------------

    def _connection(self, timeout):
        connection = getattr(self._local, 'connection', None)
        if connection is None:
            if self._https:
                connection = http.client.HTTPSConnection(self._host, self._port, timeout=timeout,
                                                         context=self.context)
            else:
                connection = http.client.HTTPConnection(self._host, self._port, timeout=timeout)
            self._local.connection = connection
            self._local.used = False
        connection.timeout = timeout
        if connection.sock is not None:
            connection.sock.settimeout(timeout)
        return connection

    def close(self):
        connection = getattr(self._local, 'connection', None)
        self._local.connection = None
        if connection is not None:
            try:
                connection.close()
            except OSError:
                pass

    def _open(self, method, path, body, headers, timeout):
        connection = self._connection(timeout)
        reused = self._local.used
        sent = time.time() * 1000
        try:
            connection.request(method, path, body=body if body else None, headers=headers)
            response = connection.getresponse()
            data = response.read()
        except (http.client.HTTPException, OSError, ValueError):
            self.close()
            if reused:
                raise _StaleConnection() from None
            raise SendError('offline') from None
        self._local.used = True
        if response.getheader('Connection', '').lower() == 'close':
            self.close()
        return response.status, data, response.headers, sent, time.time() * 1000

    def _open_once_more(self, method, path, body, headers, timeout):
        try:
            return self._open(method, path, body, headers, timeout)
        except _StaleConnection:
            return self._open(method, path, body, headers, timeout)

    def _current_key(self):
        if self.key_store is not None:
            secret, generation = self.key_store.load_key()
            if secret:
                self.secret, self.generation = secret, generation
        return self.secret, self.generation

    def _signed(self, method, path, payload=None, timeout=REQUEST_TIMEOUT_S, retry=True):
        secret, generation = self._current_key()
        if not (self.device and secret):
            raise SendError('disconnected')
        body = json.dumps(payload, separators=(',', ':')).encode('utf-8') if payload is not None else b''
        timestamp = str(self.server_now())
        nonce = secrets.token_hex(16)
        headers = {
            HEADER_DEVICE: self.device, HEADER_TIME: timestamp, HEADER_NONCE: nonce,
            HEADER_GENERATION: str(generation),
            HEADER_SIGNATURE: sign(secret, method, path, timestamp, nonce, body),
            'User-Agent': self.agent,
        }
        if body:
            headers['Content-Type'] = 'application/json'
        try:
            status, data, response_headers, sent, received = self._open(method, path, body, headers, timeout)
        except _StaleConnection:
            # The kept-open connection had gone quiet; sign afresh (new nonce) on a new one.
            return self._signed(method, path, payload, timeout, retry)
        if status == 404 and data:
            # Watch Party's own refusal is always empty. A 404 with a page is something in between,
            # such as Traefik while the container is down: the server is away, not this device's access.
            raise SendError('offline')
        if status == 404:
            # Either this device was disconnected, or its clock is off. The Date header tells which.
            moved = self._note_date(sent, received, response_headers.get('Date'))
            if retry and moved:
                return self._signed(method, path, payload, timeout, retry=False)
            raise SendError('disconnected')
        return status, data, sent, received

    def _signed_json(self, method, path, payload=None, timeout=REQUEST_TIMEOUT_S):
        status, data, sent, received = self._signed(method, path, payload, timeout)
        try:
            parsed = json.loads(data.decode('utf-8'))
        except (ValueError, UnicodeDecodeError):
            raise SendError('offline') from None
        if isinstance(parsed, dict):
            self._note_server_time(sent, received, parsed.get('server_time'))
        if status == 400:
            raise SendError((parsed or {}).get('error') or 'bad_request')
        if status != 200 or not isinstance(parsed, dict):
            raise SendError('offline')
        return parsed

    # What Watch Party offers ---------------------------------------------------

    def pair(self, code):
        """Trade a one-time code for this device's identity. Raises SendError('wrong_code')."""
        body = json.dumps({'code': code}).encode('utf-8')
        status, data, response_headers, sent, received = self._open_once_more(
            'POST', '/v1/pair', body, {'Content-Type': 'application/json', 'User-Agent': self.agent},
            REQUEST_TIMEOUT_S)
        if status == 404 and data:
            raise SendError('offline')
        if status == 404:
            raise SendError('wrong_code')
        try:
            paired = json.loads(data.decode('utf-8'))
            self.device, self.secret = paired['device'], paired['secret']
            self.generation = int(paired.get('generation', 0))
        except (ValueError, UnicodeDecodeError, KeyError, TypeError):
            raise SendError('offline') from None
        self._note_server_time(sent, received, paired.get('server_time'))
        return paired

    def act(self, payload):
        return self._signed_json('POST', '/v1/act', payload, timeout=ACTION_TIMEOUT_S)

    def state(self, since):
        state = self._signed_json('GET', '/v1/state?since=%d' % int(since), timeout=LONG_POLL_TIMEOUT_S)
        offered = state.pop('key', None)
        if isinstance(offered, dict) and offered.get('secret') and isinstance(offered.get('generation'), int):
            # Keep the new key before using it; the old one retires once the server sees the new one.
            if self.key_store is not None:
                self.key_store.save_key(offered['secret'], offered['generation'])
            self.secret, self.generation = offered['secret'], offered['generation']
        return state

    def avatar(self, person):
        status, data, _, _ = self._signed('GET', '/v1/avatar/' + person)
        return data if status == 200 else None
