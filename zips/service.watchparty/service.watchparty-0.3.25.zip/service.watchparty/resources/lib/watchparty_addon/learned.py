"""What this device has learned about its own player, kept between sessions: how far ahead each kind of move aims
(its jump, skip and play leads) and how precisely its jumps land (the spread).

Each lesson is one measure: how far off the party a move left the player once it had settled, in seconds (positive:
ahead). A measure too far off to be about the move (a stall, a skip meanwhile) teaches nothing.
"""

# A jump while playing (following a skip) aims this much further, as the picture only moves that long after the
# jump starts; each device learns its own from where its jumps land. (A jump from pause needs no lead: it lands,
# reads where it landed and plays when the party reaches that frame; see the engine's _land.)
SEEK_LEAD_S = 0.4
# The range a learned jump lead stays in.
JUMP_LEAD_RANGE_S = (0.1, 3.0)
# Whoever skips takes this long to get going again (the laptop about 0.4 s, PM4K's own skip on the TV about
# 0.5 s): it says where it will be on the party's clock, not where its skip landed, or everyone following ends up
# ahead of it. Learned per device like the other leads.
SKIP_LEAD_S = 0.4
# How much of a measured error a single jump corrects (the rest waits for more jumps; one can be noisy). Jumps
# while playing and one's own skips land on keyframes on the TV (up to 2.6 s either way, owner's third
# diagnostics run): they are learned slowly, so that noise averages out instead of pushing the lead about.
NOISY_LEARNING = 0.3
# A held player is told to play this much before the moment, as it takes that long to get moving. Learned per
# device from where it is a moment after starting, like the jump lead; errors beyond PLAY_ERROR_MAX_S are
# something else (a stall) and teach nothing.
PLAY_LEAD_S = 0.0
PLAY_LEAD_RANGE_S = (0.0, 1.0)
PLAY_LEARNING = 0.5
PLAY_ERROR_MAX_S = 1.0
# How far this device's jumps while playing land from where they aim, learned as a running average of the misses
# (starting as a device that lands anywhere). One whose jumps land within PRECISE_JUMP_S (the laptop and the PC: a
# median 0.09 and 0.10 s in the owner's diagnostics) lines up once more after a skip that left it further off than
# IN_STEP_S, mostly the one who skipped (the laptop's own skips ended up to 0.6 s off). One that lands on keyframes
# (the TV: a median 0.58 s, up to 2.6 s) never does: a second jump would land just as far off.
JUMP_SPREAD_START_S = 1.0
JUMP_SPREAD_LEARNING = 0.3
PRECISE_JUMP_S = 0.35
# One lesson moves a lead at most this far: a single far skip that buffered took the TV's lead from 0.72 to 1.63 s.
LEAD_STEP_MAX_S = 0.25
# How far past its aim this device's PM4K skips land (a keyframe player lands later: the TV a median +1.8 s,
# +1.2 to +4.7 s, on 2026-10-16; a precise one at the aim). A PM4K skip is said at once from its aim plus this, and
# what it really did teaches it, so a new PM4K or box build is relearned within a handful of skips (owner: "if we use
# some static value for pm4k or p3i and it changes behavior somewhere, then everything will be invalid again").
LANDING_S = 0.0
LANDING_RANGE_S = (-1.0, 4.0)

# kind: (the name it is kept under, where it starts, its range, how much of a miss one lesson corrects, the largest
# miss that is still about the move, and the smallest change worth keeping)
LEADS = {
    'jump': ('seek_lead', SEEK_LEAD_S, JUMP_LEAD_RANGE_S, NOISY_LEARNING, 5.0, 0.02),
    'skip': ('skip_lead', SKIP_LEAD_S, (0.0, JUMP_LEAD_RANGE_S[1]), NOISY_LEARNING, 2.0, 0.02),
    'play': ('play_lead', PLAY_LEAD_S, PLAY_LEAD_RANGE_S, PLAY_LEARNING, PLAY_ERROR_MAX_S, 0.01),
    'landing': ('skip_landing', LANDING_S, LANDING_RANGE_S, NOISY_LEARNING, 5.0, 0.02),
}
SPREAD_NAME = 'jump_spread'
# Every name a device keeps what it learned under.
NAMES = tuple(name for name, *_ in LEADS.values()) + (SPREAD_NAME,)


def _step(change):
    """A lead moves at most LEAD_STEP_MAX_S per lesson."""
    return max(-LEAD_STEP_MAX_S, min(LEAD_STEP_MAX_S, change))


def _number(value, default):
    return value if isinstance(value, (int, float)) else default


class Learned:
    """The leads by kind ('jump', 'skip', 'play') as attributes, and `spread`. `values` is what was kept before,
    by name (see NAMES; anything missing or not a number starts afresh); `save(name, value)` keeps a change."""

    def __init__(self, values=None, save=None):
        values = values or {}
        self.save = save or (lambda name, value: None)
        for kind, (name, start, *_) in LEADS.items():
            setattr(self, kind, _number(values.get(name), start))
        self.spread = _number(values.get(SPREAD_NAME), JUMP_SPREAD_START_S)

    def learn(self, kind, error):
        """One lesson for a lead: returns (before, after), or None when the miss is too large to be about the move.
        A lesson about the jump lead also teaches the spread."""
        name, _, (low, high), learning, error_max, change_min = LEADS[kind]
        if abs(error) > error_max:
            return None
        before = getattr(self, kind)
        after = min(high, max(low, before - _step(learning * error)))
        if abs(after - before) >= change_min:
            setattr(self, kind, after)
            self.save(name, round(after, 3))
        if kind == 'jump':
            spread = (1 - JUMP_SPREAD_LEARNING) * self.spread + JUMP_SPREAD_LEARNING * abs(error)
            if abs(spread - self.spread) >= 0.01:
                self.spread = spread
                self.save(SPREAD_NAME, round(spread, 3))
        return before, after

    def precise(self):
        """Whether this device's jumps land precisely enough to line up once more after a skip."""
        return self.spread < PRECISE_JUMP_S
