"""The background service: keeps this device in the watch party while Kodi runs.

Light on purpose (small ARM boxes): one waiting request to the server at a time,
one kept-open connection, a quick loop only while a video plays or a countdown runs,
and patient retries when the server is away.
"""
import json
import os
import queue
import threading
import time

import xbmc
import xbmcgui

from . import shortcut, updates
from .avatars import Avatars
from .client import Client
from .engine import Engine, SendError
from .kodi_player import Observer, PlayerAdapter
from .kodi_screen import Screen

RELOAD_PROPERTY = 'watchparty.reload'
UPDATE_PROPERTY = 'watchparty.update'
# Set for as long as Kodi runs: without it, Kodi has just started (and not merely Watch Party, after an update).
SESSION_PROPERTY = 'watchparty.session'
ACTED_PROPERTY = 'watchparty.acted'
# After Kodi starts, Watch Party waits this long before it connects, so Kodi and PM4K (which may open at boot)
# have the screen to themselves; a watch party from before is then left quietly.
STARTUP_QUIET_S = 20
# An update started from the menu that has not arrived this long after is reported as not installed.
UPDATE_GRACE_S = 180
BUSY_TICK_S = 0.25
IDLE_TICK_S = 2.0
RETRY_STEPS_S = (1, 2, 5, 10, 30, 60)
# A refusal has to repeat for this long before this device counts as disconnected,
# so a restart or a deploy on the server cannot knock it out.
DISCONNECTED_AFTER = {'times': 3, 'seconds': 30}


def log(message):
    xbmc.log('[Watch Party] ' + message, xbmc.LOGINFO)


class KodiMonitor(xbmc.Monitor):
    """Kodi's own notices: quitting (or restarting) is said before add-ons stop; an add-on update says nothing.
    Standby and waking up (CoreELEC keeps Kodi running through standby) go to `on_power`."""

    def __init__(self):
        super().__init__()
        self.quitting = False
        self.on_power = lambda event: None

    def onNotification(self, sender, method, data):
        if sender != 'xbmc':
            return
        if method in ('System.OnQuit', 'System.OnRestart'):
            self.quitting = True
        elif method == 'System.OnSleep':
            self.on_power('sleep')
        elif method == 'System.OnWake':
            self.on_power('wake')


class Updates(threading.Thread):
    """Waits for the server's next update, one request at a time, and hands it to the loop."""

    def __init__(self, client, inbox):
        super().__init__(name='watchparty-updates', daemon=True)
        self.client = client
        self.inbox = inbox
        self.running = True

    def run(self):
        version, step, refusals, first_refusal = 0, 0, 0, None
        while self.running:
            try:
                state = self.client.state(version)
            except SendError as error:
                if error.code == 'disconnected':
                    refusals += 1
                    first_refusal = first_refusal or time.monotonic()
                    if (refusals >= DISCONNECTED_AFTER['times']
                            and time.monotonic() - first_refusal >= DISCONNECTED_AFTER['seconds']):
                        self.inbox.put(('disconnected', None))
                        return
                else:
                    refusals, first_refusal = 0, None
                self.inbox.put(('online', False))
                self._sleep(RETRY_STEPS_S[min(step, len(RETRY_STEPS_S) - 1)])
                step += 1
                continue
            step, refusals, first_refusal = 0, 0, None
            version = state.get('version', version)
            self.inbox.put(('online', True))
            self.inbox.put(('state', state))

    def _sleep(self, seconds):
        deadline = time.monotonic() + seconds
        while self.running and time.monotonic() < deadline:
            time.sleep(0.5)

    def stop(self):
        self.running = False
        self.client.close()


class Service:
    def __init__(self, addon_path, storage, version='0.0.0'):
        self.addon_path = addon_path
        self.storage = storage
        self.version = version
        self.monitor = KodiMonitor()
        self.inbox = queue.Queue()
        self.monitor.on_power = lambda event: self.inbox.put((event, None))
        self.observer = Observer(lambda name, data: self.inbox.put(('local', (name, data))))
        self.player = PlayerAdapter(self.observer)
        self.window = xbmcgui.Window(10000)
        self.fresh_kodi = False

    def run(self):
        log('started')
        self.fresh_kodi = not self.window.getProperty(SESSION_PROPERTY)
        self.window.setProperty(SESSION_PROPERTY, '1')
        if self.fresh_kodi:
            self.window.clearProperty(ACTED_PROPERTY)
        self._migrate_shortcut()
        self._announce_update()
        if self.fresh_kodi:
            self._leave_at_once()
        if self.fresh_kodi and self.monitor.waitForAbort(STARTUP_QUIET_S):
            log('stopped')
            return
        while not self.monitor.abortRequested():
            device = self.storage.device()
            if not device or device.get('disconnected') or device.get('unreadable'):
                if self._wait_for_change(5):
                    break
                continue
            if self._run_connected(device):
                break
        log('stopped')

    def _reload_requested(self, seen):
        value = self.window.getProperty(RELOAD_PROPERTY)
        return value != seen, value

    def _wait_for_change(self, seconds):
        """Sleep until the menu connects this device, or Kodi closes. True means Kodi is closing."""
        stamp = self.storage.stamp()
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self.monitor.waitForAbort(1):
                return True
            if self.storage.stamp() != stamp:
                return False
        return False

    def _migrate_shortcut(self):
        """Shortcuts chosen with 0.2.7 or older, written again the way Kodi reads them (see shortcut.migrate)."""
        # Kodi closed while a key was being chosen: give every key its job back.
        shortcut.stop_listening()
        preferences = self.storage.preferences()
        before = json.dumps(preferences, sort_keys=True)
        try:
            message = shortcut.migrate(preferences)
        except (shortcut.KeymapUnreadable, OSError) as error:
            log('shortcut not updated: {}'.format(type(error).__name__))
            return
        if json.dumps(preferences, sort_keys=True) != before:
            self.storage.save_preferences(preferences)
            log('shortcut written again for this version')
        if message:
            xbmcgui.Dialog().notification('Watch Party', message, os.path.join(self.addon_path, 'resources', 'icon.png'),
                                          15000, False)

    def _leave_at_once(self):
        """Kodi just started: leave a watch party from before right away, in the background (one small request),
        so nobody sees it as still going during the quiet wait. Should the network not be up yet, the engine leaves
        it once it connects."""
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            return
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)

        def leave():
            client.goodbye()
            client.close()
        threading.Thread(target=leave, name='watchparty-goodbye', daemon=True).start()

    def _notify(self, text, seconds=6):
        xbmcgui.Dialog().notification('Watch Party', text, os.path.join(self.addon_path, 'resources', 'icon.png'),
                                      seconds * 1000, False)

    def _announce_update(self):
        """Say that an update arrived: Kodi's own message about it is easy to miss, and Watch Party restarts."""
        preferences = self.storage.preferences()
        before = preferences.get('installed_version')
        if before is None and self.storage.device():
            before = 'an earlier version'  # 0.3.1 and older did not note their version; a connected device is no new install
        if before != self.version:
            preferences['installed_version'] = self.version
            self.storage.save_preferences(preferences)
            if before:
                log('updated from {} to {}'.format(before, self.version))
                self._notify('Watch Party was updated to version {}.'.format(self.version))
        self._check_update_request(arrived_only=True)

    def _check_update_request(self, arrived_only=False):
        """An update started from the menu: forget it once it is here; say so if it never came."""
        raw = self.window.getProperty(UPDATE_PROPERTY)
        if not raw:
            return
        try:
            request = json.loads(raw)
            wanted, at = str(request['version']), float(request['at'])
        except (ValueError, KeyError, TypeError):
            self.window.clearProperty(UPDATE_PROPERTY)
            return
        if not updates.newer(wanted, self.version):
            self.window.clearProperty(UPDATE_PROPERTY)
        elif not arrived_only and time.time() - at > UPDATE_GRACE_S:
            self.window.clearProperty(UPDATE_PROPERTY)
            log('update to {} did not arrive'.format(wanted))
            self._notify('Watch Party could not be updated to version {}. Open Watch Party and choose Check for '
                         'updates to try again.'.format(wanted), seconds=10)

    @staticmethod
    def _picture(engine_box, avatars, person):
        """A person's picture for a card, unless the server says they have none (removed on the admin page)."""
        engine = engine_box.get('engine')
        people = {p.get('id'): p.get('avatar') for p in ((engine.view if engine else None) or {}).get('people', [])}
        if person in people and not people[person]:
            avatars.forget(person)
            return None
        return avatars.get(person)

    @staticmethod
    def _pace(engine):
        """Seconds until the loop runs again. Four times a second only while something is under way or someone
        watches along; a video watched alone plays undisturbed (the player's own events still come in at once)."""
        tick = BUSY_TICK_S if engine.needs_quick_pace() else IDLE_TICK_S
        wake = engine.wake_in_ms()
        if wake is not None:
            # About to start: run exactly when needed, not up to a quarter second late.
            tick = min(tick, max(0.005, wake / 1000.0))
        return tick

    def _saver(self, name):
        def save(value):
            # Read just before writing, so a change the menu made meanwhile is kept.
            preferences = self.storage.preferences()
            preferences[name] = value
            self.storage.save_preferences(preferences)
        return save

    def _run_connected(self, device):
        """Serve one connection until it changes. True means Kodi is closing."""
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        avatars = Avatars(self.storage.avatar_folder, client)
        engine_box = {}
        screen = Screen(self.addon_path, client.server_now,
                        lambda: engine_box['engine'].settings.get('notice_s', 4),
                        lambda party, accept: self.inbox.put(('answer', (party, accept))),
                        avatar=lambda person: self._picture(engine_box, avatars, person),
                        card_folder=self.storage.card_folder,
                        log=lambda text: log('screen: ' + text))
        engine = Engine(self.player, screen, client.act, client.server_now, version=self.version,
                        log=lambda text: log('sync: ' + text),
                        jump_lead=self.storage.preferences().get('jump_lead'), on_jump_lead=self._saver('jump_lead'),
                        play_lead=self.storage.preferences().get('play_lead'), on_play_lead=self._saver('play_lead'),
                        clock_info=client.clock_quality,
                        seek_lead=self.storage.preferences().get('seek_lead'), on_seek_lead=self._saver('seek_lead'),
                        skip_lead=self.storage.preferences().get('skip_lead'), on_skip_lead=self._saver('skip_lead'),
                        # Not a party joined or started from the menu meanwhile (during the wait after Kodi started).
                        leave_old_party=self.fresh_kodi and not self.window.getProperty(ACTED_PROPERTY))
        self.fresh_kodi = False  # once per Kodi start
        engine_box['engine'] = engine
        engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        updates = Updates(client, self.inbox)
        updates.start()
        stamp = self.storage.stamp()
        seen_reload = self.window.getProperty(RELOAD_PROPERTY)
        log('connected as device ' + device['device'])
        try:
            while True:
                tick = self._pace(engine)
                if self.monitor.waitForAbort(0.001):
                    if self.monitor.quitting and engine.party():
                        # Kodi is closing: say goodbye, so the others are not left waiting for this device.
                        log('Kodi is closing: leaving the watch party')
                        client.goodbye()
                    return True
                try:
                    kind, payload = self.inbox.get(timeout=tick)
                except queue.Empty:
                    kind, payload = None, None
                if kind == 'local':
                    engine.on_local(payload[0], **payload[1])
                elif kind == 'state':
                    engine.on_state(payload)
                elif kind == 'online':
                    engine.set_online(payload)
                elif kind == 'answer':
                    engine.respond(*payload)
                elif kind == 'sleep':
                    # Standby: a device asleep cannot keep in touch, so it leaves now, as when Kodi closes, rather
                    # than being taken out minutes later while the others wait for it.
                    if engine.party():
                        log('Kodi is going to standby: leaving the watch party')
                        client.goodbye()
                    engine.left_for_standby()
                elif kind == 'disconnected':
                    screen.notice('This device was disconnected from Watch Party. Open Watch Party to connect it again.')
                    self.storage.mark_disconnected()
                    return False
                engine.tick()
                screen.tick()
                self._check_update_request()
                changed, seen_reload = self._reload_requested(seen_reload)
                if changed:
                    return False
                if self.storage.stamp() != stamp:
                    stamp = self.storage.stamp()
                    current = self.storage.device()
                    if not current or current.get('device') != device['device']:
                        return False
                    engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        finally:
            updates.stop()
            screen.close()
