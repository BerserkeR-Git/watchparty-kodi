"""What this device does when someone in a watch party pauses, plays, skips or starts.

There is no Kodi code in here. The engine works through three small adapters:
a player (what is playing, and pause/play/jump), a screen (cards and questions)
and send (one request to the Watch Party server). The same logic runs in the
tests and in Kodi.

Rules measured on a real device (PLAN.md, phase 0):
- Never hold a pause after a jump: jump, then play straight away.
- PM4K wraps its own skips in pause, jump, play and raises a flag meanwhile.
- PM4K's start-up (resume point) also pauses, jumps and plays. None of that is the viewer.
"""
import json

# One jump-and-play took 0.3 to 0.5 s on the CoreELEC box; a PC can take longer. This is where each device
# starts; it then learns its own from how far behind its jumps land.
JUMP_LEAD_S = 0.4
JUMP_LEAD_RANGE_S = (0.1, 3.0)
# A jump while playing (following a skip) is much quicker than a jump from pause that then plays (a start): the
# owner's laptop landed 1.3 s early following skips with the lead its starts needed. Each kind has its own lead.
SEEK_LEAD_S = 0.4
# Whoever skips takes this long to get going again (the laptop about 0.4 s, PM4K's own skip on the TV about
# 0.5 s): it says where it will be on the party's clock, not where its skip landed, or everyone following ends up
# ahead of it. Learned per device like the other leads.
SKIP_LEAD_S = 0.4
# How much of a measured error a single jump corrects (the rest waits for more jumps; one can be noisy). Jumps
# while playing and one's own skips land on keyframes on the TV (up to 2.6 s either way, owner's third
# diagnostics run): they are learned more slowly, so that noise averages out instead of pushing the lead about.
JUMP_LEARNING = 0.5
NOISY_LEARNING = 0.3
# PM4K's own skip lands on a keyframe, up to 4 s from the spot it reports. The skipper waits until it plays
# again and then says where it really is.
PM4K_LANDING_MS = 1200
# A held player away from the spot gets into position during the countdown (a jump while paused, at least this
# long before the moment) and then starts from pause like everyone, instead of jumping at the moment (where the TV
# landed on keyframes, up to 9 s off). Tried as an experiment first (owner's fourth diagnostics run): the laptop
# landed within 0.04 s and every start from there was within 0.1 s; the TV started cleanly from where it landed.
PREPOSITION_MIN_MS = 2000
PREPOSITION_CHECK_MS = 1000
# The TV lands short of the spot when it jumps while held (on the keyframe before it: 0.2 to 9 s in the owner's
# fourth diagnostics run): with this long still to go, everyone starts from where it landed instead (the others
# get into position there; the laptop lands to the millisecond), once per countdown.
ALIGN_MIN_MS = 1500
# Whoever starts a title from its beginning has played this little of it by the time the party hears: the start
# is said as 0:00, where the others open it too (the TV then needs no jump; Lucy, Dolby Vision, landed 1.8 s short).
FROM_THE_BEGINNING_S = 3.0
# One lesson moves a lead at most this far: a single far skip that buffered took the TV's lead from 0.72 to 1.63 s.
LEAD_STEP_MAX_S = 0.25
# A jump is judged once it has settled: the TV's position stands still for about a second after a jump and only
# settles by 4 s, so judging at 2 s taught it a lead 0.6 s too long.
JUMP_SETTLE_MS = 5000
PLAY_SETTLE_MS = 4000
# A held player is told to play this much before the moment, as it takes that long to get moving. Learned per
# device from where it is a moment after starting, like the jump lead; errors beyond PLAY_ERROR_MAX_S are
# something else (a stall) and teach nothing.
PLAY_LEAD_S = 0.0
PLAY_LEAD_RANGE_S = (0.0, 1.0)
PLAY_LEARNING = 0.5
PLAY_ERROR_MAX_S = 1.0
# Our own pause, jump or play comes back as a player event within this time.
ECHO_MS = 3000
# PM4K's own skip, from its pause to its play.
SKIP_MS = 5000
# PM4K has finished opening a video once it has played normally for this long.
STEADY_MS = 500
# Stopping this close to the end is finishing, which does not pause the others.
FINISH_WINDOW_S = 60
# A party moves on to a different title only in its last minutes (same as the server).
NEXT_ITEM_WINDOW_S = 300
IDLE_STATUS_MS = 60_000
# A lost connection is said only while watching along with someone, and only once it has lasted this long: a
# server restart (an update) is back within seconds and needs no word.
OFFLINE_NOTICE_MS = 30_000
# A held player never moves: everything is put right at the shared moment. One a little ahead of the party's
# spot (a follower always pauses a moment after whoever paused) keeps its frame and starts that much later,
# exactly in sync. One further off, or behind (it would start before the moment), jumps to the spot just before
# the moment, its learned jump lead early, so it starts with everyone (jump then play at once looks right on
# the P3i box; holding paused after a jump does not).
HOLD_AHEAD_S = 3.0
HOLD_BEHIND_S = 0.25
# How often the engine runs in the last moments before a shared start.
FINE_TICK_MS = 20
# A player already playing this close to where the party is, is left alone when a state is applied again.
IN_STEP_S = 0.3
# A while after every start (start, resume, rejoin, skip) the device reports exactly where it is, so the
# server can log how well the start was shared.
SYNC_CHECK_MS = 2000
# A seek event this close to where we jumped is that jump reporting back, not the viewer.
SEEK_ECHO_S = 5.0
# An invitation shown during a film stays this long.
INVITATION_NOTICE_S = 15
# Someone started a title and the party waits for this device: said for CALL_S, and again every CALL_REPEAT_S
# until this device opens it or the party moves on (for CALL_MAX_S at most). Watching something else: a card for
# CALL_VIDEO_S, less often.
CALL_S = 20
CALL_REPEAT_S = 45
CALL_VIDEO_S = 10
CALL_REPEAT_VIDEO_S = 180
CALL_MAX_S = 600
# Starting more than this late (the message arrived late) jumps to the right spot instead of starting behind.
LATE_START_MS = 250
# A countdown is only shown when there is time to read it.
COUNTDOWN_MIN_MS = 1500
# A skip goes out at once; more skips within this time (scrubbing) are sent as one, once the viewer has settled.
SEEK_SETTLE_MS = 600
# A skip or pause that would leave the party where it already is changes nothing and is not sent (it is
# almost always this device's own follow-up coming back, not the viewer).
SAME_SPOT_S = 2.0

DEFAULT_SETTINGS = {'catchup_threshold_s': 15, 'status_interval_s': 5, 'countdown_s': 5, 'notice_s': 4,
                    'notices': 'essential', 'control': 'everyone', 'diagnostics': 'off'}
# Sync diagnostics (when the admin switches them on): how far this player is from the party this long after every
# start, resume, rejoin or skip; sent in batches small enough for the server's 2 KB request limit.
DIAG_SAMPLES_MS = (250, 500, 1000, 2000, 4000, 8000)
DIAG_FLUSH_MS = 3000
DIAG_BATCH_BYTES = 1500
DIAG_BATCH_EVENTS = 40
DIAG_KEEP = 400


class SendError(Exception):
    """The server refused a request, or could not be reached. `code` says which."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def describe(item):
    """A title the way people say it: "Example Show · S2 E3" or the film's title."""
    if not item:
        return ''
    if item.get('show'):
        if item.get('season') is not None and item.get('episode') is not None:
            return '{} · S{} E{}'.format(item['show'], item['season'], item['episode'])
        return item['show']
    return item.get('title') or ''


def clock_label(seconds):
    """Minutes and seconds (hours when there are any); callers add 0.5 to round to the nearest second."""
    seconds = int(max(0, seconds or 0))
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return '{}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{}:{:02d}'.format(minutes, seconds)


def _older(version, other):
    def parts(text):
        try:
            return tuple(int(p) for p in str(text).split('.')[:3])
        except ValueError:
            return None
    mine, theirs = parts(version), parts(other)
    return bool(mine and theirs and mine < theirs)


def device_label(name):
    """A device's name inside a sentence: "laptop", "living room TV", but "PC" and "iPad" stay as they are."""
    name = name or 'other device'
    if len(name) > 1 and name[0].isupper() and name[1].islower():
        return name[0].lower() + name[1:]
    return name


def _step(change):
    """A lead moves at most LEAD_STEP_MAX_S per lesson."""
    return max(-LEAD_STEP_MAX_S, min(LEAD_STEP_MAX_S, change))


def sentence(text):
    """Text at the start of a sentence: only the first letter raised ("Your PC", not "Your pc")."""
    return text[:1].upper() + text[1:]


def names(items):
    items = [i for i in items if i]
    if len(items) <= 1:
        return ''.join(items)
    return ', '.join(items[:-1]) + ' and ' + items[-1]


class Engine:
    def __init__(self, player, screen, send, clock, version='0.0.0', log=None, jump_lead=None, on_jump_lead=None,
                 play_lead=None, on_play_lead=None, clock_info=None, seek_lead=None, on_seek_lead=None,
                 skip_lead=None, on_skip_lead=None, leave_old_party=False):
        self.version = version
        # Kodi just started: a watch party from before is left quietly instead of picked up (see on_state).
        self.leave_old_party = leave_old_party
        self.clock_info = clock_info
        self.diag_events = []
        self.diag_samples = []
        self.diag_sent = 0
        self.log = log or (lambda text: None)
        self.jump_lead = jump_lead if isinstance(jump_lead, (int, float)) else JUMP_LEAD_S
        self.on_jump_lead = on_jump_lead or (lambda lead: None)
        self.seek_lead = seek_lead if isinstance(seek_lead, (int, float)) else SEEK_LEAD_S
        self.on_seek_lead = on_seek_lead or (lambda lead: None)
        self.skip_lead = skip_lead if isinstance(skip_lead, (int, float)) else SKIP_LEAD_S
        self.on_skip_lead = on_skip_lead or (lambda lead: None)
        self.skip_check = None
        self.play_lead = play_lead if isinstance(play_lead, (int, float)) else PLAY_LEAD_S
        self.on_play_lead = on_play_lead or (lambda lead: None)
        self.jump_check = None
        self.play_check = None
        self.update_told = False
        self.cannot_told = None
        self.last_item = None
        self.player = player
        self.screen = screen
        self.send = send
        self.clock = clock
        self.view = None
        self.settings = dict(DEFAULT_SETTINGS)
        self.applied = None
        self.fresh_start = False  # a video just started: the next state is followed, whoever changed it
        self.echo = {}
        self.skip_until = 0
        self.starting = False
        self.steady_since = None
        self.item = None
        self.scheduled = None
        self.offer = None
        self.fast = False
        self.pending_invitation = None
        self.seen_invitations = set()
        self.last_status = 0
        self.dnd = False
        self.online = True
        self.jumped_to = None
        self.pending_seek = None
        self.last_seek_sent = -SEEK_SETTLE_MS
        self.sync_check = None
        self.calling = None
        self.awaiting_seq = None
        self.pm4k_skip = None
        self.offline_since = None
        self.offline_told = False
        self.paused_alone = False
        self.positioned = None
        self.position_check = None
        self.aligned_for = None
        self.screen_countdown = None

    # Reading the party -----------------------------------------------------

    def party(self):
        return (self.view or {}).get('party')

    def _on_party_item(self, party):
        return bool(self.item and party and party.get('item') and party['item']['key'] == self.item['key'])

    def _expected(self, party, now):
        playback = party['playback']
        if playback['state'] == 'playing':
            return playback['position'] + max(0, now - playback['at']) / 1000.0
        return playback['position']

    def _near_end(self, party, now):
        duration = (party.get('item') or {}).get('duration')
        return bool(duration) and self._expected(party, now) >= duration - NEXT_ITEM_WINDOW_S

    def _may_control(self, party):
        return self.settings.get('control') != 'host' or party.get('i_am_host')

    def _my_person(self):
        return ((self.view or {}).get('me') or {}).get('person')

    def _label(self, member):
        if member.get('person') == self._my_person():
            return 'your ' + device_label(member.get('device_name'))
        return member.get('name') or 'Someone'

    def _actor(self, playback):
        """Who did it, at the start of a sentence: "You", "Your laptop" or the person's name."""
        if playback.get('by_me'):
            return 'You'
        if playback.get('by_person') and playback.get('by_person') == self._my_person() and playback.get('by_device'):
            return 'Your ' + device_label(playback['by_device'])
        return playback.get('by_name') or 'Someone'

    def _own_device(self, playback):
        return bool(playback.get('by_person') and playback.get('by_person') == self._my_person())

    def _others(self, party):
        return names([self._label(m) for m in party.get('members', []) if not m.get('me')]) or 'the others'

    # Diagnostics -------------------------------------------------------------

    def _diagnosing(self):
        return self.settings.get('diagnostics') == 'on'

    def _diag(self, kind, **data):
        if not self._diagnosing():
            return
        event = {'k': kind, 't': int(self.clock())}
        for key, value in data.items():
            event[key] = round(value, 3) if isinstance(value, float) else value
        self.diag_events.append(event)
        del self.diag_events[:-DIAG_KEEP]

    def _sample_after(self, seq):
        """Measure how far this player is from the party at fixed moments after a start."""
        if self._diagnosing() and isinstance(seq, int):
            now = self.clock()
            self.diag_samples = [(now + delay, seq, delay) for delay in DIAG_SAMPLES_MS]

    def _take_samples(self, now):
        due = [s for s in self.diag_samples if s[0] <= now]
        if not due:
            return
        self.diag_samples = [s for s in self.diag_samples if s[0] > now]
        party = self.party()
        for _, seq, delay in due:
            if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                    or not self._on_party_item(party)):
                self.diag_samples = []
                return
            if self.player.paused():
                continue  # PM4K's own skip pauses for a moment: this sample only
            position = self.player.position()
            if position is not None:
                self._diag('sm', seq=seq, d=delay, err=int(round((position - self._expected(party, now)) * 1000)))

    def _flush_diag(self, now):
        if not self.diag_events or now - self.diag_sent < DIAG_FLUSH_MS or not self.online:
            return
        self.diag_sent = now
        batch = []
        if self.clock_info:
            batch.append(dict(self.clock_info(), k='ck', t=int(now)))
        size = 0
        while self.diag_events and len(batch) < DIAG_BATCH_EVENTS:
            size += len(json.dumps(self.diag_events[0], separators=(',', ':'))) + 1
            if size > DIAG_BATCH_BYTES and batch:
                break
            batch.append(self.diag_events.pop(0))
        try:
            self.send({'type': 'diag', 'events': batch})
        except SendError:
            pass  # diagnostics are best effort: a lost batch is not sent again

    # Player commands, remembered so their echo is not taken for the viewer ---

    def _expect(self, name):
        self.echo[name] = self.clock() + ECHO_MS

    def _consume(self, name, now, position=None):
        deadline = self.echo.get(name)
        if deadline is None or deadline < now:
            return False
        if name == 'seek':
            # One jump can report more than one seek (a long one especially): every seek that lands near where
            # we jumped is ours; one somewhere else is the viewer skipping.
            if position is not None and self.jumped_to is not None and abs(position - self.jumped_to) > SEEK_ECHO_S:
                return False
            return True
        del self.echo[name]
        return True

    def _pause(self):
        if not self.player.paused():
            self._expect('paused')
            self.player.pause()
            self.log('pause at {}'.format(self.player.position()))

    def _play(self):
        if self.player.paused():
            self._expect('resumed')
            self.player.play()
            self.log('play at {}'.format(self.player.position()))

    def _lead_for_jump(self):
        """How long a jump takes here before the picture moves: from pause (then play) or while playing."""
        return self.jump_lead if self.player.paused() else self.seek_lead

    def _jump_to(self, spot):
        """Jump so the picture moves on from where the party is: `spot` is where it is now; the jump aims this
        device's own lead further, since the picture only moves that long after the jump starts."""
        # A playing player jumps while playing: pausing first would show up in Plex as a pause (and in anything
        # that listens to it, such as lights), and gives one more event to tell apart from the viewer.
        was_paused = self.player.paused()
        lead = self._lead_for_jump()
        seconds = spot + lead
        for name in ('paused', 'seek', 'resumed'):
            self._expect(name)  # whatever this player reports around the jump is ours
        self.jumped_to = max(0.0, seconds)
        self.player.jump(max(0.0, seconds))
        if was_paused:
            self.player.play()
        self.log('jump to {:.3f}{} (lead {:.2f})'.format(seconds, ' and play' if was_paused else '', lead))
        self._diag('jp', to=float(seconds), lead=lead, pz=was_paused)
        party = self.party()
        if party:
            # Once it has settled, see how far behind or ahead the jump landed and learn from it.
            self.jump_check = (party['playback']['seq'], self.clock() + JUMP_SETTLE_MS, was_paused)

    def _learn_jump(self, now):
        seq, from_pause, self.jump_check = self.jump_check[0], self.jump_check[2], None
        party = self.party()
        if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                or not self._on_party_item(party) or self.player.paused()):
            return
        position = self.player.position()
        if position is None:
            return
        error = position - self._expected(party, now)
        if abs(error) > 5:
            return  # something else happened meanwhile (a skip, a stall): not a measure of the jump
        low, high = JUMP_LEAD_RANGE_S
        before = self.jump_lead if from_pause else self.seek_lead
        rate = JUMP_LEARNING if from_pause else NOISY_LEARNING
        lead = min(high, max(low, before - _step(rate * error)))
        self.log('{} landed {:+.3f} s from the party; lead {:.2f} -> {:.2f}'.format(
            'jump from pause' if from_pause else 'jump while playing', error, before, lead))
        self._diag('lj' if from_pause else 'ls', err=float(error), lead=float(lead))
        if abs(lead - before) < 0.02:
            return
        if from_pause:
            self.jump_lead = lead
            self.on_jump_lead(round(lead, 3))
        else:
            self.seek_lead = lead
            self.on_seek_lead(round(lead, 3))

    def _learn_play(self, now):
        seq, self.play_check = self.play_check[0], None
        party = self.party()
        if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                or not self._on_party_item(party) or self.player.paused()):
            return
        position = self.player.position()
        if position is None:
            return
        error = position - self._expected(party, now)
        if abs(error) > PLAY_ERROR_MAX_S:
            return
        low, high = PLAY_LEAD_RANGE_S
        lead = min(high, max(low, self.play_lead - _step(PLAY_LEARNING * error)))
        self.log('start from hold landed {:+.3f} s from the party; play lead {:.2f} -> {:.2f}'.format(
            error, self.play_lead, lead))
        self._diag('lp', err=float(error), lead=float(lead))
        if abs(lead - self.play_lead) >= 0.01:
            self.play_lead = lead
            self.on_play_lead(round(lead, 3))

    def wake_in_ms(self):
        """When the engine next needs to run, if sooner than its usual pace (for precise starts)."""
        if self.scheduled:
            # The earliest this device may act: a jump, or playing from hold a little behind the spot.
            lead = max(self.jump_lead, self.play_lead + HOLD_BEHIND_S)
            left = self.scheduled[0] - lead * 1000 - self.clock()
            return max(FINE_TICK_MS, min(left, 250)) if left > 250 else FINE_TICK_MS
        return None

    # Talking to the server -------------------------------------------------

    def _send(self, payload):
        if not self.online:
            # Nothing is queued while the server is away: on return, this device follows the party.
            return None
        try:
            result = self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)
            else:
                self._refused(error.code)
            return None
        return result

    def _tell(self, text, extra=False, person=None, seconds=None):
        """A notice. Extra ones (pressed play, back in sync, reachable again) only show if the admin chose All."""
        if extra and self.settings.get('notices') != 'all':
            return
        how = self.screen.notice(text, person=person, seconds=seconds)
        self._diag('nt', how=how, txt=text)

    def set_online(self, online):
        """Told by the connection (or found out by a failed send). Said only while watching along with someone,
        and a loss only once it has lasted (see _check_offline). Nothing is re-applied on return: playback is not
        moved for a blip, and a change meanwhile comes back with a new number anyway."""
        if online == self.online:
            return
        self.online = online
        if online:
            if self.offline_told:
                self._tell('Connection restored. Back in sync with the watch party.', extra=True)
            self.offline_since, self.offline_told = None, False
        else:
            self.offline_since = self.clock()

    def _check_offline(self, now):
        party = self.party()
        if (self.offline_since is not None and not self.offline_told and now - self.offline_since >= OFFLINE_NOTICE_MS
                and party and self._watching_together(party)):
            self.offline_told = True
            self._tell('Connection to Watch Party lost. Playback continues on this device.')

    def _watching_together(self, party):
        """This device is on the party's title and someone else is on it too."""
        return self._on_party_item(party) and not self._alone_on_title(party)

    def needs_quick_pace(self):
        """Whether the service loop should run four times a second: only while something is under way here
        or while watching along with someone. Alone (or in no party) a video plays undisturbed."""
        if (self.scheduled or self.starting or self.pm4k_skip or self.pending_seek or self.diag_samples
                or self.jump_check or self.play_check or self.skip_check or self.position_check):
            return True
        party = self.party()
        return bool(party and self.item and self._watching_together(party))

    def _refused(self, code):
        party = self.party()
        if code == 'no_invitation':
            self._tell('That invitation is no longer open. Ask for a new one.')
        elif code == 'host_only' and party:
            self._tell('Only {} can control playback in this watch party.'.format(party.get('host_name') or 'the host'))
        elif code in ('party_busy', 'other_item') and party and party.get('item'):
            if party['playback']['state'] == 'waiting':
                self._tell('The watch party is waiting for you on {}. This video is not synchronised.'.format(
                    describe(party['item'])))
            else:
                self._tell('The watch party is playing {}. This video is not synchronised.'.format(
                    describe(party['item'])))

    def _send_playback(self, kind, position, item=None):
        result = self._send({'type': 'playback', 'kind': kind, 'item': item or self.item,
                             'position': round(max(0.0, position or 0.0), 3)})
        if result is not None:
            self._clear_offer()
            if isinstance(result.get('seq'), int):
                # Until the party's state carries this change, the distance to it means nothing: right after
                # a skip this player is already there and the party not yet (it read as "28 seconds ahead").
                self.awaiting_seq = (result.get('party'), result['seq'])
        return result

    def _started(self):
        """Playback just started for the party: report how well in a moment."""
        party = self.party()
        if party:
            self.sync_check = (party['playback']['seq'], self.clock() + SYNC_CHECK_MS)
            self._sample_after(party['playback']['seq'])

    def _send_status(self, state=None, check=None):
        now = self.clock()
        self.last_status = now
        if state is None:
            state = 'idle' if not self.item else ('paused' if self.player.paused() else 'playing')
        payload = {'type': 'status', 'state': state}
        if state != 'idle':
            payload.update(item=self.item, position=round(self.player.position() or 0.0, 3))
            if check is not None:
                payload.update(sampled_at=now, check=check)
        if not self.online:
            return
        try:
            self.send(payload)
        except SendError as error:
            if error.code == 'offline':
                self.set_online(False)

    def respond(self, party_id, accept):
        """The viewer answered an invitation. A refusal is said (it used to vanish without a word)."""
        result = self._send({'type': 'respond', 'party': party_id, 'accept': bool(accept)})
        self.log('answered {}: {}'.format('join' if accept else 'not now', 'ok' if result is not None else 'not done'))

    def set_do_not_disturb(self, value):
        self.dnd = bool(value)

    # What the player reports -----------------------------------------------

    def on_local(self, name, position=None, target=None, seeking=False, speed=None):
        now = self.clock()
        self.log('event {} at {}{}{}'.format(name, position, ' target {}'.format(target) if target is not None else '',
                                            ' (PM4K skip)' if seeking else ''))
        self._diag('ev', n=name, pos=position, tg=target, pm=bool(seeking), sp=speed)
        if name == 'started':
            self.starting, self.steady_since, self.item, self.fast = True, None, None, False
            # A new start of a video, even of the same title (opened again, played from the beginning): once
            # steady, it follows the party again instead of counting the party's state as already applied, nor
            # taking the party's last change for its own and itself for already there.
            self.applied = None
            self.fresh_start = True
            self.skip_until = 0
            self._forget_video_work()
            self._clear_offer()
            return
        if name in ('stopped', 'ended'):
            self._stopped(name == 'ended', position)
            return
        if self.starting:
            return
        if name == 'speed':
            if speed == 1:
                if self.fast:
                    self.fast = False
                    self._user_seek(position)
            else:
                self.fast = True
            return
        if name == 'paused' and seeking:
            # PM4K's own skip (its flag is up): never our echo, even if one of ours is expected.
            self.skip_until = now + SKIP_MS
            return
        if self._consume(name, now, target if target is not None else position):
            return
        self.log('taken as the viewer: {}'.format(name))
        if name == 'resumed' and self.scheduled:
            self._pause()
            if self.skip_until >= now:
                # PM4K's own skip (pause, jump, play) during a countdown: not a press. Held again; the skip itself
                # moves the countdown's spot.
                self.skip_until = 0
                return
            # A press during a countdown (Kodi's pause is a toggle, so play and pause look the same) stops it.
            self._cancel_countdown()
            return
        if name == 'paused':
            self._user_pause(position)
        elif name == 'resumed':
            if self.skip_until >= now:
                self.skip_until = 0
                if self.pm4k_skip:
                    self.pm4k_skip['resumed_at'] = now
                return
            self._user_resume(position)
        elif name == 'seek' and not self.fast:
            spot = target if target is not None else position
            party = self.party()
            if (seeking and party and party['playback']['state'] == 'playing' and party['playback']['at'] <= now
                    and not self.scheduled):
                # PM4K's own skip while the party plays: said once it plays again, from where it really landed.
                self.pm4k_skip = {'target': spot, 'since': now, 'resumed_at': None}
                return
            self._user_seek(spot)

    def _cancel_countdown(self):
        at, position = self.scheduled
        self.scheduled = None
        self.screen.clear_countdown()
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._refused('host_only')
            return
        if self._send_playback('pause', position) is not None:
            self.screen.hold(self._paused_text(party, 'You paused'))

    def _user_pause(self, position):
        party = self.party()
        if not party and self.pending_invitation:
            invitation, self.pending_invitation = self.pending_invitation, None
            self.screen.ask(invitation)
            return
        if not self._on_party_item(party):
            return
        if self.offer:
            self._catch_up(party)
            return
        if not self._may_control(party):
            self._play()
            self._refused('host_only')
            return
        if party['playback']['state'] == 'paused':
            self.log('not sent: the party is already paused')
            return
        sent = self._send_playback('pause', position) is not None
        # Not sent (the connection is away): paused here only, while the party plays on.
        self.paused_alone = not sent
        if sent and not self._alone_on_title(party):
            self.screen.hold(self._paused_text(party, 'You paused'))

    @staticmethod
    def _alone_in_party(party):
        """Nobody else is in the party: nothing to wait for or start with, so the player is left alone. (As the server
        decides it: someone offline a while is still in the party and may be watching.)"""
        return not any(not m.get('me') for m in party.get('members', []))

    def _alone_on_title(self, party):
        """Nobody else in the party is on this title right now: pausing and playing are just this player's."""
        return not any(m.get('ready') and m.get('online') for m in party.get('members', []) if not m.get('me'))

    def _user_resume(self, position):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            self._pause()
            self._refused('host_only')
            return
        self.screen.clear_hold()
        playback = party['playback']
        paused_alone, self.paused_alone = self.paused_alone, False
        if paused_alone and playback['state'] == 'playing' and playback['at'] <= self.clock():
            # Paused here only (the connection was away) while the party played on: back into it, the others are
            # not moved.
            self._jump_to(self._expected(party, self.clock()))
            return
        if self._alone_on_title(party):
            # Nobody to start with: it just plays; the party follows (the server starts it from here at once).
            self._send_playback('resume', position)
            return
        # Everyone starts together a moment from now, this player included, so hold it until then.
        self._pause()
        if self._send_playback('resume', position) is None:
            self._play()

    def _send_landed_skip(self, now):
        """PM4K's skip, said once it plays again (or, should it not, where it was aimed)."""
        skip = self.pm4k_skip
        if skip['resumed_at'] is not None and now - skip['resumed_at'] >= PM4K_LANDING_MS:
            self.pm4k_skip = None
            here = None if self.player.paused() else self.player.position()
            self.log('skip aimed at {}, landed at {}'.format(skip['target'], here))
            self._diag('pk', aim=float(skip['target']), at=here)
            self._user_seek(here if here is not None else skip['target'], landed=here is not None)
        elif now - skip['since'] > SKIP_MS:
            self.pm4k_skip = None
            self._user_seek(skip['target'])

    def _user_seek(self, target, landed=False):
        party = self.party()
        if not self._on_party_item(party):
            return
        if not self._may_control(party):
            if party['playback']['state'] == 'playing':
                self._jump_to(self._expected(party, self.clock()))
            self._refused('host_only')
            return
        now = self.clock()
        playback = party['playback']
        where = self._expected(party, now) if playback['state'] == 'playing' else playback['position']
        if target is not None and abs(target - where) < SAME_SPOT_S:
            self.log('not sent: the skip lands where the party already is')
            return
        if (not landed and target is not None and target < self.skip_lead and playback['state'] == 'playing'
                and (playback.get('at') or 0) <= now and not self.player.paused()):
            # Back to the very start: said a skip's time early, the spot would be before 0:00 (cut to 0:00, this
            # player then ran that far behind everyone). Said once it plays from there, like PM4K's skips.
            self.pm4k_skip = {'target': target, 'since': now, 'resumed_at': now}
            return
        if landed:
            self._send_seek(target, landed=True)  # where this player already plays: nothing to settle
        elif self.pending_seek is None and now - self.last_seek_sent >= SEEK_SETTLE_MS:
            self._send_seek(target)  # the first skip goes out at once, so the others start following now
        else:
            # More skips in a row (scrubbing): sent once the viewer settles, where they ended up.
            self.pending_seek = (target, now)

    def _send_settled_seek(self, now):
        target, at = self.pending_seek
        if now - at < SEEK_SETTLE_MS:
            return
        self.pending_seek = None
        if self._on_party_item(self.party()):
            self._send_seek(target)

    def _send_seek(self, target, landed=False):
        self.last_seek_sent = self.clock()
        # Where this player is now, not where the skip landed: it may have played on meanwhile.
        here = self.player.position()
        spot = (here if here is not None and not self.player.paused() else target) or 0.0
        party = self.party()
        if landed:
            spot = target  # read while playing, where it really is: nothing to allow for
        elif party and party['playback']['state'] == 'playing' and (party['playback'].get('at') or 0) <= self.clock():
            # Its picture only moves on once the skip has landed: say where it will be on the party's clock.
            # (While the party is paused or counting down nothing moves, so the spot is the spot.)
            spot = max(0.0, spot - self.skip_lead)
        result = self._send_playback('seek', spot)
        if result and isinstance(result.get('seq'), int):
            # The skipper reports and learns too (the party's new number comes back in the answer).
            self.sync_check = (result['seq'], self.clock() + SYNC_CHECK_MS)
            if not landed:
                self.skip_check = (result['seq'], self.clock() + JUMP_SETTLE_MS)
            self._sample_after(result['seq'])

    def _learn_skip(self, now):
        seq, self.skip_check = self.skip_check[0], None
        party = self.party()
        if (not party or party['playback']['seq'] != seq or party['playback']['state'] != 'playing'
                or not self._on_party_item(party) or self.player.paused()):
            return
        position = self.player.position()
        if position is None:
            return
        error = position - self._expected(party, now)
        if abs(error) > 2:
            return  # something else happened meanwhile: not a measure of the skip
        lead = min(JUMP_LEAD_RANGE_S[1], max(0.0, self.skip_lead - _step(NOISY_LEARNING * error)))
        self.log('own skip landed {:+.3f} s from the party; skip lead {:.2f} -> {:.2f}'.format(
            error, self.skip_lead, lead))
        self._diag('lk', err=float(error), lead=float(lead))
        if abs(lead - self.skip_lead) >= 0.02:
            self.skip_lead = lead
            self.on_skip_lead(round(lead, 3))

    def _forget_video_work(self):
        """What belonged to the video that was playing: a skip still to be said, checks still to be made."""
        self.pm4k_skip = self.pending_seek = None
        self.jump_check = self.play_check = self.skip_check = self.position_check = None
        self.diag_samples = []

    def _stopped(self, ended, position):
        was, self.item = self.item, None
        self._forget_video_work()
        self.last_item = was or self.last_item
        self.starting, self.scheduled, self.pending_seek, self.sync_check = False, None, None, None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        party = self.party()
        if party and was and party.get('item') and party['item']['key'] == was['key']:
            duration = was.get('duration') or 0
            finished = ended or (duration and (position or 0) >= duration - FINISH_WINDOW_S)
            if not finished:
                self._send_playback('stop', position, item=was)
        self._send_status('idle')

    # Housekeeping, about four times a second ---------------------------------

    def tick(self):
        now = self.clock()
        for name in [n for n, deadline in self.echo.items() if deadline < now]:
            del self.echo[name]
        if self.starting:
            self._check_steady(now)
        if self.scheduled:
            self._run_scheduled(now)
        if self.pending_seek:
            self._send_settled_seek(now)
        if self.pm4k_skip:
            self._send_landed_skip(now)
        if self.calling:
            self._remind(now)
        if self.offline_since is not None:
            self._check_offline(now)
        if self.diag_samples:
            self._take_samples(now)
        self._flush_diag(now)
        if self.position_check and now >= self.position_check[1]:
            self._check_position(now)
        if self.jump_check and now >= self.jump_check[1]:
            self._learn_jump(now)
        if self.play_check and now >= self.play_check[1]:
            self._learn_play(now)
        if self.skip_check and now >= self.skip_check[1]:
            self._learn_skip(now)
        if self.sync_check and now >= self.sync_check[1]:
            seq, self.sync_check = self.sync_check[0], None
            if self.item and not self.player.paused():
                self._send_status(check=seq)
        party = self.party()
        # Reported often only while watching along with someone; alone, now and then (and at every change).
        together = bool(self.item and party and self._watching_together(party))
        interval = self.settings['status_interval_s'] * 1000 if together else IDLE_STATUS_MS
        if now - self.last_status >= interval:
            self._send_status()
        party = self.party()
        if party and self.item and not self.starting:
            self._check_distance(party, now)

    def _preposition(self, now, at, position):
        """Get into position while held, once per scheduled start."""
        if self.positioned == (at, position) or not self.player.paused():
            return
        self.positioned = (at, position)
        mine = self.player.position()
        if mine is None or -HOLD_BEHIND_S <= mine - position <= HOLD_AHEAD_S or at - now < PREPOSITION_MIN_MS:
            return
        self._expect('seek')  # its own jump reports back as a seek
        self.jumped_to = position
        self.player.jump(position)
        self.log('into position while held: {:.3f} -> {:.3f}, {} ms before the moment'.format(mine, position, at - now))
        party = self.party()
        seq = party['playback']['seq'] if party else None
        self._diag('pp', seq=seq, frm=float(mine), to=float(position), early=int(at - now))
        self.position_check = (seq, now + PREPOSITION_CHECK_MS, position)

    def _check_position(self, now):
        seq, _, aimed = self.position_check
        self.position_check = None
        landed = self.player.position() if self.player.paused() else None
        self._diag('pl', seq=seq, off=None if landed is None else float(landed - aimed))
        if landed is not None and self.scheduled:
            self.log('into position: landed {:+.3f} s from the spot'.format(landed - aimed))
            # Against where everyone starts now, not where this player aimed: another player may have moved the
            # start back meanwhile (to where it landed), and this one may well be ahead of that.
            at, spot = self.scheduled
            if (landed - spot < -HOLD_BEHIND_S and at - now >= ALIGN_MIN_MS and self.aligned_for != at
                    and self._send_playback('align', landed) is not None):
                # Landed short: everyone starts from here instead (the new spot comes back as the party's state).
                self.aligned_for = at
                self._diag('al', seq=seq, to=float(landed))
                return
            start = self._own_start(*self.scheduled)
            if self.screen_countdown and abs(start - self.screen_countdown[0]) > 300:
                # Landed a little ahead (a keyframe): it starts that much later, and its countdown says so.
                self.screen_countdown = (start, self.screen_countdown[1])
                self.screen.countdown(*self.screen_countdown)

    def _run_scheduled(self, now):
        at, position = self.scheduled
        self._preposition(now, at, position)
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and -HOLD_BEHIND_S <= mine - position <= HOLD_AHEAD_S:
            # Already (nearly) there: start a little earlier or later instead of jumping, and this device's own
            # play lead early, as it takes that long to get moving.
            start = at + (mine - position) * 1000 - self.play_lead * 1000
            if now < start:
                return
            self.scheduled = None
            if not self.item:
                return
            self.log('start: {} ms after the moment, {:.3f} from the spot'.format(now - at, mine - position))
            party = self.party()
            self._diag('go', seq=party['playback']['seq'] if party else None,
                       how='late' if now - start > LATE_START_MS else 'hold', late=int(now - start),
                       ahead=float(mine - position), pl=self.play_lead)
            if now - start > LATE_START_MS:
                self._jump_to(position + (now - at) / 1000.0)
            else:
                self._play()
                party = self.party()
                if party:
                    self.play_check = (party['playback']['seq'], now + PLAY_SETTLE_MS)
            self._started()
            return
        if now < at - self.jump_lead * 1000:
            return
        self.scheduled = None
        if self.item:
            self.log('start by jumping: {} ms to the moment'.format(at - now))
            party = self.party()
            self._diag('go', seq=party['playback']['seq'] if party else None, how='jump', early=int(at - now),
                       jl=self.jump_lead)
            self._started()
            # Playback resumes about jump_lead after the jump starts, at at + (now - at) + lead. Jumping early
            # makes (now - at) negative and cancels the lead, so the picture moves on from `position` right at `at`.
            self._jump_to(position + (now - at) / 1000.0)

    def _own_start(self, at, position):
        """When this held player will start for the shared moment `at`: later by however far ahead it is held."""
        mine = self.player.position() if self.player.paused() else None
        if mine is not None and 0 < mine - position <= HOLD_AHEAD_S:
            return at + int((mine - position) * 1000)
        return at

    def _check_steady(self, now):
        if not self.player.video() or self.player.pm4k_busy() or self.player.paused():
            self.steady_since = None
            return
        if self.steady_since is None:
            self.steady_since = now
            return
        if now - self.steady_since >= STEADY_MS:
            self.starting = False
            self.item = self.player.item()
            self._ready()
            self.fresh_start = False  # followed the party just now (if it is on its title); later states as usual

    def _ready(self):
        self._send_status()
        party = self.party()
        if not party:
            return
        if not self.item:
            self._tell('This video cannot be synchronised: it is not playing directly from Plex.')
            return
        if self._on_party_item(party) and not self._alone_in_party(party):
            # Opened what the party is on: follow wherever it is now (paused, waiting or counting down holds this
            # player at once, before the server has even heard of it). Alone in the party there is nobody to
            # follow: the server takes this player's spot instead, and the player is left alone.
            self._follow(party)
        self._join_playback(party)

    def _join_playback(self, party):
        """Tell the server this device is on its title. The next update says what to do."""
        playback = party['playback']
        if (not self._on_party_item(party) and playback['state'] == 'playing'
                and not self._near_end(party, self.clock())):
            self._refused('party_busy')
            return
        joins_playing = self._on_party_item(party) and playback['state'] == 'playing' and playback['at'] <= self.clock()
        alone = self._alone_in_party(party)
        here = self.player.position() or 0.0
        if here < FROM_THE_BEGINNING_S and not alone:
            here = 0.0  # opened from the beginning: said as the beginning, where everyone else opens it too
        if self._send_playback('start', here) is not None and not joins_playing and not alone:
            # The party will wait or count down on this title: hold now instead of playing on until it says so.
            # (Alone in the party it plays on untouched: the server starts the party from where it is.)
            self._pause()

    def _check_distance(self, party, now):
        playback = party['playback']
        if self.awaiting_seq and self.awaiting_seq[0] == party['id'] and playback['seq'] < self.awaiting_seq[1]:
            return  # this device's own change is on its way back
        self.awaiting_seq = None
        if self._alone_on_title(party):
            # Nobody else on the title: nobody to be behind or ahead of (a stall while alone is the player's own).
            self._clear_offer()
            return
        if (playback['state'] != 'playing' or playback['at'] > now or not self._on_party_item(party)
                or self.player.paused() or any(k != 'seek' for k in self.echo) or self.skip_until >= now
                or self.scheduled or self.pending_seek or self.fast or self.pm4k_skip):
            return
        position = self.player.position()
        if position is None:
            return
        distance = position - self._expected(party, now)
        threshold = self.settings['catchup_threshold_s']
        if distance < -threshold:
            wanted = 'behind'
        elif distance > threshold:
            wanted = 'ahead'
        elif abs(distance) < threshold / 2.0:
            wanted = None
        else:
            wanted = self.offer
        if wanted == self.offer:
            return
        self.offer = wanted
        if wanted == 'behind':
            self.screen.offer('You are {} seconds behind {}. Press pause to resync.'.format(
                int(-distance), self._others(party)))
        elif wanted == 'ahead':
            self.screen.offer('You are {} seconds ahead of {}. Press pause to resync.'.format(
                int(distance), self._others(party)))
        else:
            self.screen.clear_offer()

    def _catch_up(self, party):
        self._clear_offer()
        self._jump_to(self._expected(party, self.clock()))
        self._tell('Back in sync with {}.'.format(self._others(party)), extra=True)

    def _clear_offer(self):
        if self.offer:
            self.offer = None
            self.screen.clear_offer()

    # What the server reports -----------------------------------------------

    def on_state(self, view):
        previous, self.view = self.view, view
        self.settings.update({k: v for k, v in (view.get('settings') or {}).items() if k in DEFAULT_SETTINGS})
        if previous is None and self.leave_old_party:
            # Kodi just started: invitations already open are in the menu; asking them now would put a question
            # over whatever is starting (PM4K opening at boot, for one).
            self.seen_invitations.update((i['party'], i.get('at')) for i in view.get('invitations', []))
        if self.leave_old_party:
            if not view.get('party'):
                self.leave_old_party = False
            elif self._quietly_leave(view):
                return
        self._invitations(view)
        minimum = (view.get('addon') or {}).get('minimum')
        if minimum and not self.update_told and _older(self.version, minimum):
            self.update_told = True
            self._tell('A Watch Party update is required. Open Watch Party and choose Check for updates.')
        party, before = view.get('party'), (previous or {}).get('party')
        if before and not party:
            self._party_gone(before, view.get('last_end'))
        elif party and (not before or before['id'] != party['id']):
            self._joined(party, still=previous is None)
        elif party:
            self._membership(before, party)
        if party:
            self._follow(party)

    def left_for_standby(self):
        """Kodi is going to standby and has said goodbye: the party is forgotten without a word. Should the goodbye
        not have arrived, the party is left quietly once the device is back, as after Kodi starts."""
        self.leave_old_party = True
        self.calling = None
        if self.view and self.view.get('party'):
            self.scheduled = None
            self.screen.clear_countdown()
            self.screen.clear_hold()
            self._clear_offer()
            self.view = dict(self.view, party=None)

    def _quietly_leave(self, view):
        """Kodi just started and this device is still in a watch party from before: leave it without a word.
        True while that party is to be left (nothing of it is shown or followed)."""
        party = view['party']
        try:
            self.send({'type': 'leave'})
        except SendError as error:
            if error.code != 'not_in_party':
                self.log('watch party from before Kodi started not left yet: {}'.format(error.code))
                self.view = dict(view, party=None)
                return True
        self.leave_old_party = False
        self.log('left the watch party from before Kodi started ({})'.format(party['id'][:6]))
        self.view = dict(view, party=None)
        return True

    def _invitations(self, view):
        current = {i['party'] for i in view.get('invitations', [])}
        if self.pending_invitation and self.pending_invitation['party'] not in current:
            self.pending_invitation = None
        for invitation in view.get('invitations', []):
            # By party and time: inviting again (after "Not now") is a new invitation and is asked again.
            key = (invitation['party'], invitation.get('at'))
            if key in self.seen_invitations or invitation.get('declined'):
                continue
            self.seen_invitations.add(key)
            self.log('invitation: do not disturb is on, not shown' if self.dnd else
                     'invitation: {}'.format('told during playback' if self.player.video() and not self.player.paused()
                                             else 'asked'))
            if self.dnd:
                continue
            if invitation.get('from_me'):
                text = 'Your {} invited this device to a watch party.'.format(device_label(invitation.get('from_device')))
            else:
                text = '{} invited you to a watch party.'.format(invitation.get('from') or 'Someone')
            if self.player.video() and not self.player.paused():
                # Long enough to read and act on during a film (a short notice was gone before anyone could).
                if view.get('party'):
                    self._tell(text + ' Open Watch Party to answer.', seconds=INVITATION_NOTICE_S)
                else:
                    self.pending_invitation = invitation
                    self._tell(text + ' Press pause to answer.', seconds=INVITATION_NOTICE_S)
            else:
                self.screen.ask(invitation)

    def _party_gone(self, before, end):
        self.scheduled = None
        self.screen.clear_countdown()
        self.screen.clear_hold()
        self._clear_offer()
        end = end if end and end.get('party') == before.get('id') else {}
        reason = end.get('reason')
        if reason == 'left':
            self._tell('You left the watch party.')
        elif reason == 'ended' and end.get('by_me'):
            self._tell('You ended the watch party.')
        elif reason == 'ended' and end.get('by_name'):
            self._tell('{} ended the watch party.'.format(end['by_name']))
        elif reason == 'idle':
            self._tell('The watch party ended because nothing was played for a while.')
        elif reason == 'gone':
            self._tell('This device was out of reach for a while and is no longer in the watch party.')
        else:
            self._tell('The watch party has ended.')

    def _host_words(self, party):
        """Whose watch party this is: "Alex's watch party", or "the watch party on your laptop"."""
        host = next((m for m in party.get('members', []) if m.get('host')), None)
        if host and host.get('person') == self._my_person():
            return 'the watch party on your ' + device_label(host.get('device_name'))
        name = (host or {}).get('name') or party.get('host_name')
        return "{}'s watch party".format(name) if name else 'the watch party'

    def _joined(self, party, still=False):
        if still:
            # Kodi (or Watch Party) just started and this device is still in a party.
            self._tell('You are in {}.'.format(self._host_words(party)))
        elif not (party.get('i_am_host') and len(party.get('members', [])) == 1):
            # Starting one is said by the menu, together with who was invited.
            self._tell('You joined {}.'.format(self._host_words(party)))
        if self.item and not self.starting:
            self._join_playback(party)

    def _membership(self, before, party):
        def key(member):
            return (member.get('person'), member.get('device_name'))
        old = {key(m) for m in before.get('members', [])}
        new = {key(m) for m in party.get('members', [])}
        was_online = {key(m): m.get('online') for m in before.get('members', [])}
        for member in party.get('members', []):
            if member.get('me'):
                continue
            name = sentence(self._label(member))
            if key(member) not in old:
                self._tell('{} joined the watch party.'.format(name))
            elif was_online.get(key(member)) and not member.get('online'):
                self._tell('{} lost connection.'.format(name))
            elif was_online.get(key(member)) is False and member.get('online'):
                self._tell('{} reconnected.'.format(name), extra=True)
        for member in before.get('members', []):
            if key(member) not in new and not member.get('me'):
                self._tell('{} left the watch party.'.format(sentence(self._label(member))))

    def _follow(self, party):
        playback = party['playback']
        item_key = (party.get('item') or {}).get('key')
        if party.get('cannot_watch') and item_key and self.cannot_told != item_key and self._on_party_item(party):
            self.cannot_told = item_key
            self._tell('{} does not have access to this title.'.format(names(party['cannot_watch'])))
        # A state is applied once per title this device plays, so opening the party's title
        # after a change still brings this player to where the party is.
        key = (party['id'], playback['seq'], (self.item or {}).get('key'))
        if key != self.applied:
            self.applied = key
            self._apply(party, playback)
        elif playback['state'] == 'waiting' and self._on_party_item(party):
            self.screen.hold(self._waiting_text(party), until_cleared=True)

    def _paused_text(self, party, who, playback=None):
        """Who paused, and nothing else ("You paused · with your laptop" read as if the laptop had paused)."""
        return who

    def _starting_text(self, party, by):
        item = party['item']
        if party.get('can_watch') is False:
            return '{} started a title you do not have access to. You will rejoin when the watch party moves on.'.format(by)
        last = self.last_item or {}
        if last.get('show') and last.get('show') == item.get('show') and last.get('key') != item.get('key'):
            return '{} moved on to {}. Open it in Plex to continue watching together.'.format(
                by, 'S{} E{}'.format(item.get('season'), item.get('episode')) if item.get('episode') is not None
                else describe(item))
        return '{} is starting {}. Open it in Plex to watch together.'.format(by, describe(item))

    def _say_call(self, text, person):
        """Kodi's notification outside video, a card during another video. Returns (shown for, say again after)."""
        if self.player.video():
            self._tell(text, person=person, seconds=CALL_VIDEO_S)
            return CALL_VIDEO_S, CALL_REPEAT_VIDEO_S
        self._tell(text, person=person, seconds=CALL_S)
        return CALL_S, CALL_REPEAT_S

    def _call(self, party, playback, by):
        """Someone started a title: say so, and keep saying it until this device opens it or it stops applying."""
        now = self.clock()
        if party.get('can_watch') is False:
            # Nothing to do about it: said once.
            self._tell(self._starting_text(party, by), person=playback.get('by_person'))
            self.calling = None
            return
        seconds, repeat = self._say_call(self._starting_text(party, by), playback.get('by_person'))
        self.calling = {'party': party['id'], 'key': party['item']['key'], 'since': now, 'next': now + repeat * 1000,
                        'by': by, 'person': playback.get('by_person'), 'shown_until': now + seconds * 1000}

    def _remind(self, now):
        call, party = self.calling, self.party()
        still = (party and party['id'] == call['party'] and (party.get('item') or {}).get('key') == call['key']
                 and party['playback']['state'] in ('waiting', 'playing') and not self._on_party_item(party)
                 and not self.starting and now - call['since'] < CALL_MAX_S * 1000)
        if not still:
            self.calling = None
            if now < call['shown_until']:
                self.screen.clear_notice()  # opened it, or the party moved on: the call no longer applies
            return
        if now < call['next']:
            return
        if party['playback']['state'] == 'waiting':
            text = '{} is waiting for you to start {}. Open it in Plex to watch together.'.format(
                call['by'], describe(party['item']))
        else:
            text = 'The watch party is watching {}. Open it in Plex to join.'.format(describe(party['item']))
        seconds, repeat = self._say_call(text, call['person'])
        call.update(next=now + repeat * 1000, shown_until=now + seconds * 1000)

    def _waiting_text(self, party):
        missing = [m for m in party.get('members', []) if not m.get('me') and not m.get('ready')]
        if not missing:
            return 'Everyone is ready. Starting shortly.'
        here = [self._label(m) for m in missing if m.get('online')]
        away = [self._label(m) for m in missing if not m.get('online')]
        parts = []
        if here:
            parts.append('Waiting for {} to open it.'.format(names(here)))
        if away:
            # Not waited for by the server; said, so nobody waits on someone whose device is off.
            sentence = '{} {} offline.'.format(names(away), 'is' if len(away) == 1 else 'are')
            parts.append(sentence[0].upper() + sentence[1:])  # "your laptop" opens the sentence as "Your laptop"
        text = ' '.join(parts)
        return text + ' Press play to start without them.' if self._may_control(party) else text

    def _me_ready(self, party):
        return any(m.get('ready') for m in party.get('members', []) if m.get('me'))

    def _near(self, party, playback, now):
        """This player is about where the party is (its own skip lands within SAME_SPOT_S of what it said)."""
        mine = self.player.position()
        if mine is None:
            return True
        there = self._expected(party, now) if playback['state'] == 'playing' else playback['position']
        return abs(mine - there) < SAME_SPOT_S

    def _apply(self, party, playback):
        now = self.clock()
        by, kind = self._actor(playback), playback.get('kind')
        self.log('party {} #{} {} at {} ({} ms){}'.format(playback['state'], playback['seq'], kind, playback['position'],
                                                        (playback.get('at') or now) - now,
                                                        ' by me' if playback.get('by_me') else ''))
        self._diag('ap', seq=playback['seq'], kd=kind, st=playback['state'], pos=float(playback['position']),
                   inms=int((playback.get('at') or now) - now), me=self.player.position(), pz=self.player.paused(),
                   mine=bool(playback.get('by_me')), on=self._on_party_item(party))
        if not self._on_party_item(party) or self.starting:
            if self.scheduled:
                # The party moved to another title during a countdown: this one no longer starts.
                self.scheduled = None
                self.screen.clear_countdown()
            if (kind == 'start' and not playback.get('by_me') and playback['state'] in ('waiting', 'playing')
                    and not self.starting and party.get('item')):
                self._call(party, playback, by)
            return
        counting_down = playback['state'] == 'playing' and (playback.get('at') or 0) > now + 100
        if (playback.get('by_me') and kind in ('pause', 'seek') and not counting_down and not self.fresh_start
                and self._near(party, playback, now)):
            # This device's own pause or skip coming back: it is already there. (One made during a countdown still
            # has to be held for the shared moment, so it goes on below; and a title opened again since is not
            # there, so it follows like any other.)
            self.scheduled = None
            self.screen.clear_countdown()
            return
        state = playback['state']
        if state == 'paused':
            self.scheduled = None
            self.screen.clear_countdown()
            self.screen.clear_hold()
            self._pause()
            if playback.get('by_me'):
                # Back on the title after closing it, while someone else is still away.
                self.screen.hold(self._waiting_text(party), until_cleared=True)
            else:
                if kind == 'stopped':
                    text = '{} closed the video.'.format(by)
                    if self._may_control(party):
                        text += ' Press play to continue without {}.'.format('it' if self._own_device(playback) else 'them')
                    self.screen.hold(text)
                elif kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'] + 0.5)),
                               person=playback.get('by_person'))
                else:
                    self.screen.hold(self._paused_text(party, '{} paused'.format(by), playback))
        elif state == 'playing':
            self.screen.clear_hold()
            if playback['at'] > now + 100:
                self._pause()
                self.scheduled = (playback['at'], playback['position'])
                # A player a little ahead (it paused a moment after whoever paused) starts that much later, so its
                # countdown runs to its own start: it never sits at zero looking stuck.
                start = self._own_start(playback['at'], playback['position'])
                self.screen_countdown = None
                if start - now >= COUNTDOWN_MIN_MS:
                    self.screen_countdown = (start, 'Starting' if kind == 'start' else 'Resuming')
                    self.screen.countdown(*self.screen_countdown)
                if kind == 'rejoin' and not playback.get('by_me'):
                    self._tell('{} returned to the video.'.format(by), person=playback.get('by_person'))
                elif kind == 'resume' and not playback.get('by_me'):
                    self._tell('{} resumed playback.'.format(by), extra=True)
                elif kind == 'seek' and not playback.get('by_me'):
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'] + 0.5)),
                               person=playback.get('by_person'))
                return
            self.scheduled = None
            self.screen.clear_countdown()
            mine = None if self.player.paused() else self.player.position()
            if mine is not None and abs(mine - self._expected(party, now)) <= IN_STEP_S:
                # Already playing where the party is (the same state again, after a reconnect): leave it be.
                self.log('already in step')
            else:
                self._jump_to(self._expected(party, now))
                self._started()
            if not playback.get('by_me'):
                if kind == 'seek':
                    self._tell('{} skipped to {}.'.format(by, clock_label(playback['position'] + 0.5)),
                               person=playback.get('by_person'))
                elif kind == 'resume':
                    self._tell('{} resumed playback.'.format(by), extra=True)
        elif state == 'waiting':
            # Back to waiting (a finished title opened again): any countdown before it no longer applies.
            self.scheduled = None
            self.screen.clear_countdown()
            self._pause()
            # On screen for as long as the wait lasts (it used to leave after a few seconds).
            self.screen.hold(self._waiting_text(party), until_cleared=True)
            if not self._me_ready(party):
                # On the party's title but not counted as ready (the party moved titles meanwhile): say so again.
                self._send_playback('start', self.player.position() or 0.0)
