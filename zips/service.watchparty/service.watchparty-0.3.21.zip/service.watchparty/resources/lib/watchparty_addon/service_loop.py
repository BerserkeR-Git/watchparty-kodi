"""The background service: keeps this device in the watch party while Kodi runs.

Light on purpose (small ARM boxes): one waiting request to the server at a time,
one kept-open connection, a quick loop only while a video plays or a countdown runs,
and patient retries when the server is away.
"""
import json
import os
import queue
import threading
import time
import traceback

import xbmc
import xbmcgui

from . import shortcut, updates
from .guard import logged
from .avatars import Avatars
from .client import Client
from .engine import Engine, SendError
from .kodi_player import Observer, PlayerAdapter
from .kodi_screen import Screen

RELOAD_PROPERTY = 'watchparty.reload'
UPDATE_PROPERTY = 'watchparty.update'
# Set for as long as Kodi runs: without it, Kodi has just started (and not merely Watch Party, after an update).
SESSION_PROPERTY = 'watchparty.session'
ACTED_PROPERTY = 'watchparty.acted'
# After Kodi starts, Watch Party waits this long before it connects, so Kodi and PM4K (which may open at boot)
# have the screen to themselves; a watch party from before is then left quietly.
STARTUP_QUIET_S = 20
# An update started from the menu that has not arrived this long after is reported as not installed.
UPDATE_GRACE_S = 180
BUSY_TICK_S = 0.25
IDLE_TICK_S = 2.0
RETRY_STEPS_S = (1, 2, 5, 10, 30, 60)
# A refusal has to repeat for this long before this device counts as disconnected, so a restart, a deploy or a
# mistake on the server (a data file it cannot read) cannot knock it out for good. (30 s was too short for the
# latter: every device would have needed a new code.)
DISCONNECTED_AFTER = {'times': 10, 'seconds': 600}
# An unexpected error is logged and the service carries on; this many within FAULT_WINDOW_S start the connection
# afresh (after FAULT_PAUSE_S), rather than repeating a failure four times a second.
FAULTS_BEFORE_RESTART = 5
FAULT_WINDOW_S = 60
FAULT_PAUSE_S = 10
# After an unexpected failure of the service itself (a Kodi call can fail): made and run again after this long.
# Before, one failing call while it started, or in its loop's own waiting, ended Watch Party until Kodi restarted.
RESTART_PAUSE_S = 5
# Online after use (see Storage.awake): how often a connection checks whether it is still wanted, and how often a
# watch party under way counts as a use again (so the device stays online for the window after the party ends).
AWAKE_CHECK_S = 30
IN_PARTY_USE_S = 300
# What the engine learns about this device's player, kept with the preferences: its leads, and how far its jumps land.
LEARNED = ('play_lead', 'seek_lead', 'skip_lead', 'jump_spread')


def log(message):
    xbmc.log('[Watch Party] ' + message, xbmc.LOGINFO)


def log_fault(what):
    """An unexpected error: its details go to Kodi's log, and Watch Party carries on."""
    xbmc.log('[Watch Party] {} failed:\n{}'.format(what, traceback.format_exc()), xbmc.LOGERROR)


def start(addon_path, storage, version='0.0.0', made=None):
    """service.py's way in: the service made and run, and made and run again after an unexpected failure, until Kodi
    closes. `made` is given each service as it is made (for tests). One monitor throughout: only the monitor Kodi
    told it is stopping knows it (a new one made then says it is not), so the pause between tries uses it."""
    monitor = None
    while True:
        try:
            monitor = monitor or KodiMonitor()
            service = Service(addon_path, storage, version, monitor=monitor)
            if made:
                made(service)
            service.run()
            return
        except Exception:  # noqa: BLE001 - whatever it was: logged, then Watch Party starts again
            log_fault('the service')
        if _pause(monitor, RESTART_PAUSE_S):
            return


def _pause(monitor, seconds):
    """Waits; True if Kodi is closing. Never raises: it is what keeps the service going after a failure."""
    try:
        if monitor is not None:
            return monitor.waitForAbort(seconds)
    except Exception:  # noqa: BLE001
        pass
    time.sleep(seconds)
    try:
        return monitor is not None and monitor.abortRequested()
    except Exception:  # noqa: BLE001
        return False


class KodiMonitor(xbmc.Monitor):
    """Kodi's own notices: quitting (or restarting) is said before add-ons stop; an add-on update says nothing.
    Standby and waking up (CoreELEC keeps Kodi running through standby) go to `on_power`."""

    def __init__(self):
        super().__init__()
        self.quitting = False
        self.on_power = lambda event: None

    def onNotification(self, sender, method, data):
        if sender != 'xbmc':
            return
        if method in ('System.OnQuit', 'System.OnRestart'):
            self.quitting = True
        elif method == 'System.OnSleep':
            self.on_power('sleep')
        elif method == 'System.OnWake':
            self.on_power('wake')


class Updates(threading.Thread):
    """Waits for the server's next update, one request at a time, and hands it to the loop."""

    def __init__(self, client, inbox):
        super().__init__(name='watchparty-updates', daemon=True)
        self.client = client
        self.inbox = inbox
        self.running = True
        self.lock = threading.Lock()

    @logged('the update thread')
    def run(self):
        version, step, refusals, first_refusal = 0, 0, 0, None
        while self.running:
            try:
                state = self.client.state(version)
            except Exception as error:  # noqa: BLE001 - this thread must outlive any failure, or updates stop unseen
                if not isinstance(error, SendError):
                    log_fault('asking for updates')
                if isinstance(error, SendError) and error.code == 'disconnected':
                    refusals += 1
                    first_refusal = first_refusal or time.monotonic()
                    if (refusals >= DISCONNECTED_AFTER['times']
                            and time.monotonic() - first_refusal >= DISCONNECTED_AFTER['seconds']):
                        self._put('disconnected', None)
                        return
                else:
                    refusals, first_refusal = 0, None
                self._put('online', False)
                self._sleep(RETRY_STEPS_S[min(step, len(RETRY_STEPS_S) - 1)])
                step += 1
                continue
            step, refusals, first_refusal = 0, 0, None
            version = state.get('version', version)
            self._put('online', True)
            self._put('state', state)

    def _put(self, kind, payload):
        # Nothing once stopped: the inbox is the service's, and the next connection's engine reads it. The request
        # under way when the connection is closed fails, and its "offline" made that engine drop what was pressed.
        with self.lock:
            if self.running:
                self.inbox.put((kind, payload))

    def _sleep(self, seconds):
        deadline = time.monotonic() + seconds
        while self.running and time.monotonic() < deadline:
            time.sleep(0.5)

    def stop(self):
        with self.lock:
            self.running = False
        self.client.close_all()  # its own long poll too, which runs on this thread's connection, not the caller's


class Service:
    def __init__(self, addon_path, storage, version='0.0.0', monitor=None):
        self.addon_path = addon_path
        self.storage = storage
        self.version = version
        self.monitor = monitor or KodiMonitor()
        self.inbox = queue.Queue()
        self.monitor.on_power = self._power
        # Stamped as Kodi raises them: they may wait in the inbox while a request holds up the loop.
        self.observer = Observer(self._player_event)
        self.player = PlayerAdapter(self.observer)
        self.window = xbmcgui.Window(10000)
        self.fresh_kodi = False
        self.faults = []
        self.asleep = False
        # Kodi in standby (CoreELEC keeps it running): quiet like a device not used lately, until it wakes.
        self.standby = False
        # The party this device was in when Kodi went to standby: left once it is back, should the goodbye not
        # have arrived (the connection ends at standby, so the engine that knew is gone).
        self.standby_party = None
        # When the last standby began (wall clock, as the menu's time of use), and whether a goodbye for it was
        # taken care of (said, or not needed).
        self.standby_at = 0.0
        self.standby_handled = True

    def _power(self, event):
        self.standby = event == 'sleep'
        if self.standby:
            self.standby_at, self.standby_handled = time.time(), False
        self.inbox.put((event, None))

    def _player_event(self, name, data):
        # Something plays: Kodi is awake, even if it never said it woke up.
        self.standby = False
        self.inbox.put(('local', (name, data, time.monotonic())))

    def run(self):
        log('started')
        self.fresh_kodi = not self.window.getProperty(SESSION_PROPERTY)
        self.window.setProperty(SESSION_PROPERTY, '1')
        if self.fresh_kodi:
            self.window.clearProperty(ACTED_PROPERTY)
        self._migrate_shortcut()
        self._announce_update()
        if self.fresh_kodi and self.storage.awake():
            # A quiet device sends nothing, not even this: it was in no watch party lately (a party under way counts
            # as a use), and the server takes out a member it has not heard from in minutes.
            self._leave_at_once()
        if self.fresh_kodi and self.monitor.waitForAbort(STARTUP_QUIET_S):
            log('stopped')
            return
        while not self.monitor.abortRequested():
            device = self.storage.device()
            if not device or device.get('disconnected') or device.get('unreadable'):
                if self._wait_for_change(5):
                    break
                continue
            if self.standby or not self.storage.awake():
                # Not used for a while, or in standby: nothing is sent at all until Watch Party is opened again (the
                # menu marks a use, which changes the preferences file this waits on) or Kodi wakes up.
                if self.standby and not self.standby_handled and self.storage.awake():
                    # In use, but standby came before a connection knew of the use (the menu accepted an invitation
                    # a moment before): leave whatever party that was, as a connected device does at standby.
                    self.standby_handled = True
                    self._leave_at_once()
                if not self.asleep:
                    self.asleep = True
                    log('quiet during standby' if self.standby else 'quiet until Watch Party is opened')
                if self._wait_for_change(60):
                    break
                continue
            self.asleep = False
            if self._run_connected(device):
                break
            if len(self.faults) >= FAULTS_BEFORE_RESTART:
                self.faults = []
                if self.monitor.waitForAbort(FAULT_PAUSE_S):
                    break
        log('stopped')

    def _reload_requested(self, seen):
        value = self.window.getProperty(RELOAD_PROPERTY)
        return value != seen, value

    def _wait_for_change(self, seconds):
        """Sleep until the menu connects this device, or Kodi closes. True means Kodi is closing."""
        stamp, standby = self.storage.stamp(), self.standby
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self.monitor.waitForAbort(1):
                return True
            if self.storage.stamp() != stamp:
                if (self.storage.preferences().get('used_at') or 0) >= self.standby_at:
                    self.standby = False  # the menu was opened: Kodi is awake
                # (A use from before the standby, noticed only now, leaves Kodi in standby.)
                return False
            if self.standby != standby:
                return False
        return False

    def _migrate_shortcut(self):
        """Shortcuts chosen with 0.2.7 or older, written again the way Kodi reads them (see shortcut.migrate)."""
        # Kodi closed while a key was being chosen: give every key its job back.
        shortcut.stop_listening()
        preferences = self.storage.preferences()
        before = json.dumps(preferences, sort_keys=True)
        try:
            message = shortcut.migrate(preferences)
        except (shortcut.KeymapUnreadable, OSError) as error:
            log('shortcut not updated: {}'.format(type(error).__name__))
            return
        if json.dumps(preferences, sort_keys=True) != before:
            self.storage.save_preferences(preferences)
            log('shortcut written again for this version')
        if message:
            xbmcgui.Dialog().notification('Watch Party', message, os.path.join(self.addon_path, 'resources', 'icon.png'),
                                          15000, False)

    def _leave_at_once(self):
        """Leave a watch party right away, in the background (one small request): one from before Kodi started, so
        nobody sees it as still going during the quiet wait (should the network not be up yet, the engine leaves it
        once it connects); or one joined just before a standby that came before the connection."""
        device = self.storage.device()
        if not device or device.get('disconnected') or device.get('unreadable'):
            return
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)

        @logged('saying goodbye')
        def leave():
            client.goodbye()
            client.close()
        threading.Thread(target=leave, name='watchparty-goodbye', daemon=True).start()

    def _notify(self, text, seconds=6):
        xbmcgui.Dialog().notification('Watch Party', text, os.path.join(self.addon_path, 'resources', 'icon.png'),
                                      seconds * 1000, False)

    def _announce_update(self):
        """Say that an update arrived: Kodi's own message about it is easy to miss, and Watch Party restarts."""
        preferences = self.storage.preferences()
        before = preferences.get('installed_version')
        if before is None and self.storage.device():
            before = 'an earlier version'  # 0.3.1 and older did not note their version; a connected device is no new install
        if before != self.version:
            preferences['installed_version'] = self.version
            self.storage.save_preferences(preferences)
            if before:
                log('updated from {} to {}'.format(before, self.version))
                if self.storage.awake():
                    # Not on a device that is quiet: Kodi says it updated an add-on, and nobody here uses this one
                    # lately, so a word about it (perhaps over a film) is not needed.
                    self._notify('Watch Party was updated to version {}.'.format(self.version))
        self._check_update_request(arrived_only=True)

    def _check_update_request(self, arrived_only=False):
        """An update started from the menu: forget it once it is here; say so if it never came."""
        raw = self.window.getProperty(UPDATE_PROPERTY)
        if not raw:
            return
        try:
            request = json.loads(raw)
            wanted, at = str(request['version']), float(request['at'])
        except (ValueError, KeyError, TypeError):
            self.window.clearProperty(UPDATE_PROPERTY)
            return
        if not updates.newer(wanted, self.version):
            self.window.clearProperty(UPDATE_PROPERTY)
        elif not arrived_only and time.time() - at > UPDATE_GRACE_S:
            self.window.clearProperty(UPDATE_PROPERTY)
            log('update to {} did not arrive'.format(wanted))
            self._notify('Watch Party could not be updated to version {}. Open Watch Party and choose Check for '
                         'updates to try again.'.format(wanted), seconds=10)

    @staticmethod
    def _picture(engine_box, avatars, person):
        """A person's picture for a card, unless the server says they have none (removed on the admin page)."""
        engine = engine_box.get('engine')
        people = {p.get('id'): p.get('avatar') for p in ((engine.view if engine else None) or {}).get('people', [])}
        if person in people and not people[person]:
            avatars.forget(person)
            return None
        return avatars.get(person)

    @staticmethod
    def _pace(engine):
        """Seconds until the loop runs again. Four times a second only while something is under way or someone
        watches along; a video watched alone plays undisturbed (the player's own events still come in at once)."""
        tick = BUSY_TICK_S if engine.needs_quick_pace() else IDLE_TICK_S
        wake = engine.wake_in_ms()
        if wake is not None:
            # About to start: run exactly when needed, not up to a quarter second late.
            tick = min(tick, max(0.005, wake / 1000.0))
        return tick

    def _learned(self):
        """What the engine learned on this device before, and how it keeps what it learns next."""
        preferences = self.storage.preferences()
        learned = {}
        for name in LEARNED:
            learned[name] = preferences.get(name)
            learned['on_' + name] = self._saver(name)
        return learned

    def _saver(self, name):
        def save(value):
            # Read just before writing, so a change the menu made meanwhile is kept.
            preferences = self.storage.preferences()
            preferences[name] = value
            self.storage.save_preferences(preferences)
        return save

    def _run_connected(self, device):
        """Serve one connection until it changes. True means Kodi is closing."""
        # Noted before anything is read, so a change the menu makes from here on is seen. (Noted after the reads, a
        # change made in between became the starting point and was never applied: do not disturb stayed as it was.)
        stamp = self.storage.stamp()
        current = self.storage.device()
        if not current or current.get('device') != device['device']:
            return False  # connected to another device meanwhile: start again with that one
        client = Client(device['address'], device['device'], device['secret'], generation=device.get('generation', 0),
                        key_store=self.storage, version=self.version)
        avatars = Avatars(self.storage.avatar_folder, client)
        engine_box = {}
        screen = Screen(self.addon_path, client.server_now,
                        lambda: engine_box['engine'].settings.get('notice_s', 4),
                        lambda party, accept: self.inbox.put(('answer', (party, accept))),
                        avatar=lambda person: self._picture(engine_box, avatars, person),
                        card_folder=self.storage.card_folder,
                        log=lambda text: log('screen: ' + text),
                        on_stuck=lambda: engine_box['engine']._diag('ns') if engine_box.get('engine') else None)
        engine = Engine(self.player, screen, client.act, client.server_now, version=self.version,
                        log=lambda text: log('sync: ' + text),
                        clock_info=client.clock_quality, **self._learned(),
                        # Not a party joined or started from the menu meanwhile (during the wait after Kodi started).
                        leave_old_party=(self.fresh_kodi and not self.window.getProperty(ACTED_PROPERTY))
                        or self.standby_party or False)
        self.fresh_kodi = False  # once per Kodi start
        self.standby_party = None
        engine_box['engine'] = engine
        self.observer.catch_up()  # a video already playing as Watch Party starts
        engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        updates = Updates(client, self.inbox)
        updates.start()
        try:
            # Inside the try: a failure here used to leave the update thread running for good.
            seen_reload = self.window.getProperty(RELOAD_PROPERTY)
            next_awake_check, last_use = time.monotonic() + AWAKE_CHECK_S, 0.0
            log('connected as device ' + device['device'])
            while True:
                tick = self._pace(engine)
                if self.monitor.waitForAbort(0.001):
                    if self.monitor.quitting and engine.party():
                        # Kodi is closing: say goodbye, so the others are not left waiting for this device.
                        log('Kodi is closing: leaving the watch party')
                        client.goodbye()
                    return True
                try:
                    kind, payload = self.inbox.get(timeout=tick)
                except queue.Empty:
                    kind, payload = None, None
                try:
                    done = self._step(engine, screen, client, kind, payload)
                except Exception:  # noqa: BLE001 - one failure must not stop Watch Party until Kodi restarts
                    log_fault('handling {}'.format(kind or 'a tick'))
                    now = time.monotonic()
                    self.faults = [at for at in self.faults if now - at < FAULT_WINDOW_S] + [now]
                    if len(self.faults) >= FAULTS_BEFORE_RESTART:
                        log('{} failures in a minute: connecting again'.format(len(self.faults)))
                        return False
                    continue
                if done is not None:
                    return done
                if time.monotonic() >= next_awake_check:
                    next_awake_check = time.monotonic() + AWAKE_CHECK_S
                    last_use = self._keep_awake(engine, last_use)
                    if last_use is None:
                        log('not used for a while: quiet until Watch Party is opened')
                        return False
                changed, seen_reload = self._reload_requested(seen_reload)
                if changed:
                    return False
                if self.storage.stamp() != stamp:
                    stamp = self.storage.stamp()
                    current = self.storage.device()
                    if not current or current.get('device') != device['device']:
                        return False
                    engine.set_do_not_disturb(self.storage.preferences().get('do_not_disturb'))
        finally:
            updates.stop()
            screen.close(questions=not self.monitor.abortRequested())

    def _keep_awake(self, engine, last_use):
        """Keep the admin's window in the preferences, count a watch party under way as a use (now and then), and
        say whether this connection is still wanted: the last use time, or None to go quiet."""
        preferences = self.storage.preferences()
        setting = str(engine.settings.get('stay_online', '4'))
        if preferences.get('stay_online') != setting:
            preferences['stay_online'] = setting
            self.storage.save_preferences(preferences)
        if engine.party():
            if not last_use or time.monotonic() - last_use >= IN_PARTY_USE_S:
                self.storage.mark_used()
                last_use = time.monotonic()
            return last_use
        return last_use if self.storage.awake() else None

    def _step(self, engine, screen, client, kind, payload):
        """One event (or none) and a tick. Returns False to connect again, None to carry on."""
        if kind == 'local':
            name, data, raised = payload
            engine.on_local(name, age_ms=int((time.monotonic() - raised) * 1000), **data)
        elif kind == 'state':
            engine.on_state(payload)
        elif kind == 'online':
            engine.set_online(payload)
        elif kind == 'answer':
            engine.respond(*payload)
        elif kind == 'sleep':
            # Standby: a device asleep cannot keep in touch, so it leaves now, as when Kodi closes, rather than being
            # taken out minutes later while the others wait for it.
            if engine.party():
                log('Kodi is going to standby: leaving the watch party')
                self.standby_party = engine.party().get('id')
                client.goodbye()
            elif self.standby and engine.view is None:
                # No news yet, so no telling whether it is in a party: the menu may have just accepted an invitation.
                client.goodbye()
            engine.left_for_standby()
            if self.standby:
                self.standby_handled = True
                return False  # quiet until Kodi wakes (one noticed late, after waking, changes nothing more)
        elif kind == 'disconnected':
            screen.notice('This device was disconnected from Watch Party. Open Watch Party to connect it again.')
            self.storage.mark_disconnected()
            return False
        engine.tick()
        screen.tick()
        self._check_update_request()
        return None
